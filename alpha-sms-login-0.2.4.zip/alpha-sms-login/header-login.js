(() => {
    const panel = document.currentScript.dataset.panel;
    const header = '.header-options-item-account';
    const trigger = 'a.open-popbox-login, a[data-alpha-panel-login]';

    function update(link) {
        link.href = panel;
        link.classList.remove('open-popbox-login');
        link.dataset.alphaPanelLogin = '';
        if (!link.hasAttribute('aria-label')) link.setAttribute('aria-label', 'ورود / ثبت‌نام');
    }

    // Capture the click before the theme's delegated popup handler.
    window.addEventListener('click', event => {
        if (document.body?.classList.contains('logged-in') || !(event.target instanceof Element)) return;
        const link = event.target.closest(header)?.querySelector(trigger);
        if (!link) return;
        update(link);
        event.stopImmediatePropagation();
        if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        window.location.assign(panel);
    }, true);

    document.addEventListener('DOMContentLoaded', () => {
        if (document.body.classList.contains('logged-in')) return;
        document.querySelectorAll(header).forEach(item => {
            const link = item.querySelector(trigger);
            if (link) update(link);
        });
    });
})();

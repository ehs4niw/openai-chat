# اجزای ثالث

- WordPress: GPLv2 or later؛ هسته وردپرس در بسته نصب آلفا قرار ندارد.
- React / React DOM: MIT.
- ExcelJS: MIT؛ فقط خواندن/نوشتن فایل XLSX در رابط؛ وابستگی‌ها در frontend/package-lock.json ثبت‌اند.
- qrcode: MIT.
- esbuild: MIT؛ ابزار ساخت روی رایانه توسعه و نه نیاز هاست.
- Vazirmatn: SIL Open Font License؛ متن در assets/OFL.txt همراه هسته قرار دارد.

متن مجوزهای موجود در فایل اجرایی esbuild حفظ شده و فایل LICENSES.txt فهرست مجوزهای بسته‌های npm را همراه دارد. حقوق و مجوز اجزای ثالث متعلق به صاحبان آن‌هاست.

<?php
/**
 * Plugin Name: Alpha Core | هسته مشاوران آلفا
 * Description: هسته، دسترسی‌ها، پایگاه داده و پنل React سامانه آلفا.
 * Version: 0.1.0
 * Requires at least: 6.5
 * Requires PHP: 8.0
 */
defined('ABSPATH') || exit;
define('ALPHA_VERSION', '0.1.0');
require_once __DIR__.'/includes/domain.php';
require_once __DIR__.'/includes/schema.php';
register_activation_hook(__FILE__, 'alpha_activate');
add_action('rest_api_init', function(){
    alpha_route('/me', 'GET', function(){
        $u=wp_get_current_user();return ['id'=>$u->ID,'name'=>$u->display_name,'caps'=>array_values(array_filter(alpha_caps(),fn($c)=>current_user_can($c))),'modules'=>apply_filters('alpha_modules',[]),'currency'=>'IRR'];
    },'alpha_access');
    alpha_route('/files', 'POST', 'alpha_upload', 'alpha_access');
    alpha_route('/accounts','GET',function($r){$q=alpha_text($r['q']??'',100);if(mb_strlen($q)<3)return [];return array_map(fn($u)=>['id'=>$u->ID,'name'=>$u->display_name,'login'=>$u->user_login,'roles'=>array_values(array_filter($u->roles,fn($role)=>str_starts_with($role,'alpha_')))],get_users(['search'=>'*'.$q.'*','search_columns'=>['user_login','display_name','user_email'],'number'=>20,'role__not_in'=>['administrator']]));},'alpha_manage');
    alpha_route('/accounts/(?P<id>\d+)/role','POST',function($r){$u=get_userdata((int)$r['id']);$role=$r['role'];if(!$u||user_can($u,'manage_options'))alpha_fail('تغییر این حساب مجاز نیست.',403);if(!in_array($role,['alpha_manager','alpha_reception','alpha_finance','alpha_consultant','alpha_student'],true))alpha_fail('نقش معتبر نیست.');foreach($u->roles as $old)if(str_starts_with($old,'alpha_'))$u->remove_role($old);$u->add_role($role);alpha_audit('account',$u->ID,'role_assigned',['role'=>$role]);return ['ok'=>true];},'alpha_manage');

    do_action('alpha_register_routes');
});
add_action('admin_post_alpha_file','alpha_download');
add_action('admin_menu',function(){add_menu_page('مشاوران آلفا','پنل آلفا','alpha_access','alpha-panel',function(){echo alpha_shortcode();},'dashicons-welcome-learn-more',30);});
function alpha_assets($atts=[]){
    static $prepared=false;if($prepared)return;$prepared=true;
    wp_enqueue_style('alpha-panel',plugins_url('assets/app.css',__FILE__),[],ALPHA_VERSION);
    wp_enqueue_script('alpha-panel',plugins_url('assets/app.js',__FILE__),[],ALPHA_VERSION,true);
    $login=get_option('alpha_login_url',home_url('/login/'));
    $config=['api'=>esc_url_raw(rest_url('alpha/v1/')),'nonce'=>wp_create_nonce('wp_rest'),'loggedIn'=>is_user_logged_in(),'login'=>add_query_arg('r',get_permalink()?:home_url('/alpha-panel/'),$login),'intake'=>home_url('/alpha-intake/'),'public'=>isset($atts['public'])];
    wp_add_inline_script('alpha-panel','window.ALPHA='.wp_json_encode($config).';','before');
}
function alpha_shortcode($atts=[]){
    alpha_assets($atts);
    return '<div id="alpha-panel" dir="rtl"><p>در حال آماده‌سازی پنل آلفا…</p></div>';
}
add_shortcode('alpha_panel','alpha_shortcode');
add_shortcode('alpha_intake',fn()=>alpha_shortcode(['public'=>true]));
add_action('wp_login',function(){/* Existing OTP owns identity. Alpha never creates a parallel login session. */},10,0);
add_action('template_redirect',function(){if(is_page(['alpha-panel','alpha-intake'])){if(!defined('DONOTCACHEPAGE'))define('DONOTCACHEPAGE',true);nocache_headers();do_action('litespeed_control_set_nocache','Alpha private workflow');}});
add_filter('template_include',function($template){return is_page(['alpha-panel','alpha-intake'])?__DIR__.'/templates/portal.php':$template;},99);

add_action('wp_enqueue_scripts',function(){if(is_page(['alpha-panel','alpha-intake']))alpha_assets(['public'=>is_page('alpha-intake')]);});
add_filter('wp_robots',function($robots){if(is_page(['alpha-panel','alpha-intake'])){$robots['noindex']=true;$robots['nofollow']=true;}return $robots;});

<?php
defined('ABSPATH') || exit;
function alpha_notify($uid,$message){if($uid>0)alpha_insert('notifications',['user_id'=>$uid,'body'=>$message,'created_at'=>alpha_now()]);}
add_action('alpha_event',function($event,$kind,$id){
    if($kind==='booking'){$b=alpha_get('bookings',$id);alpha_notify((int)$b['user_id'],'وضعیت درخواست جلسه: '.(['booking_requested'=>'در انتظار تأیید پذیرش','booking_approved'=>'تأیید شد','booking_rejected'=>'رد شد','booking_cancelled'=>'لغو شد'][$event]??$event));}
    if($kind==='payment'){$p=alpha_get('payments',$id);$i=alpha_get('invoices',$p['invoice_id']);$s=alpha_get('students',$i['student_id']);alpha_notify((int)$s['user_id'],'وضعیت رسید پرداخت: '.(['receipt_submitted'=>'در انتظار بررسی مالی','payment_approved'=>'تأیید شد','payment_rejected'=>'رد شد'][$event]??$event));}
    // Future SMS adapters must explicitly implement alpha_sms_dispatch; no provider key is embedded.
},10,3);
add_action('alpha_register_routes',function(){
    alpha_route('/notifications','GET',function(){global $wpdb;return $wpdb->get_results($wpdb->prepare('SELECT id,body,is_read,created_at FROM '.alpha_table('notifications').' WHERE user_id=%d ORDER BY id DESC LIMIT 100',get_current_user_id()),ARRAY_A);},'alpha_access');
    alpha_route('/notifications/(?P<id>\d+)/read','POST',function($r){global $wpdb;$n=alpha_get('notifications',$r['id']);if((int)$n['user_id']!==get_current_user_id())alpha_fail('دسترسی مجاز نیست.',403);alpha_dbcheck($wpdb->update(alpha_table('notifications'),['is_read'=>1],['id'=>$n['id']]));return ['ok'=>true];},'alpha_access');
});

<?php
/**
 * Plugin Name: Alpha Booking | نوبت‌دهی
 * Version: 0.1.0
 * Requires Plugins: alpha-core
 * Requires PHP: 8.0
 */
defined('ABSPATH') || exit;
add_action('plugins_loaded',function(){
    if(!defined('ALPHA_VERSION')){add_action('admin_notices',function(){echo '<div class="notice notice-error"><p>ابتدا هسته آلفا را فعال کنید.</p></div>';});return;}
    alpha_module('booking');
    require_once __DIR__.'/routes.php';
});

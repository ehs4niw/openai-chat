<?php
/**
 * Plugin Name: Alpha Booking | نوبت‌دهی
 * Version: 0.3.1
 * Requires Plugins: alpha-core
 * Requires PHP: 8.0
 */
defined('ABSPATH') || exit;
add_action('plugins_loaded',function(){
    if(!defined('ALPHA_VERSION')){add_action('admin_notices',function(){echo '<div class="notice notice-error"><p>ابتدا هسته آلفا را فعال کنید.</p></div>';});return;}
    if(version_compare(ALPHA_VERSION,'0.3.0','<')){add_action('admin_notices',function(){echo '<div class="notice notice-error"><p>برای نوبت‌دهی ۰.۳، ابتدا Alpha Core را به ۰.۳.۰ به‌روزرسانی کنید.</p></div>';});return;}
    define('ALPHA_BOOKING_FIRST_VISIT', true);
    alpha_module('booking');
    require_once __DIR__.'/routes.php';
    require_once __DIR__.'/management.php';
});


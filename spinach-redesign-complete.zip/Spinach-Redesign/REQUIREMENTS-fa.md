# نقشه صفحات و پوشش خواسته‌ها

| شماره | صفحه | فایل |
|---|---|---|
| 01 | خانه | [01-home](pages/01-home.html) |
| 02 | معرفی و راهنمای اسپیناچ | [02-about](pages/02-about.html) |
| 03 | فروشگاه | [03-store](pages/03-store.html) |
| 04 | پک جامع آموزشی | [04-package](pages/04-package.html) |
| 05 | جزئیات دوره | [05-course](pages/05-course.html) |
| 06 | کتاب‌های فیزیکی | [06-books](pages/06-books.html) |
| 07 | کتاب مبحثی زیست | [07-book](pages/07-book.html) |
| 08 | سبد خرید | [08-cart](pages/08-cart.html) |
| 09 | تکمیل سفارش | [09-checkout](pages/09-checkout.html) |
| 10 | محیط یادگیری مرحله‌ای | [10-learning](pages/10-learning.html) |
| 11 | کتاب‌خوان مبحثی | [11-reader](pages/11-reader.html) |
| 12 | مرکز آزمون | [12-exams](pages/12-exams.html) |
| 13 | آزمون‌ساز | [13-builder](pages/13-builder.html) |
| 14 | شرکت در آزمون | [14-take-exam](pages/14-take-exam.html) |
| 15 | کارنامه تحلیلی | [15-results](pages/15-results.html) |
| 16 | آزمون‌های شبیه‌ساز کنکور | [16-simulators](pages/16-simulators.html) |
| 17 | کلاس‌های آنلاین | [17-live](pages/17-live.html) |
| 18 | آرشیو کلاس آنلاین | [18-recording](pages/18-recording.html) |
| 19 | آموزش‌های رایگان | [19-free](pages/19-free.html) |
| 20 | تماشای آموزش رایگان | [20-free-video](pages/20-free-video.html) |
| 21 | انتخاب مشاور | [21-counseling](pages/21-counseling.html) |
| 22 | پروفایل مشاور | [22-advisor-profile](pages/22-advisor-profile.html) |
| 23 | رزرو جلسه معارفه | [23-booking](pages/23-booking.html) |
| 24 | داشبورد دانش‌آموز | [24-student](pages/24-student.html) |
| 25 | ثبت ساعت مطالعه | [25-study](pages/25-study.html) |
| 26 | داشبورد مشاور | [26-advisor](pages/26-advisor.html) |
| 27 | درخواست‌های مشاوره | [27-requests](pages/27-requests.html) |
| 28 | پنل اولیا | [28-parent](pages/28-parent.html) |
| 29 | پنل مدیر کل | [29-admin](pages/29-admin.html) |
| 30 | مجله اسپیناچ | [30-articles](pages/30-articles.html) |
| 31 | صفحه مقاله | [31-article](pages/31-article.html) |
| 32 | مدیریت و ویرایش مقاله | [32-editor](pages/32-editor.html) |
| 33 | مدیریت محصولات و محتوا | [33-admin-products](pages/33-admin-products.html) |
| 34 | مدیریت آزمون و آرشیو | [34-admin-exams](pages/34-admin-exams.html) |
| 35 | ورود | [35-login](pages/35-login.html) |
| 36 | ثبت‌نام | [36-register](pages/36-register.html) |
| 37 | برنامه هفتگی | [37-study-plan](pages/37-study-plan.html) |
| 38 | محیط یادگیری با دسترسی کامل | [38-learning-open](pages/38-learning-open.html) |
| 39 | پیگیری رزروها برای مدیر | [39-admin-bookings](pages/39-admin-bookings.html) |
| 40 | مدیریت کاربران و دسترسی | [40-admin-users](pages/40-admin-users.html) |
| 41 | سفارش‌ها و ارسال کتاب | [41-admin-orders](pages/41-admin-orders.html) |
| 42 | پیامک‌ها و تنظیمات | [42-admin-sms](pages/42-admin-sms.html) |
| 43 | خط ویژه اسپیناچ | [43-special-line](pages/43-special-line.html) |
| 44 | مطالعه سؤالات و پاسخنامه آزمون | [44-simulator-pdf](pages/44-simulator-pdf.html) |
| 45 | پاسخنامه ویدیویی آزمون | [45-simulator-video](pages/45-simulator-video.html) |

## ارتباط خواسته‌ها با طراحی

| خواسته | صفحه‌ها و حالت‌های مرتبط |
|---|---|
| صفحه اصلی خلوت و معرفی مستقل | 01-home، 02-about |
| حفظ هویت مرجع و هدر و فوتر هماهنگ | صفحات عمومی؛ نسخه مستقل ورود سرمه‌ای |
| فروشگاه بهتر، پک و دوره | 03-store، 04-package، 05-course |
| کتاب فیزیکی، چهار تصویر نمونه و سفارش | 06-books، 07-book، 08-cart، 09-checkout |
| انتخاب دسترسی مرحله‌ای هنگام خرید | 04-package، 05-course، سبد خرید |
| بازشدن همه منابع جلسه بعد با تکمیل آزمون | 10-learning، 14-take-exam، 15-results |
| حالت دسترسی کامل بدون قفل | 38-learning-open |
| کتاب مبحثی اسلایدی کنار دوره آفلاین و آنلاین | 10-learning، 11-reader، 17-live، 18-recording |
| آزمون‌ساز ساده، متوسط، سخت و ترکیبی | 13-builder |
| آزمون آنلاین و کارنامه تحلیلی | 12-exams، 14-take-exam، 15-results |
| آزمون‌های قلم‌چی، ماز و خیلی سبز با سه بخش | 16-simulators، 44-simulator-pdf، 45-simulator-video |
| افزودن آرشیو با PDF سؤال و پاسخ و ویدیو | 34-admin-exams؛ فرم تاریخ و وضعیت انتشار |
| کلاس آنلاین و جلسات ضبط‌شده | 17-live، 18-recording |
| آموزش رایگان و صفحه مستقل ویدیو | 19-free، 20-free-video |
| انتخاب مشاور، سه زمان و تأیید مشاور | 21-counseling، 22-advisor-profile، 23-booking، 27-requests |
| اطلاع درخواست به مشاور و مدیر، تأیید برای دانش‌آموز | 23-booking، 27-requests، 39-admin-bookings، 42-admin-sms |
| پنل دانش‌آموز، مطالعه و برنامه هفتگی | 24-student، 25-study، 37-study-plan |
| پنل مشاور | 26-advisor، 27-requests |
| پنل اولیا با گزارش‌های قابل اشتراک | 28-parent |
| پنل مدیر کل و کنترل نقش‌ها | 29-admin، 39-admin-bookings، 40-admin-users |
| مدیریت محصولات و چهار صفحه کتاب | 33-admin-products |
| سفارش و ارسال کتاب و پیامک‌ها | 41-admin-orders، 42-admin-sms |
| مجله و صفحه مقاله | 30-articles، 31-article |
| مدیریت مقاله از داشبورد، پیش‌نویس و تنظیمات سئو | 32-editor |
| ورود و ثبت‌نام سرمه‌ای با دکمه زرد | 35-login، 36-register |
| حفظ خط ویژه | 43-special-line |

## جریان‌های اصلی بررسی طراحی

۱. خانه ← معرفی اسپیناچ ← فروشگاه ← دوره ← انتخاب حالت دسترسی ← سبد ← تسویه‌حساب.
۲. یادگیری مرحله‌ای ← کتاب مبحثی ← آزمون ← کارنامه ← بازشدن همه محتواهای جلسه دوم.
۳. مشاوره ← پروفایل مشاور ← سه زمان پیشنهادی ← بررسی در پنل مشاور ← مشاهده وضعیت در پنل مدیر.
۴. آرشیو شبیه‌ساز ← دفترچه سؤالات / پاسخنامه PDF / پاسخنامه ویدیویی؛ مستقل از آزمون آنلاین.
۵. مدیر کل ← مدیریت مقاله ← ویرایش، پیش‌نویس، پیش‌نمایش، تنظیمات انتشار و سئو.

هیچ‌یک از این جریان‌ها در این بسته عملیات مالی، ارسال پیامک یا ذخیره‌سازی سروری انجام نمی‌دهند. درباره تعامل‌های قابل کلیک و محدودیت‌های نمونه، START-HERE-fa.txt را بخوانید.

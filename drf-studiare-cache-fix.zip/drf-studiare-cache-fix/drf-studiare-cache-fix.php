<?php
/**
 * Plugin Name: DrFarzi Studiare Login & Loader Fix
 * Description: Fresh authentication nonces for cached Studiare pages, with immediate page content display.
 * Version: 1.0.0
 * Requires PHP: 7.4
 */

defined('ABSPATH') || exit;

final class DRF_Studiare_Cache_Fix {
    const VERSION = '1.0.0';

    public static function init() {
        add_action('wp_ajax_drf_sc_auth_boot', array(__CLASS__, 'bootstrap'));
        add_action('wp_ajax_nopriv_drf_sc_auth_boot', array(__CLASS__, 'bootstrap'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'assets'), 99);
        add_action('after_setup_theme', array(__CLASS__, 'disable_loader'), 100);
        add_action('wp_head', array(__CLASS__, 'loader_css'), 1);
        add_action('template_redirect', array(__CLASS__, 'private_account'), 0);
    }

    public static function is_studiare() {
        return 'studiare' === get_template();
    }

    public static function no_cache() {
        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }
        nocache_headers();
        header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0', true);
        do_action('litespeed_control_set_nocache', 'DrFarzi authentication or private account');
    }

    /** Public bootstrap: only fresh form nonces; no account data or authentication changes. */
    public static function bootstrap() {
        self::no_cache();
        if (!isset($_SERVER['REQUEST_METHOD']) || 'POST' !== $_SERVER['REQUEST_METHOD']) {
            header('Allow: POST');
            wp_send_json_error(array('message' => 'POST required.'), 405);
            return;
        }
        if (!self::is_studiare()) {
            wp_send_json_error(array('message' => 'Studiare is not active.'), 409);
            return;
        }
        // No nonce gate here: this read-only endpoint replaces stale public-page nonces.
        // The original theme/core handlers still validate every protected request.
        wp_send_json_success(array('nonces' => array(
            'popup' => wp_create_nonce('load_login_popup_nonce'),
            'otp'   => wp_create_nonce('combined_otp_nonce'),
            'woo'   => wp_create_nonce('custom_login_register_nonce_action'),
        )));
    }

    public static function assets() {
        if (!self::is_studiare()) {
            return;
        }
        $handle = 'drf-sc-cache-fix';
        wp_enqueue_script($handle, plugins_url('assets/auth-cache.js', __FILE__), array('jquery'), self::VERSION, false);
        wp_localize_script($handle, 'DRF_SC_CACHE', array('ajax' => admin_url('admin-ajax.php')));
        // Ensure our transport is registered before the theme's login handlers run.
        $scripts = wp_scripts();
        foreach (array('studiare-theme', 'combined-otp-scripts', 'custom-woo-login-register-ajax') as $theme_handle) {
            if (isset($scripts->registered[$theme_handle]) && !in_array($handle, $scripts->registered[$theme_handle]->deps, true)) {
                $scripts->registered[$theme_handle]->deps[] = $handle;
            }
        }
    }

    public static function disable_loader() {
        if (self::is_studiare()) {
            remove_action('studiare_before_body', 'studiare_preloader', 10);
        }
    }

    public static function loader_css() {
        if (self::is_studiare()) {
            echo '<style id="drf-sc-no-loader">.studiare-preloader{display:none!important;visibility:hidden!important;pointer-events:none!important}</style>';
        }
    }

    public static function private_account() {
        if (self::is_studiare() && function_exists('is_account_page') && is_account_page()) {
            self::no_cache();
        }
    }
}

DRF_Studiare_Cache_Fix::init();

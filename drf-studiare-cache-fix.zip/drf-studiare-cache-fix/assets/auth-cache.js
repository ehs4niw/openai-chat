(function ($, window) {
    'use strict';
    if (!$ || !window.DRF_SC_CACHE || !window.fetch || !window.AbortController || !window.URLSearchParams) {
        return;
    }
    var endpoint = new URL(window.DRF_SC_CACHE.ajax, window.location.href);
    if (endpoint.origin !== window.location.origin) { return; }
    var routes = {
        load_login_popup: ['popup', '_ajax_nonce'],
        check_and_send_combined_otp: ['otp', 'nonce'],
        verify_combined_otp: ['otp', 'nonce'],
        custom_login_register_action: ['woo', 'nonce']
    };

    // Keep jQuery's callbacks, converters, beforeSend, global events and abort API.
    // Only these four POST actions to this site's admin-ajax use this transport.
    $.ajaxTransport('+*', function (options) {
        if (options.async === false || options.crossDomain || String(options.type).toUpperCase() !== 'POST' ||
                typeof options.data !== 'string') { return; }
        var requestURL;
        try { requestURL = new URL(options.url, window.location.href); } catch (e) { return; }
        if (requestURL.origin !== endpoint.origin || requestURL.pathname !== endpoint.pathname) { return; }
        var body = new URLSearchParams(options.data);
        var rule = routes[body.get('action')];
        if (!rule) { return; }
        var controller = new AbortController();
        var aborted = false;
        var timer;

        return {
            send: function (headers, complete) {
                // Also bound requests whose original caller supplied no timeout.
                timer = window.setTimeout(function () {
                    if (aborted) { return; }
                    aborted = true;
                    controller.abort();
                    complete(0, 'timeout');
                }, 20000);

                function failure(error) {
                    window.clearTimeout(timer);
                    if (aborted) { return; }
                    complete(503, 'error', {text: JSON.stringify({success: false, data: {
                        message: 'ارتباط با سرور برقرار نشد؛ دوباره تلاش کنید.'
                    }})}, 'Content-Type: application/json');
                }
                var bootURL = new URL(endpoint.href);
                bootURL.searchParams.set('drf_sc_fresh', String(Date.now()));
                window.fetch(bootURL.href, {
                    method: 'POST', credentials: 'same-origin', cache: 'no-store',
                    redirect: 'error', signal: controller.signal,
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest'},
                    body: 'action=drf_sc_auth_boot'
                }).then(function (response) {
                    if (!response.ok) { throw new Error('Bootstrap HTTP ' + response.status); }
                    return response.json();
                }).then(function (result) {
                    var nonces = result && result.success && result.data && result.data.nonces;
                    if (!nonces || typeof nonces[rule[0]] !== 'string' || !nonces[rule[0]]) {
                        throw new Error('No fresh authentication nonce');
                    }
                    if (aborted) { return; }
                    body.set(rule[1], nonces[rule[0]]);
                    if (window.loginAjax) { window.loginAjax.nonce = nonces.popup; }
                    if (window.combined_otp_ajax_object) { window.combined_otp_ajax_object.nonce = nonces.otp; }
                    if (window.custom_woo_login_register_params) { window.custom_woo_login_register_params.nonce = nonces.woo; }
                    // Preserve all original fields, including custom registration fields and passwords.
                    var outgoingHeaders = Object.assign({}, headers);
                    if (!Object.keys(outgoingHeaders).some(function (key) { return key.toLowerCase() === 'x-requested-with'; })) {
                        outgoingHeaders['X-Requested-With'] = 'XMLHttpRequest';
                    }
                    return window.fetch(requestURL.href, {
                        method: 'POST', credentials: 'same-origin', cache: 'no-store',
                        redirect: 'error', signal: controller.signal,
                        headers: outgoingHeaders, body: body.toString()
                    });
                }).then(function (response) {
                    if (!response || aborted) { return; }
                    return response.text().then(function (text) {
                        window.clearTimeout(timer);
                        if (aborted) { return; }
                        var responseHeaders = '';
                        response.headers.forEach(function (value, key) { responseHeaders += key + ': ' + value + '\r\n'; });
                        complete(response.status, response.statusText || 'OK', {text: text}, responseHeaders);
                    });
                }).catch(failure);
            },
            abort: function () {
                aborted = true;
                window.clearTimeout(timer);
                controller.abort();
            }
        };
    });
})(window.jQuery, window);

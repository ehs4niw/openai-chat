<?php
defined('ABSPATH') || exit;
function alpha_backup_tables(){return ['leads','followups','students','notes','slots','bookings','services','invoices','payments','installments','files','audit','notifications'];}
add_action('alpha_register_routes',function(){
    alpha_route('/reports','GET',function(){global $wpdb;$counts=[];foreach(['leads','students','bookings'] as $t)$counts[$t]=(int)$wpdb->get_var('SELECT COUNT(*) FROM '.alpha_table($t));$counts['approved']=(int)$wpdb->get_var('SELECT COALESCE(SUM(amount),0) FROM '.alpha_table('payments')." WHERE status='approved'");$counts['total']=(int)$wpdb->get_var('SELECT COALESCE(SUM(amount),0) FROM '.alpha_table('invoices'));$counts['balance']=$counts['total']-$counts['approved'];$counts['pending_receipts']=(int)$wpdb->get_var('SELECT COUNT(*) FROM '.alpha_table('payments')." WHERE status='pending'");$counts['audit']=$wpdb->get_results('SELECT actor_id,kind,entity_id,event,created_at FROM '.alpha_table('audit').' ORDER BY id DESC LIMIT 50',ARRAY_A);return $counts;},'alpha_reports');
    alpha_route('/import/leads','POST',function($r){$rows=$r['rows'];if(!is_array($rows)||count($rows)>200||!count($rows))alpha_fail('هر بار ۱ تا ۲۰۰ ردیف ارسال کنید.');$errors=[];foreach($rows as $k=>$row){try{alpha_phone($row['phone']??'');if(!alpha_text($row['name']??'',200))alpha_fail('نام لازم است.');alpha_lead_data($row);}catch(Throwable $e){$errors[]=['row'=>$k+2,'message'=>$e->getMessage()];}}if($errors)return ['imported'=>0,'errors'=>$errors];return alpha_tx(function()use($rows){$ids=[];foreach($rows as $row){$row['website']='';$ids[]=alpha_new_lead($row)['id'];}return ['imported'=>count($ids),'ids'=>$ids,'errors'=>[]];});},'alpha_admissions');
    alpha_route('/settings','GET',function(){return ['login_url'=>get_option('alpha_login_url',home_url('/login/')),'booking_policy'=>'درخواست تا زمان تأیید یا رد پذیرش ظرفیت را نگه می‌دارد.','currency'=>'ریال','company_name'=>get_option('alpha_company_name','مشاوران آلفا'),'academic_year'=>get_option('alpha_academic_year','')];},'alpha_manage');
    alpha_route('/settings','POST',function($r){$url=esc_url_raw($r['login_url']??'');if(!$url||wp_parse_url($url,PHP_URL_HOST)!==wp_parse_url(home_url(),PHP_URL_HOST))alpha_fail('نشانی ورود باید متعلق به همین سایت باشد.');update_option('alpha_login_url',$url,false);if(isset($r['company_name']))update_option('alpha_company_name',alpha_text($r['company_name'],100),false);if(isset($r['academic_year']))update_option('alpha_academic_year',alpha_text($r['academic_year'],30),false);return ['ok'=>true];},'alpha_manage');
});
// Domain-only backup/restore. No public REST endpoint exposes these operations.
function alpha_backup_write($path){
    global $wpdb;$dir=realpath(dirname($path));$web=realpath(ABSPATH);
    if(!$dir||!is_writable($dir)||($web&&($dir===$web||str_starts_with($dir,$web.DIRECTORY_SEPARATOR))))alpha_fail('Backup must be outside the public WordPress directory.');
    $out=['version'=>ALPHA_VERSION,'created_at'=>alpha_now(),'tables'=>[]];
    foreach(alpha_backup_tables() as $t)$out['tables'][$t]=$wpdb->get_results('SELECT * FROM '.alpha_table($t),ARRAY_A);
    $json=wp_json_encode($out);if(!$json||strlen($json)>100*1024*1024)alpha_fail('Backup exceeds 100MB; use a full host database backup.');if(file_put_contents($path,$json,LOCK_EX)===false)alpha_fail('Backup write failed.');chmod($path,0600);
}
function alpha_backup_restore($path){
    global $wpdb;if(!is_readable($path)||filesize($path)>100*1024*1024)alpha_fail('Backup missing or exceeds 100MB.');
    $data=json_decode(file_get_contents($path),true);if(!is_array($data)||($data['version']??'')!==ALPHA_VERSION||array_diff(alpha_backup_tables(),array_keys($data['tables']??[])))alpha_fail('Backup version/tables invalid.');
    return alpha_tx(function()use($data,$wpdb){foreach(alpha_backup_tables() as $t){$rows=$data['tables'][$t];if(!is_array($rows))alpha_fail('Invalid table data.');$allowed=$wpdb->get_col('DESCRIBE '.alpha_table($t),0);foreach($rows as $row)if(!is_array($row)||array_diff(array_keys($row),$allowed))alpha_fail('Invalid columns.');alpha_dbcheck($wpdb->query('DELETE FROM '.alpha_table($t)));foreach($rows as $row)alpha_insert($t,$row);}return true;});
}
if(defined('WP_CLI')&&WP_CLI){
    WP_CLI::add_command('alpha backup',function($args){try{if(empty($args[0]))alpha_fail('Output file required.');alpha_backup_write($args[0]);WP_CLI::success('Alpha records and private files saved; WordPress users/config require a separate host backup.');}catch(Throwable $e){WP_CLI::error($e->getMessage());}});
    WP_CLI::add_command('alpha restore',function($args){WP_CLI::confirm('Replace Alpha records? Use only with the same WordPress user database.');try{if(empty($args[0]))alpha_fail('Backup file required.');alpha_backup_restore($args[0]);WP_CLI::success('Alpha records restored.');}catch(Throwable $e){WP_CLI::error('Restore failed and was rolled back: '.$e->getMessage());}});
}

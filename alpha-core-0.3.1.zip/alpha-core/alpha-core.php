<?php
/**
 * Plugin Name: Alpha Core | هسته مشاوران آلفا
 * Description: هسته، دسترسی‌ها، پایگاه داده و پنل React سامانه آلفا.
 * Version: 0.3.1
 * Requires at least: 6.5
 * Requires PHP: 8.0
 */
defined('ABSPATH') || exit;
define('ALPHA_VERSION', '0.3.1');
require_once __DIR__.'/includes/domain.php';
require_once __DIR__.'/includes/schema.php';
require_once __DIR__.'/includes/overview.php';
require_once __DIR__.'/includes/workflow.php';
register_activation_hook(__FILE__, 'alpha_activate');
add_action('rest_api_init', function(){
    alpha_route('/me', 'GET', function(){
        $u=wp_get_current_user();return ['id'=>$u->ID,'name'=>$u->display_name,'caps'=>array_values(array_filter(alpha_caps(),fn($c)=>current_user_can($c))),'modules'=>apply_filters('alpha_modules',[]),'currency'=>'IRR'];
    },'alpha_access');
    alpha_route('/files', 'POST', 'alpha_upload', 'alpha_access');
    alpha_route('/accounts','GET',function($r){$q=alpha_text($r['q']??'',100);if(mb_strlen($q)<3)return [];return array_map(fn($u)=>['id'=>$u->ID,'name'=>$u->display_name,'login'=>$u->user_login,'roles'=>array_values(array_filter($u->roles,fn($role)=>str_starts_with($role,'alpha_')))],get_users(['search'=>'*'.$q.'*','search_columns'=>['user_login','display_name','user_email'],'number'=>20,'role__not_in'=>['administrator']]));},'alpha_manage');
    alpha_route('/accounts/(?P<id>\d+)/role','POST',function($r){$u=get_userdata((int)$r['id']);$role=$r['role'];if(!$u||user_can($u,'manage_options'))alpha_fail('تغییر این حساب مجاز نیست.',403);if(!in_array($role,['alpha_manager','alpha_reception','alpha_finance','alpha_consultant','alpha_student'],true))alpha_fail('نقش معتبر نیست.');foreach($u->roles as $old)if(str_starts_with($old,'alpha_'))$u->remove_role($old);$u->add_role($role);alpha_audit('account',$u->ID,'role_assigned',['role'=>$role]);return ['ok'=>true];},'alpha_manage');

    do_action('alpha_register_routes');
});
add_action('admin_post_alpha_file','alpha_download');
// The Alpha application is frontend-only. Keep the legacy admin URL as a redirect.
add_action('admin_init', function () {
    if (is_admin() && isset($_GET['page']) && sanitize_key(wp_unslash($_GET['page'])) === 'alpha-panel') {
        wp_safe_redirect(home_url('/alpha-panel/'));
        exit;
    }
});

// Keep capabilities in sync on upgrades, without changing existing user roles.
add_action('init', function () {
    if (get_option('alpha_core_portal_version') !== ALPHA_VERSION) {
        $admin = get_role('administrator');
        if ($admin) foreach (alpha_caps() as $cap) $admin->add_cap($cap);
        update_option('alpha_core_portal_version', ALPHA_VERSION, false);
    }
}, 5);

// Provision a dedicated frontend page only if it does not already exist.
function alpha_ensure_portal_page() {
    $existing = get_page_by_path('alpha-panel');
    if (!$existing) {
        wp_insert_post([
            'post_title' => 'پنل آلفا',
            'post_name' => 'alpha-panel',
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_content' => '[alpha_panel]',
            'comment_status' => 'closed',
        ]);
    }
}
add_action('init', function () {
    if (get_option('alpha_portal_page_provisioned') !== '0.2.5') {
        alpha_ensure_portal_page();
        update_option('alpha_portal_page_provisioned', '0.2.5', false);
    }
}, 20);

/** Determine whether the signed-in account already has an Alpha intake record. */
function alpha_has_completed_intake($user_id) {
    global $wpdb;
    $user_id = absint($user_id);
    if (!$user_id) return false;
    $table = alpha_table('leads');
    // A submitted lead (including pending review) is considered completed.
    $found = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE user_id = %d LIMIT 1", $user_id));
    // Only activated student profiles enter the dashboard.
    if (current_user_can('alpha_booking') || current_user_can('alpha_admissions') || current_user_can('alpha_consult') || current_user_can('alpha_finance')) return true;
    // Existing student profiles also count, even if the lead was imported.
    $students = alpha_table('students');
    return (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$students} WHERE user_id = %d LIMIT 1", $user_id));
}

function alpha_assets($atts=[]){
    static $prepared=false;if($prepared)return;$prepared=true;
    wp_enqueue_style('alpha-panel',plugins_url('assets/app.css',__FILE__),[],ALPHA_VERSION);
    wp_enqueue_script('alpha-booking-manager',plugins_url('assets/booking-manager.js',__FILE__),[],ALPHA_VERSION,true);
    wp_enqueue_style('alpha-booking-manager',plugins_url('assets/booking-manager.css',__FILE__),[],ALPHA_VERSION);
    wp_enqueue_script('alpha-panel',plugins_url('assets/app.js',__FILE__),['alpha-booking-manager'],ALPHA_VERSION,true);
    wp_enqueue_style('alpha-jalali-booking',plugins_url('assets/jalali-booking.css',__FILE__),[],ALPHA_VERSION);
    wp_enqueue_script('alpha-jalali-booking',plugins_url('assets/jalali-booking.js',__FILE__),['alpha-panel'],ALPHA_VERSION,true);
    $login=get_option('alpha_login_url',home_url('/login/'));
    $config=['api'=>esc_url_raw(rest_url('alpha/v1/')),'nonce'=>wp_create_nonce('wp_rest'),'loggedIn'=>is_user_logged_in(),'login'=>add_query_arg('r',get_permalink()?:home_url('/alpha-panel/'),$login),'intake'=>home_url('/alpha-intake/'),'companyName'=>get_option('alpha_company_name','مشاوران آلفا'),'home'=>home_url('/'),'assets'=>plugins_url('assets/',__FILE__),'manageBooking'=>current_user_can('alpha_booking'),'resume'=>is_user_logged_in()?alpha_resume_state():null,'public'=>!empty($atts['public']) || (is_user_logged_in() && !current_user_can('manage_options') && !alpha_has_completed_intake(get_current_user_id()))];
    wp_add_inline_script('alpha-panel','window.ALPHA='.wp_json_encode($config).';','before');
}
function alpha_shortcode($atts=[]){
    if (!is_user_logged_in() && empty($atts['public'])) {
        if (shortcode_exists('alpha_sms_login')) return '<div class="alpha-mobile-auth">'.do_shortcode('[alpha_sms_login]').'</div>';
        return '<div class="alpha-mobile-auth" dir="rtl"><p>برای ورود با شماره موبایل، افزونه Alpha SMS Login را فعال کنید.</p></div>';
    }
    alpha_assets($atts);
    return '<div id="alpha-panel" dir="rtl"><p>در حال آماده‌سازی پنل آلفا…</p></div>';
}
add_shortcode('alpha_panel','alpha_shortcode');
add_shortcode('alpha_intake',fn()=>alpha_shortcode(['public'=>true]));
add_action('wp_login',function(){/* Existing OTP owns identity. Alpha never creates a parallel login session. */},10,0);
add_action('template_redirect',function(){if(is_page(['alpha-panel','alpha-intake'])){if(!defined('DONOTCACHEPAGE'))define('DONOTCACHEPAGE',true);nocache_headers();do_action('litespeed_control_set_nocache','Alpha private workflow');}});
add_filter('template_include',function($template){return is_page(['alpha-panel','alpha-intake'])?__DIR__.'/templates/portal.php':$template;},99);

add_action('wp_enqueue_scripts',function(){if(is_page(['alpha-panel','alpha-intake']) && (is_user_logged_in() || is_page('alpha-intake')))alpha_assets(['public'=>is_page('alpha-intake')]);});
add_filter('wp_robots',function($robots){if(is_page(['alpha-panel','alpha-intake'])){$robots['noindex']=true;$robots['nofollow']=true;}return $robots;});

// Hide header buttons added by the theme snippet until WordPress confirms login.
add_action('wp_head', function () {
    echo '<style id="alpha-panel-header-visibility">body:not(.logged-in) .alpha-panel-header-btn { display: none !important; }</style>' . "\n";
});

// Canonical destination for the custom header button, including older snippets.
add_action('wp_footer', function () {
    if (is_admin() || is_page(['alpha-panel', 'alpha-intake'])) return;
    $url = home_url('/alpha-panel/');
    ?>
    <script>
    (function(){
      const url = <?php echo wp_json_encode(esc_url($url)); ?>;
      function fixLinks(){
        document.querySelectorAll('a.alpha-panel-header-btn').forEach(function(a){a.href=url;});
      }
      if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',fixLinks);
      else fixLinks();
      window.addEventListener('load',fixLinks);
    })();
    </script>
    <?php
}, 100);

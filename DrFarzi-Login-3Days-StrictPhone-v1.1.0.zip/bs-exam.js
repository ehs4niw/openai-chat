/* آزمون‌ساز استادیار v2.0 */
(function () {
  var C = window.BSE || {}, root = document.getElementById('bse-app');
  if (!root) return;
  root.classList.add('bse');
  if(!document.getElementById('bse-editor-v38')){var editorStyle=document.createElement('style');editorStyle.id='bse-editor-v38';editorStyle.textContent="/* Version 3.8: scoped editor layout only. */\n.bse .bse-type-chooser{container-type:inline-size}\n.bse .bse-type-chooser>h1{margin:0 0 24px;font-size:25px;font-weight:850;color:#142b55}\n.bse .bse-type-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:22px;direction:rtl}\n.bse .bse-type-card{--type-accent:#1672ff;--type-soft:#e4f0ff;position:relative;display:flex;flex-direction:column;align-items:stretch;min-height:270px;padding:28px 24px 24px;border:1px solid #dce7fa;border-top:4px solid var(--type-accent);border-radius:18px;background:linear-gradient(145deg,#fff,#edf5ff);box-shadow:0 8px 22px #1e438008;overflow:hidden}\n.bse .bse-type-card.is-multi{--type-accent:#7540e8;--type-soft:#eae0ff;border-color:#e6ddfa;border-top-color:var(--type-accent);background:linear-gradient(145deg,#fff,#f3eeff)}\n.bse .bse-type-card .bse-type-tag{position:absolute;top:22px;left:22px;padding:4px 13px;border-radius:30px;background:var(--type-soft);color:var(--type-accent);font-size:12px;font-weight:750}\n.bse .bse-type-icon{display:flex;align-items:center;justify-content:center;width:62px;height:62px;margin:0 0 16px;border-radius:17px;background:var(--type-soft);color:var(--type-accent)}\n.bse .bse-type-icon .bse-i{width:33px;height:33px}\n.bse .bse-type-card h2{font-size:21px;line-height:1.7;margin:0 0 8px;color:#142b55;font-weight:850}\n.bse .bse-type-card p{font-size:13px;line-height:1.9;margin:0 0 22px;color:#586981}\n.bse .bse-type-card>.bse-btn{margin-top:auto;min-height:46px;font-size:13px}\n.bse .bse-type-back{display:flex;justify-content:flex-start;margin-top:20px}\n.bse .bse-top-schedule-title{font-size:14px;font-weight:800;margin:20px 0 12px;padding-top:15px;border-top:1px solid #e5eaf2;line-height:1.8}\n.bse .bse-first-info{overflow:visible;position:relative;z-index:3}\n.bse .bse-first-info .bse-cal{z-index:1000;max-width:calc(100vw - 32px)}\n.bse .bsem-form .bsem-general .bse-top-schedule-title{margin:18px 0 0;font-size:13px}\n@container(max-width:620px){.bse .bse-type-grid{grid-template-columns:minmax(0,1fr);gap:16px}.bse .bse-type-card{min-height:255px;padding:24px 20px}.bse .bse-type-chooser>h1{font-size:22px}}\n@media(max-width:600px){.bse .bse-type-grid{grid-template-columns:minmax(0,1fr)}.bse .bse-type-card{min-height:255px}}\n";document.head.appendChild(editorStyle);}
  var S = { off: 0, timer: null, ov: null, mdl: [] };
  var ST = { upcoming: 'هنوز شروع نشده', running: 'در حال برگزاری', ended: 'پایان‌یافته' };
  var STC = { upcoming: 'soon', running: 'live', ended: 'closed' };
  var MON = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];

  /* ---------- آیکن‌ها ---------- */
  var IC = {
    clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    list: '<path d="m3 17 2 2 4-4"/><path d="m3 7 2 2 4-4"/><path d="M13 6h8"/><path d="M13 12h8"/><path d="M13 18h8"/>',
    cal: '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
    back: '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
    chl: '<path d="m15 18-6-6 6-6"/>',
    chr: '<path d="m9 18 6-6-6-6"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    minus: '<path d="M5 12h14"/>',
    trophy: '<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/>',
    crown: '<path d="m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7z"/><path d="M5 20h14"/>',
    copy: '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
    edit: '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
    eye: '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
    ext: '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
    sheet: '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
    info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
    chart: '<line x1="12" x2="12" y1="20" y2="10"/><line x1="18" x2="18" y1="20" y2="4"/><line x1="6" x2="6" y1="20" y2="16"/>',
    play: '<polygon points="6 3 20 12 6 21 6 3"/>',
    file: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
    down: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
    refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
    megaphone: '<path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
    sparkles: '<path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3Z"/>',
    more: '<circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/>',
    share: '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
    star: '<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>'
  };
  function ico(n, c) {
    var d = document.createElement('div');
    d.innerHTML = '<svg class="bse-i ' + (c || '') + '" viewBox="0 0 24 24" aria-hidden="true">' + (IC[n] || '') + '</svg>';
    return d.firstChild;
  }

  /* ---------- ابزارها ---------- */
  function fa(x) { return String(x).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.charAt(d); }); }
  /* عدد با حداکثر d رقم اعشار (رو به پایین)، مثل کارنامه‌ی وبلایت. منفی هم نمایش داده می‌شود */
  function fn(n, d) {
    n = Math.round((+n || 0) * 100) / 100;
    var neg = n < 0, s = Math.abs(n).toFixed(2);
    if (d === 1) s = s.slice(0, -1); else if (d === 0) s = s.slice(0, -3);
    if (s.indexOf('.') > -1) s = s.replace(/0+$/, '').replace(/\.$/, '');
    return (neg && parseFloat(s) > 0 ? '\u200E\u2212' : '') + fa(s).replace('.', '٫');
  }
  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function dt(t) { return new Date(t * 1000).toLocaleString('fa-IR-u-ca-persian', { calendar: 'persian', timeZone: C.timezone || 'Asia/Tehran', dateStyle: 'medium', timeStyle: 'short', hour12: false }); }
  function now() { return Math.floor(Date.now() / 1000) + S.off; }
  function mm(s) {
    s = Math.max(0, s);
    var h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), c = s % 60;
    return fa((h ? p2(h) + ':' : '') + p2(m) + ':' + p2(c));
  }
  function hms(s) {
    s = Math.max(0, Math.round(s));
    return fa(p2(Math.floor(s / 3600)) + ':' + p2(Math.floor(s % 3600 / 60)) + ':' + p2(s % 60));
  }
  function h(t, a, k) {
    var e = document.createElement(t); a = a || {};
    for (var i in a) {
      if (i === 'class') e.className = a[i];
      else if (i === 'text') e.textContent = a[i];
      else if (i.slice(0, 2) === 'on') e.addEventListener(i.slice(2), a[i]);
      else e.setAttribute(i, a[i]);
    }
    (k || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      e.appendChild(c.nodeType ? c : document.createTextNode(String(c)));
    });
    return e;
  }
  function btn(t, c, f, ic) { return h('button', { type: 'button', class: 'bse-btn ' + (c || ''), onclick: f }, [ic ? ico(ic) : null, t]); }
  function link(t, href, c, ic) { return h('a', { class: 'bse-btn ' + (c || ''), href: href }, [ic ? ico(ic) : null, t]); }
  function stat(x) { var n = now(); return n < x.st ? 'upcoming' : n < x.en ? 'running' : 'ended'; }
  function eU(id) { return (C.mgr ? '#/p/' : '#/e/') + id; }
  function dur2(s) { s = Math.max(0, +s || 0); return s < 60 ? fa(Math.round(s)) + ' ثانیه' : fn(s / 60, 1) + ' دقیقه'; }
  function shortName(nm) { var p = String(nm || '').trim().split(/\s+/); return p.length < 2 ? p[0] || '' : p[0] + ' ' + p[p.length - 1].charAt(0) + '.'; }
  function stBadge(k, big) { return h('span', { class: 'bse-st ' + STC[k] + (big ? ' big' : '') }, [h('i'), ST[k]]); }
  function tagBadge(c, t) { return h('span', { class: 'bse-st ' + c }, [h('i'), t]); }
  var AVC = ['#0284c7', '#16a36a', '#745dde', '#e59a21', '#dd4b59', '#0d9488'];
  function avc(s) { var n = 0, i; s = String(s || '?'); for (i = 0; i < s.length; i++) n += s.charCodeAt(i); return AVC[n % AVC.length]; }
  function avatar(name, me) {
    return h('div', { class: 'bse-pav' + (me ? ' me' : ''), style: 'background:' + avc(name), text: String(name || '؟').charAt(0) });
  }
  function toast(m, bad) {
    var t = h('div', { class: 'bse bse-toast' + (bad === false ? '' : ' bad'), text: m });
    document.body.appendChild(t);
    setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 3600);
  }

  /* ---------- صفحه‌ی اصلی، تمام‌صفحه و پنجره ---------- */
  function unOv() {
    clearInterval(S.timer);
    S.mdl.slice().forEach(function (c) { c(); });
    if (S.ov && S.ov.parentNode) S.ov.parentNode.removeChild(S.ov);
    S.ov = null;
    document.documentElement.classList.remove('bse-lock');
  }
  function mount(n) { unOv(); root.textContent = ''; root.appendChild(n); window.scrollTo(0, 0); }
  function overlay(kids) {
    unOv(); root.textContent = '';
    var o = h('div', { class: 'bse bse-ov' }, kids);
    document.body.appendChild(o); S.ov = o;
    document.documentElement.classList.add('bse-lock');
  }
  function modal(o) {
    var bd = h('div', { class: 'bse bse-mbd' }), closed = false;
    function key(e) { if (e.key === 'Escape') close(); }
    function close() {
      if (closed) return; closed = true;
      document.removeEventListener('keydown', key);
      if (bd.parentNode) bd.parentNode.removeChild(bd);
      var i = S.mdl.indexOf(close); if (i > -1) S.mdl.splice(i, 1);
    }
    var ok = btn(o.ok || 'تأیید', o.danger ? 'dng' : 'pri', function () { close(); if (o.onok) o.onok(); });
    var kids = [h('span', { class: 'bse-mic' + (o.danger ? ' d' : '') }, [ico(o.icon || 'info')]), h('h2', { text: o.title })]
      .concat(o.body || [], [h('div', { class: 'bse-mac' }, [ok, btn(o.cancel || 'بازگشت', 'gh', close)])]);
    bd.appendChild(h('div', { class: 'bse-mdl', role: 'dialog' }, kids));
    bd.addEventListener('mousedown', function (e) { if (e.target === bd) close(); });
    document.addEventListener('keydown', key);
    document.body.appendChild(bd); S.mdl.push(close);
    return close;
  }
  function rules(lines) { return h('div', { class: 'bse-rules' }, lines.map(function (t) { return h('p', {}, [ico('check'), t]); })); }

  /* ---------- ارتباط با سرور ---------- */
  // Refresh an expired request nonce without replacing the exam or extending its deadline.
  var authRefresh = null, authNotice = null;
  function showAuthNotice(message) {
    if (!authNotice) {
      authNotice = h('div', {role:'alert', style:'position:fixed;top:12px;left:12px;right:12px;z-index:2147483647;background:#fff3cd;color:#402b00;padding:16px;border:1px solid #bb8b00;border-radius:8px;direction:rtl'});
      document.body.appendChild(authNotice);
    }
    authNotice.textContent = message + ' ';
    var a=h('a',{href:C.login||'/my-account/',target:'_blank',rel:'noopener',text:'ورود در تب جدید'});
    authNotice.appendChild(a);
  }
  function freshExamAuth() {
    if(authRefresh)return authRefresh;
    var f=new FormData();f.append('action','bse_boot');
    var ctl=typeof AbortController!=='undefined'?new AbortController():null;
    var t=setTimeout(function(){if(ctl)ctl.abort();},8000);
    authRefresh=fetch(C.ajax,{method:'POST',body:f,credentials:'same-origin',cache:'no-store',signal:ctl?ctl.signal:undefined})
      .then(function(r){if(!r.ok)throw new Error('bootstrap failed');return r.json();})
      .then(function(j){
        if(!j||!j.success||!j.data)throw new Error('invalid bootstrap');
        var b=j.data;
        if(!b.in||!b.uid){showAuthNotice('ورود شما منقضی شده است؛ این تب را باز نگه دارید و با همان حساب دوباره وارد شوید. زمان آزمون متوقف نمی‌شود.');throw new Error('login required');}
        if((+C.uid||0)!==(+b.uid||0)){showAuthNotice('حساب ورود تغییر کرده است؛ برای حفظ پاسخ‌ها با حساب قبلی وارد شوید.');throw new Error('account changed');}
        if(!b.nonce)throw new Error('missing nonce');
        C.nonce=b.nonce;
        if(authNotice){authNotice.remove();authNotice=null;}
        return b.nonce;
      });
    authRefresh=authRefresh.then(function(n){clearTimeout(t);authRefresh=null;return n;},function(e){clearTimeout(t);authRefresh=null;throw e;});
    return authRefresh;
  }
  function post(fd, cb, quiet, err, retried) {
    var upload=fd.get('action')==='bse_up',file=upload?fd.get('f'):null,httpStatus=0;
    function reject(message){if(!quiet)toast(message);if(err)err(message);}
    function problem(message){var e=new Error(message);e.bseMessage=message;return e;}
    function sizeMB(bytes){return fn(bytes/1048576,2)+' مگابایت';}
    if(upload&&file&&C.upload_max>0&&file.size>C.upload_max){reject('حجم فایل '+sizeMB(file.size)+' است؛ حداکثر مجاز فعلی هاست '+sizeMB(C.upload_max)+' است. محدودیت آپلود باید در تنظیمات هاست افزایش یابد.');return;}
    var controller=typeof AbortController!=='undefined'?new AbortController():null;
    var timeout=setTimeout(function(){if(controller)controller.abort();},upload?120000:(fd.get('op')==='mrank_pdf'?30000:8000));
    var url=C.ajax;
    // Keep routing and nonce readable even if PHP discards an oversized POST body.
    if(upload)url+=(url.indexOf('?')<0?'?':'&')+'action=bse_up&n='+encodeURIComponent(C.nonce||'');
    fetch(url,{method:'POST',body:fd,credentials:'same-origin',signal:controller?controller.signal:undefined,cache:'no-store'})
      .then(function(r){
        httpStatus=r.status||200;
        if(httpStatus===413)throw problem('سرور حجم درخواست آپلود را رد کرد (HTTP 413). سقف upload_max_filesize، post_max_size یا محدودیت وب‌سرور باید بررسی و افزایش داده شود.');
        return r.json().catch(function(){
          if(httpStatus===403)throw problem('سرور اجازهٔ این درخواست را نداد (HTTP 403). صفحه را تازه کنید؛ اگر تکرار شد، محدودیت امنیتی یا فایروال هاست باید بررسی شود.');
          if(httpStatus>=500)throw problem('خطای سرور هنگام '+(upload?'آپلود':'پردازش درخواست')+' (HTTP '+httpStatus+').');
          throw problem('پاسخ سرور قابل خواندن نبود (HTTP '+httpStatus+').');
        });
      })
      .then(function(j){
        clearTimeout(timeout);
        if(j&&j.success){cb(j.data);return;}
        var action=fd.get('action');
        if(!retried && (j===-1||j==='-1'||j===0||j==='0') && ['bse','bse_preview','bse_practice'].indexOf(action)!==-1){
          freshExamAuth().then(function(n){fd.set('n',n);post(fd,cb,quiet,err,true);},function(){reject('ذخیره تأیید نشد؛ اتصال و وضعیت ورود را بررسی کنید. این تب را نبندید.');});
          return;
        }
        var message;
        if(j===-1||j==='-1')message=upload?'اعتبار آپلود تمام شده است؛ صفحه را تازه کنید و دوباره فایل را انتخاب کنید.':'اعتبار درخواست تأیید نشد؛ پاسخ‌ها را حفظ کنید و وضعیت ورود را بررسی کنید.';
        else if(j===0||j==='0')message='درخواست به بخش آپلود نرسید؛ محدودیت حجم درخواست یا مسدودشدن admin-ajax.php را در هاست بررسی کنید.';
        else if(j&&typeof j.data==='string')message=j.data;
        else if(j&&j.data&&j.data.message)message=j.data.message;
        else if(j&&Array.isArray(j.data)&&j.data[0]&&j.data[0].message)message=j.data[0].message;
        else message='خطای '+(upload?'آپلود':'درخواست')+'؛ پاسخ ناموفق سرور'+(httpStatus?' (HTTP '+httpStatus+')':'')+'.';
        reject(message);
      })
      .catch(function(e){
        clearTimeout(timeout);
        if(e.name==='AbortError')reject(upload?'آپلود در ۱۲۰ ثانیه کامل نشد. اتصال اینترنت را بررسی و دوباره فایل را انتخاب کنید.':'سرور در مهلت درخواست پاسخ نداد؛ دوباره تلاش کنید.');
        else reject(e.bseMessage||'ارتباط با سرور برقرار نشد؛ اتصال اینترنت را بررسی و دوباره تلاش کنید.');
      });
  }
  function api(op, data, cb, quiet, err) {
    var f = new FormData();
    f.append('action', 'bse'); f.append('n', C.nonce); f.append('op', op);
    for (var k in data || {}) f.append(k, data[k]);
    post(f, cb || function () {}, quiet, err);
  }

  /* ---------- تقویم شمسی ---------- */
  var BRK = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
  function dv(a, b) { return ~~(a / b); }
  function md(a, b) { return a - ~~(a / b) * b; }
  function jalCal(jy) {
    var gy = jy + 621, leapJ = -14, jp = BRK[0], jm, jump = 0, leap, leapG, march, n, i;
    for (i = 1; i < BRK.length; i++) {
      jm = BRK[i]; jump = jm - jp;
      if (jy < jm) break;
      leapJ = leapJ + dv(jump, 33) * 8 + dv(md(jump, 33), 4);
      jp = jm;
    }
    n = jy - jp;
    leapJ = leapJ + dv(n, 33) * 8 + dv(md(n, 33) + 3, 4);
    if (md(jump, 33) === 4 && jump - n === 4) leapJ += 1;
    leapG = dv(gy, 4) - dv((dv(gy, 100) + 1) * 3, 4) - 150;
    march = 20 + leapJ - leapG;
    if (jump - n < 6) n = n - jump + dv(jump + 4, 33) * 33;
    leap = md(md(n + 1, 33) - 1, 4);
    if (leap === -1) leap = 4;
    return { leap: leap, gy: gy, march: march };
  }
  function g2d(gy, gm, gd) {
    var d = dv((gy + dv(gm - 8, 6) + 100100) * 1461, 4) + dv(153 * md(gm + 9, 12) + 2, 5) + gd - 34840408;
    return d - dv(dv(gy + 100100 + dv(gm - 8, 6), 100) * 3, 4) + 752;
  }
  function d2g(jdn) {
    var j = 4 * jdn + 139361631, i, gd, gm, gy;
    j = j + dv(dv(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
    i = dv(md(j, 1461), 4) * 5 + 308;
    gd = dv(md(i, 153), 5) + 1;
    gm = md(dv(i, 153), 12) + 1;
    gy = dv(j, 1461) - 100100 + dv(8 - gm, 6);
    return { gy: gy, gm: gm, gd: gd };
  }
  function j2d(jy, jm, jd) {
    var r = jalCal(jy);
    return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - dv(jm, 7) * (jm - 7) + jd - 1;
  }
  function d2j(jdn) {
    var gy = d2g(jdn).gy, jy = gy - 621, r = jalCal(jy), jdn1f = g2d(gy, 3, r.march), k = jdn - jdn1f, jm, jd;
    if (k >= 0) {
      if (k <= 185) return { jy: jy, jm: 1 + dv(k, 31), jd: md(k, 31) + 1 };
      k -= 186;
    } else {
      jy -= 1; k += 179;
      if (r.leap === 1) k += 1;
    }
    jm = 7 + dv(k, 30); jd = md(k, 30) + 1;
    return { jy: jy, jm: jm, jd: jd };
  }
  function toJ(gy, gm, gd) { return d2j(g2d(gy, gm, gd)); }
  function toG(jy, jm, jd) { return d2g(j2d(jy, jm, jd)); }
  function jml(jy, jm) { return jm <= 6 ? 31 : jm <= 11 ? 30 : (jalCal(jy).leap === 0 ? 30 : 29); }
  function tsJ(ts) { var d = new Date(ts * 1000); return toJ(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
  if (window.BSE_TEST) window.BSE_JAL = { toJ: toJ, toG: toG, jml: jml };

  /* فیلد تاریخ شمسی + ساعت؛ cb(unix) یا cb(0) اگر کامل نباشد */
  function dtField(ts, cb) {
    var cur = ts ? tsJ(ts) : null;
    var tv = ts ? p2(new Date(ts * 1000).getHours()) + ':' + p2(new Date(ts * 1000).getMinutes()) : '';
    var td0 = tsJ(Math.floor(Date.now() / 1000));
    var view = cur ? { y: cur.jy, m: cur.jm } : { y: td0.jy, m: td0.jm };
    var pop = null;
    var bd = h('button', { type: 'button', class: 'bse-dfb', onclick: toggle });
    var hh = h('select', { 'aria-label': 'ساعت، از صفر تا ۲۳' });
    var mi = h('select', { 'aria-label': 'دقیقه، از صفر تا ۵۹' });
    hh.appendChild(h('option', { value: '', text: 'ساعت' }));
    mi.appendChild(h('option', { value: '', text: 'دقیقه' }));
    for (var hour = 0; hour < 24; hour++) hh.appendChild(h('option', { value: p2(hour), text: p2(hour) }));
    for (var minute = 0; minute < 60; minute++) mi.appendChild(h('option', { value: p2(minute), text: p2(minute) }));
    if (tv) { hh.value = tv.split(':')[0]; mi.value = tv.split(':')[1]; }
    function timeChanged() { tv = hh.value !== '' && mi.value !== '' ? hh.value + ':' + mi.value : ''; emit(); }
    hh.addEventListener('change', timeChanged); mi.addEventListener('change', timeChanged);
    var ti = h('div', { class: 'bse-time24', dir: 'ltr' }, [hh, h('span', { text: ':' }), mi]);
    var wrap = h('div', { class: 'bse-df' }, [bd, ti]);
    function lab() {
      bd.textContent = ''; bd.appendChild(ico('cal'));
      bd.appendChild(document.createTextNode(cur ? fa(cur.jy) + '/' + fa(p2(cur.jm)) + '/' + fa(p2(cur.jd)) : 'انتخاب تاریخ'));
    }
    function emit() {
      if (cur && tv) {
        var g = toG(cur.jy, cur.jm, cur.jd), t = tv.split(':');
        cb(Math.floor(new Date(g.gy, g.gm - 1, g.gd, +t[0], +t[1], 0).getTime() / 1000));
      } else cb(0);
    }
    function out(e) { if (pop && !wrap.contains(e.target)) close(); }
    function close() {
      if (pop && pop.parentNode) pop.parentNode.removeChild(pop);
      pop = null; document.removeEventListener('mousedown', out);
    }
    function toggle() { if (pop) { close(); return; } draw(); document.addEventListener('mousedown', out); }
    function mv(d) {
      view.m += d;
      if (view.m > 12) { view.m = 1; view.y++; }
      if (view.m < 1) { view.m = 12; view.y--; }
      draw();
    }
    function draw() {
      if (pop && pop.parentNode) pop.parentNode.removeChild(pop);
      var g1 = toG(view.y, view.m, 1), off = (new Date(g1.gy, g1.gm - 1, g1.gd).getDay() + 1) % 7, len = jml(view.y, view.m);
      var grid = h('div', { class: 'bse-cg' }), i;
      ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'].forEach(function (w) { grid.appendChild(h('span', { class: 'w', text: w })); });
      for (i = 0; i < off; i++) grid.appendChild(h('span'));
      for (i = 1; i <= len; i++) (function (d) {
        var c = h('button', { type: 'button', text: fa(d), onclick: function () {
          cur = { jy: view.y, jm: view.m, jd: d };
          if (!tv) { tv = '08:00'; ti.value = tv; }
          lab(); emit(); close();
        } });
        if (cur && cur.jy === view.y && cur.jm === view.m && cur.jd === d) c.className = 'on';
        else if (td0.jy === view.y && td0.jm === view.m && td0.jd === d) c.className = 'td';
        grid.appendChild(c);
      })(i);
      pop = h('div', { class: 'bse-cal' }, [
        h('div', { class: 'bse-ch' }, [
          h('button', { type: 'button', onclick: function () { mv(-1); }, 'aria-label': 'ماه قبل' }, [ico('chr')]),
          h('b', { text: MON[view.m - 1] + ' ' + fa(view.y) }),
          h('button', { type: 'button', onclick: function () { mv(1); }, 'aria-label': 'ماه بعد' }, [ico('chl')])]),
        grid]);
      wrap.appendChild(pop);
    }
    lab();
    return wrap;
  }

  /* ---------- پاسخ‌برگ موبایل ---------- */
  function mobShell(sheet, fabKids) {
    var bd = h('div', { class: 'bse-bd' });
    function tg(o) { sheet.classList.toggle('open', o); bd.classList.toggle('open', o); }
    bd.addEventListener('click', function () { tg(false); });
    var fab = h('button', { type: 'button', class: 'bse-fab', onclick: function () { tg(!sheet.classList.contains('open')); } }, fabKids);
    return { bd: bd, fab: fab, close: function () { tg(false); } };
  }
  function pdfFiles(d) {
    return Array.isArray(d.pdfs) && d.pdfs.length ? d.pdfs : (d.pdf ? [d.pdf] : []);
  }
  function pdfName(url, index) {
    try { return decodeURIComponent(url.split('?')[0].split('/').pop()) || 'فایل ' + fa(index + 1); }
    catch (e) { return 'فایل ' + fa(index + 1); }
  }
  function pdfViewer(d) {
    var groups = (Array.isArray(d.groups) && d.groups.length ? d.groups : [{ label: d.viewer_title || 'سؤالات آزمون', files: pdfFiles(d) }])
      .filter(function (g) { return g.files && g.files.length; });
    if (!groups.length) groups = [{ label: d.viewer_title || 'سؤالات آزمون', files: [] }];
    var gi = 0, files = groups[0].files, current = 0, tabBtns = [];
    var open = h('a', { class: 'bse-vl', target: '_blank', rel: 'noopener' }, [ico('ext'), 'باز کردن در تب جدید']);
    var download = h('a', { class: 'bse-vl bse-question-download', title: 'دانلود فایل در حال نمایش', 'aria-label': 'دانلود فایل در حال نمایش', download: '', style: 'display:inline-flex;align-items:center;padding:6px;' }, [ico('down')]);
    var frame = h('iframe', { class: 'bse-fr', title: groups[0].label });
    var select = h('select', { class: 'bse-in bse-pdf-select', 'aria-label': 'انتخاب فایل' });
    var picker = h('div', { class: 'bse-pdf-picker' }, [select]);
    var head = groups.length > 1
      ? h('div', { class: 'bse-vtabs', role: 'tablist' }, groups.map(function (g, i) {
          var b = h('button', { type: 'button', class: 'bse-vtab', role: 'tab', onclick: function () { setGroup(i); } }, [g.label]);
          tabBtns.push(b); return b;
        }))
      : h('span', { text: groups[0].label });
    function fillSelect() {
      select.textContent = '';
      files.forEach(function (url, i) { select.appendChild(h('option', { value: i, text: fa(i + 1) + '. ' + pdfName(url, i) })); });
      select.value = current;
      picker.style.display = files.length > 1 ? '' : 'none';
    }
    function activate() {
      var url = files[current]; if (!url) { frame.removeAttribute('src'); return; }
      open.href = url; download.href = url; download.download = pdfName(url, current);
      frame.src = url + '#toolbar=0&navpanes=0';
    }
    function setGroup(i) {
      gi = i; files = groups[i].files; current = 0; frame.title = groups[i].label;
      tabBtns.forEach(function (b, j) { b.classList.toggle('on', j === i); b.setAttribute('aria-selected', j === i ? 'true' : 'false'); });
      fillSelect(); activate();
    }
    download.addEventListener('click', function (e) {
      var url = files[current]; if (!url) return;
      if (new URL(url, location.href).origin === location.origin) return;
      e.preventDefault(); download.style.pointerEvents = 'none';
      fetch(url, { credentials: 'omit' }).then(function (r) { if (!r.ok) throw new Error('download'); return r.blob(); }).then(function (blob) {
        var u = URL.createObjectURL(blob), a = document.createElement('a'); a.href = u; a.download = pdfName(url, current); document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(u); }, 60000);
      }).catch(function () { toast('دانلود مستقیم از میزبان فایل ممکن نیست؛ از «باز کردن در تب جدید» و گزینه ذخیره مرورگر استفاده کنید'); }).finally(function () { download.style.pointerEvents = ''; });
    });
    select.addEventListener('change', function () { current = +this.value; activate(); });
    setGroup(0);
    return h('section', { class: 'bse-vw' }, [
      h('div', { class: 'bse-vt' }, [head, h('div', { style: 'display:flex;align-items:center;gap:10px;' }, [open, download])]),
      picker,
      h('div', { class: 'bse-stg' }, [frame])]);
  }
  function loadMk(id) { try { return JSON.parse(localStorage.getItem('bse_mk_' + id) || '{}') || {}; } catch (e) { return {}; } }
  function saveMk(id, M) { try { localStorage.setItem('bse_mk_' + id, JSON.stringify(M)); } catch (e) {} }

  /* ================= شرکت‌کننده ================= */

  /* ---------- لیست آزمون‌ها ---------- */
  function examRow(x, href, mgr) {
    var kids = [
      h('div', { class: 'bse-rm' }, [
        h('div', { class: 'bse-rt' }, [h('h3', { text: x.title }), stBadge(x.status), x.me === 'done' && !mgr ? tagBadge('done', 'شرکت کرده‌اید') : null, x.lock && !mgr ? tagBadge('closed', 'دسترسی تمام شده') : null]),
        h('div', { class: 'bse-rd' }, [h('span', {}, [ico('cal'), 'شروع: ' + dt(x.st)]), h('span', {}, [ico('cal'), 'پایان: ' + dt(x.en)])])]),
      h('div', { class: 'bse-mt' }, [h('small', { text: 'تعداد سؤال' }), h('b', {}, [ico('list'), fa(x.qn)])]),
      h('div', { class: 'bse-mt' }, [h('small', { text: 'مدت' }), h('b', {}, [ico('clock'), fa(x.dur) + ' دقیقه'])]),
      mgr ? h('div', { class: 'bse-mt' }, [h('small', { text: 'شرکت‌کننده' }), h('b', {}, [ico('users'), fa(x.n || 0)])]) : null,
      ico('chl', 'bse-ar')];
    return h('a', { class: 'bse-row', href: href }, kids);
  }
  function vList() {
    var box = h('div', { class: 'bse-list' });
    mount(h('div', { class: 'bse-wrap' }, [
      h('div', { class: 'bse-h' }, [h('div', {}, [h('h1', { text: 'آزمون‌ها' }), h('p', { text: 'آزمون‌های آنلاین؛ یکی را انتخاب کنید' })]),
        C.mgr ? link('مدیریت آزمون‌ها', '#/m', 'pri', 'edit') : null]), box]));
    api('list', {}, function (d) {
      if (!d.length) box.appendChild(h('div', { class: 'bse-empty' }, [h('b', { text: 'هنوز آزمونی ثبت نشده است' }), 'وقتی آزمونی منتشر شود، اینجا می‌بینید.']));
      d.forEach(function (x) { box.appendChild(examRow(x, '#/e/' + x.id, false)); });
    });
  }

  /* ---------- صفحه‌ی شروع آزمون ---------- */
  function askStart(x, id) {
    modal({
      icon: 'play', title: 'آماده‌ی شروع آزمون هستید؟', ok: 'شروع آزمون', cancel: 'بازگشت',
      body: [rules([
        x.neg ? 'پاسخ غلط ۱/۳ نمره منفی دارد.' : 'پاسخ غلط نمره منفی ندارد.',
        x.multi ? 'هر دفترچه زمان مستقل دارد؛ پس از تحویل یا پایان زمان آن، بازگشت ممکن نیست و زمان اضافه منتقل نمی‌شود.' : 'پاسخ‌ها خودکار ذخیره می‌شوند.',
        'مهلت شما حداکثر تا پایان زمان کلی آزمون است.',
        x.early_results ? 'نتیجه پس از پایان مدت پاسخ‌گویی شما منتشر می‌شود؛ ثبت زودتر، زمان انتشار را جلو نمی‌اندازد.' : 'نتیجه بعد از پایان مهلت شرکت در آزمون منتشر می‌شود.',
        x.early_results ? 'پس از پایان زمان شما، پاسخ‌نامه نیز باز می‌شود و رتبه تا پایان مهلت شرکت موقت است.' : 'مرور پاسخ‌ها پس از پایان مهلت شرکت فعال می‌شود.']),
        h('p', { class: 'bse-cn' }, ['با تأیید شما، زمان‌سنج ' + fa(x.dur) + ' دقیقه‌ای آزمون فوراً آغاز می‌شود.', h('br'), 'تا پیش از تأیید، زمان آزمون شما شروع نخواهد شد.'])],
      onok: function () { location.hash = '#/t/' + id; }
    });
  }
  function vInfo(id) {
    api('get', { id: id }, function (x) {
      S.off = x.now - Math.floor(Date.now() / 1000);
      var s0 = stat(x), cd = h('b', { text: mm(x.st - now()) }), act = h('div', { class: 'bse-ac' });
      if (x.lock) {
        act.appendChild(h('div', { class: 'bse-note', text: 'دسترسی شما به این آزمون تمام شده است. برای شرکت، محصول «' + x.lock.name + '» را دوباره بخرید.' }));
        act.appendChild(link('خرید محصول', x.lock.url, 'pri lg wide', 'plus'));
      } else if (x.me === 'done') {
        act.appendChild(link('مشاهده کارنامه', C.results_url || '/my-account/bse-results/', 'pri lg wide', 'trophy'));
        if (s0 === 'ended' || x.result_ready) act.appendChild(link('نفرات برتر', '#/b/' + id, 'gh wide', 'crown'));
      } else if (s0 === 'running') {
        if (x.me === 'going') act.appendChild(link('ادامه آزمون', '#/t/' + id, 'pri lg wide', 'play'));
        else act.appendChild(btn('شروع آزمون', 'pri lg wide', function () { askStart(x, id); }, 'play'));
      } else if (s0 === 'upcoming') {
        act.appendChild(h('span', { class: 'bse-btn pri lg wide off' }, ['شروع آزمون در ', cd]));
      } else {
        act.appendChild(h('span', { class: 'bse-btn gh lg wide off', text: 'زمان آزمون تمام شده است' }));
        act.appendChild(link('نفرات برتر', '#/b/' + id, 'gh wide', 'crown'));
      }
      if(x.practice_available)act.appendChild(link('آزمون تمرینی (نامحدود)',previewHash('info',id,'practice'),'pri lg wide','play'));
      var facts = [['list', 'تعداد سؤال', fa(x.qn) + ' سؤال'], ['clock', 'مدت پاسخ‌گویی', fa(x.dur) + ' دقیقه']];
      var kv = [['شروع آزمون', dt(x.st)], ['پایان مهلت شرکت', dt(x.en)], ['نمره منفی', x.neg ? 'دارد (هر ۳ غلط، ۱ نمره)' : 'ندارد']];
      if (x.until) kv.push(['دسترسی شما تا', dt(x.until)]);
      mount(h('div', { class: 'bse-pf' }, [
        h('div', { class: 'bse-ptop' }, [link('آزمون‌ها', '#/', 'gh sm', 'back')]),
        h('section', { class: 'bse-pc' }, [
          h('div', { class: 'bse-ts' }, [h('span', { class: 'bse-av', text: String(x.by || '؟').charAt(0) }), h('p', {}, [h('small', { text: 'برگزارکننده' }), h('b', { text: x.by || '—' })])]),
          h('div', { class: 'bse-cv' }, [stBadge(s0, true), h('h1', { text: x.title })]),
          h('div', { class: 'bse-fx' }, facts.map(function (f) { return h('div', {}, [ico(f[0]), h('small', { text: f[1] }), h('b', { text: f[2] })]); })),
          h('div', { class: 'bse-kv' }, kv.map(function (r) { return h('div', {}, [h('span', { text: r[0] }), h('b', { text: r[1] })]); })),
          act])]));
      S.timer = setInterval(function () {
        if (stat(x) !== s0) { vInfo(id); return; }
        if (s0 === 'upcoming') cd.textContent = mm(x.st - now());
      }, 500);
    });
  }

  /* Pending answers stay in this browser tab until acknowledged; never shared across users or attempts. */
  function answerDraft(id,mode,d,book){
    var user=+C.uid||0,from=+d.from||1,to=from+(+d.qn||0)-1;
    var key='bse_pending_'+user+'_'+id+'_'+(mode==='practice'?'practice':mode?'preview':'official')+'_'+(mode?previewToken(id,null,mode):'')+'_'+d.deadline+'_'+(book===undefined?'single':book);
    function clear(){if(!user)return;try{sessionStorage.removeItem(key);}catch(e){}}
    return {
      restore:function(A){
        if(!user)return false;
        try{
          var saved=JSON.parse(sessionStorage.getItem(key)||'null');
          if(!saved)return false;if(now()>=d.deadline){clear();return false;}
          var next={},changed=false;
          Object.keys(saved.answers||{}).forEach(function(k){var q=+k,v=+saved.answers[k];if(q>=from&&q<=to&&q%1===0&&v>=1&&v<=4&&v%1===0)next[q]=v;});
          for(var q=from;q<=to;q++)if((+A[q]||0)!==(+next[q]||0))changed=true;
          if(!changed){clear();return false;}
          Object.keys(A).forEach(function(k){delete A[k];});Object.keys(next).forEach(function(k){A[k]=next[k];});return true;
        }catch(e){return false;}
      },
      write:function(A){if(!user)return;try{sessionStorage.setItem(key,JSON.stringify({answers:A}));}catch(e){}},
      clear:clear
    };
  }
  function saveRetryDelay(failures){return Math.min(30000,3000*Math.pow(2,Math.min(4,Math.max(0,failures-1))))+Math.floor(Math.random()*1000);}

  /* ---------- محیط آزمون ---------- */
  function vTake(id, preview) {
    (preview === 'practice' ? practiceApi : preview ? previewApi : api)('start', { id: id }, function (d) {
      if (d.over) { location.hash = preview ? previewHash('result',id,preview) : '#/r/' + id; return; }
      if (d.multi) { multiTake(id, d, preview); return; }
      S.off = d.now - Math.floor(Date.now() / 1000);
      var A = {}, M = loadMk(preview ? (preview==='practice'?'practice_':'preview_')+id+'_'+previewToken(id,null,preview) : id), qn = d.qn, dl = d.deadline, done = false, busy = false, dirty = false, finishing = false, tm = null, act = 0, k, rowEls = {}, lastSend = 0, retryAt = 0, failures = 0;
      for (k in d.answers) A[k] = d.answers[k];
      var clock = h('b'), tbox = h('div', { class: 'bse-tm' }, [ico('clock'), clock, h('small', { text: 'باقی‌مانده' })]);
      var fill = h('span'), hp = h('p'), hn = h('span'), fabN = h('span'), fabM = h('em');
      function upd() {
        var n = Object.keys(A).length, m = Object.keys(M).length;
        hp.textContent = fa(n) + ' از ' + fa(qn) + ' پاسخ داده شده' + (m ? ' · ' + fa(m) + ' نشان‌دار' : '');
        hn.textContent = fa(n) + '/' + fa(qn);
        fill.style.width = (n / qn * 100) + '%';
        fabN.textContent = fa(n) + '/' + fa(qn);
        fabM.textContent = m ? '★ ' + fa(m) : '';
      }
      var saveStatus = h('small', { role: 'status', 'aria-live': 'polite', text: 'پاسخ‌ها ذخیره شده‌اند' });
      var draft=answerDraft(id,preview,d);dirty=draft.restore(A);
      function active(){return !done&&S.ov&&S.ov.contains(sheet);}
      function goResult() {
        done=true;draft.clear();clearTimeout(tm);clearInterval(S.timer);
        location.hash=preview?previewHash('result',id,preview):'#/r/'+id;
      }
      function plan(){
        if(!active()||busy)return;
        if(dirty&&!finishing&&retryAt<=Date.now()&&dl-now()<=2){clearTimeout(tm);tm=null;sendAnswers(true);return;}
        if(tm!==null)return;
        var wait=Math.max(retryAt-Date.now(),finishing?0:lastSend+2500-Date.now(),finishing?0:1000);
        tm=setTimeout(function(){tm=null;sendAnswers();},Math.max(0,wait));
      }
      function sendAnswers(force){
        if(!active()||busy||(!dirty&&!finishing))return;
        if(!force&&retryAt>Date.now()){plan();return;}
        clearTimeout(tm);tm=null;busy=true;dirty=false;lastSend=Date.now();
        var finalRequest=finishing;
        saveStatus.textContent=finalRequest?'در حال ثبت نهایی پاسخ‌ها…':'در حال ذخیره…';
        (preview==='practice'?practiceApi:preview?previewApi:api)(finalRequest?'submit':'save',{id:id,answers:JSON.stringify(A)},function(r){
          busy=false;if(!active())return;failures=0;retryAt=0;
          if(r&&r.over){goResult();return;}
          if(!dirty)draft.clear();
          if(!finishing&&now()>=dl){finish();return;}
          saveStatus.textContent=dirty?'پاسخ‌های تازه در انتظار ذخیره‌اند…':'پاسخ‌ها ذخیره شده‌اند';
          if(finishing)sendAnswers(true);else if(dirty)plan();
        },true,function(){
          busy=false;if(!active())return;dirty=true;failures++;
          retryAt=Date.now()+saveRetryDelay(failures);
          saveStatus.textContent='ذخیره روی سرور تأیید نشد؛ با فاصله دوباره تلاش می‌کنیم. صفحه را نبندید.';
          if(finishing&&!finalRequest)sendAnswers(true);else plan();
        });
      }
      function later(){dirty=true;draft.write(A);saveStatus.textContent='پاسخ‌های تازه در انتظار ذخیره‌اند…';plan();}
      function finish(){
        if(done||finishing)return;finishing=true;clearTimeout(tm);tm=null;retryAt=0;
        S.mdl.slice().forEach(function(close){close();});sheet.querySelectorAll('button').forEach(function(b){b.disabled=true;});
        sendAnswers(true);
      }
      function askSubmit() {
        var n = Object.keys(A).length, blank = qn - n, m = Object.keys(M).length;
        var lines = [fa(n) + ' سؤال پاسخ داده شده است.'];
        if (blank) lines.push(fa(blank) + ' سؤال بدون پاسخ است.');
        if (m) lines.push(fa(m) + ' سؤال نشان‌دار دارید.');
        modal({ icon: 'check', title: 'ثبت نهایی پاسخ‌ها؟', ok: 'ثبت نهایی', cancel: 'بازگشت به آزمون',
          body: [rules(lines), h('p', { class: 'bse-cn', text: 'بعد از ثبت نهایی امکان ویرایش پاسخ‌ها وجود ندارد.' })], onok: finish });
      }
      var scroll = h('div', { class: 'bse-shs' });
      for (var i = 1; i <= qn; i++) (function (i) {
        var nb = h('button', { type: 'button', class: 'bse-qn', title: 'نشان‌دار کردن سؤال', text: fa(i) });
        var bs = [1, 2, 3, 4].map(function (o) {
          return h('button', { type: 'button', text: fa(o), onclick: function () {
            if (done || finishing || now() >= dl) { finish(); return; }
            if (A[i] === o) delete A[i]; else A[i] = o;
            setAct(i); paint(); upd(); later();
          } });
        });
        var row = h('div', { class: 'bse-sq' }, [nb, h('div', { class: 'bse-og' }, bs)]);
        function paint() {
          bs.forEach(function (b, j) { b.classList.toggle('sel', A[i] === j + 1); });
          nb.classList.toggle('mk', !!M[i]); row.classList.toggle('mk', !!M[i]);
        }
        nb.addEventListener('click', function () {
          if (M[i]) delete M[i]; else M[i] = 1;
          saveMk(preview ? (preview==='practice'?'practice_':'preview_')+id+'_'+previewToken(id,null,preview) : id, M); setAct(i); paint(); upd();
        });
        rowEls[i] = row; paint(); scroll.appendChild(row);
      })(i);
      function setAct(i) {
        if (rowEls[act]) rowEls[act].classList.remove('act');
        act = i; if (rowEls[i]) rowEls[i].classList.add('act');
      }
      var sheet = h('aside', { class: 'bse-sh' });
      var mob = mobShell(sheet, [h('b', {}, [ico('sheet'), 'پاسخ‌برگ']), h('span', {}, [fabM, fabN])]);
      sheet.appendChild(h('div', { class: 'bse-shh', onclick: mob.close }, [h('i'), h('div', {}, [h('b', { text: 'پاسخ‌برگ' }), h('small', { text: 'برای بستن بزنید' })])]));
      sheet.appendChild(h('div', { class: 'bse-shd' }, [h('div', {}, [h('h2', { text: 'پاسخ‌برگ' }), hp]), hn]));
      sheet.appendChild(scroll);
      sheet.appendChild(saveStatus);
      sheet.appendChild(h('div', { class: 'bse-shf' }, [btn('ثبت نهایی پاسخ‌ها', 'pri wide', askSubmit, 'check')]));
      upd();
      overlay([
        h('header', { class: 'bse-ah' }, [h('div', { class: 'bse-at' }, [h('b', { text: (preview==='practice'?'آزمون تمرینی · ':preview?'پیش‌نمایش · ':'') + d.title }), h('span', { text: fa(qn) + ' سؤال' })]), tbox]),
        h('div', { class: 'bse-pg' }, [fill]),
        h('div', { class: 'bse-lay' }, [pdfViewer(d), sheet]), mob.bd, mob.fab]);
      function tick() {
        var left = dl - now();
        clock.textContent = mm(left);
        tbox.classList.toggle('urg', left < 60);
        if(left>0&&left<=2&&dirty&&!finishing)plan(); if (left <= 0) finish();
      }
      S.timer = setInterval(tick, 500); tick(); if(dirty){saveStatus.textContent='پاسخ‌های ذخیره‌نشدهٔ این تب بازیابی شد؛ در انتظار ذخیره روی سرور…';plan();}
    }, false, function () { location.hash = preview ? previewHash('info',id,preview) : eU(id); });
  }

  /* ---------- کارنامه ---------- */
  function vResult(id, preview) {
    (preview === 'practice' ? practiceApi : preview ? previewApi : api)('result', { id: id }, function (d) {
      if (d.now) S.off = d.now - Math.floor(Date.now() / 1000);
      if (d.wait) {
        mount(h('div', { class: 'bse-pf' }, [
          h('div', { class: 'bse-ptop' }, [link('بازگشت', eU(id), 'gh sm', 'back')]),
          h('section', { class: 'bse-pc' }, [
            h('div', { class: 'bse-cv' }, [h('span', { class: 'bse-mic' }, [ico('check')]), h('h1', { text: d.pending ? 'در حال نهایی‌سازی آزمون' : 'پاسخ‌های شما ثبت شد' })]),
            h('div', { class: 'bse-kv' }, [h('div', {}, [h('span', { text: 'انتشار نتیجه و کارنامه' }), h('b', { text: dt(d.release) })])]),
            h('div', { class: 'bse-ac' }, [link('بازگشت به آزمون', eU(id), 'pri wide')])])]));
        S.timer = setInterval(function () { if (now() >= d.release) { clearInterval(S.timer); vResult(id,preview); } }, 1000);
        return;
      }
      var sc = Math.max(0, Math.min(100, d.pct));
      var box = [['check', 'g', 'پاسخ صحیح', fa(d.correct)], ['x', 'r', 'پاسخ غلط', fa(d.wrong)], ['minus', 'n', 'بدون پاسخ', fa(d.blank)], ['clock', 'b', 'زمان پاسخ‌گویی', mm(d.secs)]];
      mount(h('div', { class: 'bse-rp' }, [
        h('div', { class: 'bse-ptop' }, [link('آزمون‌ها', '#/', 'gh sm', 'back')]),
        d.practice ? practiceNotice() : d.preview ? previewNotice() : null,
        h('section', { class: 'bse-sc' }, [
          h('div', { class: 'bse-sct' }, [h('p', {}, [h('small', { text: 'نتیجه برای' }), h('b', { text: d.name || '' })]), h('small', { text: d.title })]),
          h('div', { class: 'bse-gg', style: '--score:' + sc + '%' }, [h('div', {}, [h('b', { text: fn(d.pct, 2) + '٪' }), h('small', { text: 'درصد کل' })])]),
          (d.preview || d.practice) ? null : h('div', { class: 'bse-rk' }, [ico('trophy'), h('span', {}, ['رتبه ', h('b', { text: fa(d.rank) }), d.temporary ? h('small', { class: 'bse-temporary', text: 'موقت' }) : null])])]),
        h('div', { class: 'bse-b4' }, box.map(function (r) {
          return h('div', {}, [h('span', { class: 'bse-ic ' + r[1] }, [ico(r[0])]), h('p', {}, [h('b', { text: r[3] }), h('small', { text: r[2] })])]);
        })),
        d.multi ? multiReport(d) : null,
        h('div', { class: 'bse-acts' }, [
          h('div', {}, [link('مشاهده پاسخ‌نامه و تحلیل', preview ? previewHash('answers',id,preview) : '#/a/' + id, 'grn', 'eye'), (d.preview || d.practice) ? null : link('نفرات برتر', '#/b/' + id, 'gh', 'crown')]),
          h('div', {}, [preview ? link(preview==='practice'?'تمرین دوباره':'پیش‌نمایش تازه',previewHash('info',id,preview),'gh','play') : link('بازگشت به آزمون', eU(id), 'gh'), link('همه‌ی آزمون‌ها', '#/', 'gh')])])]));
    });
  }

  /* ---------- پاسخ‌نامه و تحلیل ---------- */
  function vAnswers(id, uid, preview) {
    (preview === 'practice' ? practiceApi : preview ? previewApi : api)(uid ? 'mres' : 'result', uid ? { id: id, uid: uid } : { id: id }, function (d) {
      if (d.wait) { location.hash = preview ? previewHash('result',id,preview) : '#/r/' + id; return; }
      var list = h('div', {}), i;
      for (i = 1; i <= d.qn; i++) (function (i) {
        if (d.multi) (d.books || []).forEach(function (b) { b.subjects.forEach(function (s) { if (s.from === i) list.appendChild(h('h3', {class:'bsem-group',text:b.title+' / '+s.title+' · '+fn(s.pct,2)+'٪'})); }); });
        var mine = +d.mine[i] || 0, key = d.key ? +d.key[i - 1] : 0;
        var s = !mine ? 'blank' : mine === key ? 'correct' : 'wrong';
        var opts = [1, 2, 3, 4].map(function (o) {
          var c = '';
          if (mine === o) c = o === key ? 'uc' : 'uw'; else if (o === key) c = 'k';
          return h('span', { class: c, text: fa(o) });
        });
        list.appendChild(h('div', { class: 'bse-aq' }, [
          h('div', { class: 'bse-nt' }, [h('span', { class: 'bse-qs ' + s }, [s === 'correct' ? ico('check') : s === 'wrong' ? ico('x') : '—']), h('b', { text: fa(i) })]),
          h('div', { class: 'bse-ao' }, opts)]));
      })(i);
      var sheet = h('aside', { class: 'bse-sh' });
      var mob = mobShell(sheet, [h('b', {}, [ico('sheet'), 'پاسخ‌برگ تحلیلی']), h('span', {}, [fa(d.correct) + ' ✓ · ' + fa(d.wrong) + ' ✗'])]);
      sheet.appendChild(h('div', { class: 'bse-shh', onclick: mob.close }, [h('i'), h('div', {}, [h('b', { text: 'پاسخ‌برگ تحلیلی' }), h('small', { text: fa(d.correct) + ' صحیح · ' + fa(d.wrong) + ' غلط · ' + fa(d.blank) + ' نزده' })])]));
      sheet.appendChild(h('div', { class: 'bse-sha' }, [h('div', { class: 'bse-sm3' }, [
        h('div', { class: 'c' }, [h('small', { text: 'صحیح' }), h('b', { text: fa(d.correct) })]),
        h('div', { class: 'w' }, [h('small', { text: 'غلط' }), h('b', { text: fa(d.wrong) })]),
        h('div', { class: 'b' }, [h('small', { text: 'نزده' }), h('b', { text: fa(d.blank) })])])]));
      sheet.appendChild(h('div', { class: 'bse-lg' }, [
        h('span', {}, [h('i', { class: 'c' }), 'گزینه‌ی درست شما']), h('span', {}, [h('i', { class: 'w' }), 'گزینه‌ی غلط شما']), h('span', {}, [h('i', { class: 'k' }), 'کلید صحیح'])]));
      sheet.appendChild(h('div', { class: 'bse-shs' }, [h('div', { class: 'bse-gt' }, [h('b', { text: 'سؤال‌های آزمون' }), h('span', { text: fa(d.qn) + ' سؤال' })]), list]));
      overlay([
        h('header', { class: 'bse-ah' }, [
          link(uid ? 'نتایج' : 'کارنامه', preview ? previewHash('result',id,preview) : (uid ? '#/m/k/' + id : '#/r/' + id), 'gh sm bse-bk', 'back'),
          h('div', { class: 'bse-at' }, [h('b', { text: preview==='practice'?'پاسخ‌نامه آزمون تمرینی':preview ? 'پاسخ‌نامه پیش‌نمایش' : (d.explanation_pdf ? 'پاسخ‌نامهٔ تشریحی' : (uid ? 'کارنامه ' + d.name : 'پاسخ‌نامه و تحلیل سؤالات')) }), h('span', { text: d.title + (uid ? ' · رتبه ' + fa(d.rank) + ' · ' + fn(d.pct, 2) + '٪' : '') })]),
          h('div', { class: 'bse-sb' }, [
            h('span', { class: 'c' }, [ico('check'), fa(d.correct)]), h('span', { class: 'w' }, [ico('x'), fa(d.wrong)]), h('span', { class: 'b' }, [ico('minus'), fa(d.blank)])])]),
        h('div', { class: 'bse-lay' }, [pdfViewer(d.explanation_pdf ? {groups:[{label:'پاسخ‌نامهٔ تشریحی',files:[d.explanation_pdf]},{label:'سؤالات آزمون',files:pdfFiles(d)}]} : d), sheet]), mob.bd, mob.fab]);
    });
  }

  /* ---------- نفرات برتر ---------- */
  function vBoard(id) {
    api('board', { id: id }, function (d) {
      var top = d.rows.slice(0, 3), rest = d.rows.slice(3), pod = h('div', { class: 'bse-pdm' });
      var order = [1, 0, 2], cls = ['g', 's', 'z'];
      order.forEach(function (idx) {
        var r = top[idx]; if (!r) return;
        pod.appendChild(h('div', { class: 'bse-pc3 r' + (idx + 1) }, [
          h('div', { class: 'bse-pw' }, [idx === 0 ? h('div', { class: 'bse-crn' }, [ico('crown')]) : null, avatar(r.name, r.me)]),
          h('div', { class: 'bse-pnm', text: r.name, title: r.name }),
          h('div', { class: 'bse-psc', text: fn(r.pct, 1) + '٪' }),
          h('div', { class: 'bse-ped ' + cls[idx] }, [h('b', { text: fa(idx + 1) }), h('span', { text: mm(r.secs) })])]));
      });
      var list = h('div', { class: 'bse-lbl' });
      rest.forEach(function (r, i) {
        list.appendChild(h('div', { class: 'bse-lbi' + (r.me ? ' me' : '') }, [
          h('b', { text: fa(i + 4) }), avatar(r.name, r.me), h('span', { class: 'nm', text: r.name }),
          h('div', { class: 'sc' }, [h('b', { text: fn(r.pct, 1) + '٪' }), h('small', { text: mm(r.secs) })])]));
      });
      mount(h('div', { class: 'bse-wrap' }, [
        h('div', { class: 'bse-ptop' }, [link('بازگشت', eU(id), 'gh sm', 'back')]),
        h('section', { class: 'bse-lb' }, [
          h('div', { class: 'bse-trf' }, [ico('trophy')]), h('h1', { text: d.title }),
          h('p', { class: 'sub', text: d.temporary ? 'جدول موقت ۱۰ نفر برتر — تا پایان مهلت شرکت قابل تغییر است' : 'جدول ۱۰ نفر برتر' }),
          d.rows.length ? pod : h('div', { class: 'bse-empty', text: 'هنوز کسی در این آزمون شرکت نکرده است.' }), list])]));
    });
  }

  /* ================= مدیر ================= */

  /* ---------- لیست آزمون‌های مدیر ---------- */
  function mMan() {
    var box = h('div', { class: 'bse-list' });
    mount(h('div', { class: 'bse-wrap' }, [
      h('div', { class: 'bse-h' }, [h('div', {}, [h('h1', { text: 'آزمون‌های من' }), h('p', { text: 'ساخت آزمون و دیدن نتیجه‌ها' })]),
        h('div', { class: 'bse-da' }, [link('همه‌ی آزمون‌ها', '#/', 'gh', 'list'), link('آزمون جدید', '#/m/new', 'pri', 'plus')])]),
      h('section', { class: 'bse-sec' }, [box])]));
    api('list', {}, function (d) {
      if (!d.length) box.appendChild(h('div', { class: 'bse-empty' }, [h('b', { text: 'هنوز آزمونی نساخته‌اید' }), 'با «آزمون جدید» اولین آزمون را بسازید.']));
      d.forEach(function (x) { box.appendChild(h('div', {}, [examRow(x, '#/m/s/' + x.id, true), link('اتصال به محصول', '#/m/access/' + x.id, 'gh sm', 'list')])); });
    });
  }

  /* ---------- جزئیات آزمون: نمای کلی / کارنامه / تحلیل ---------- */
  /* Administrator ranking PDF. Raster pages preserve Persian shaping without external libraries. */
  function rankPdfBlob(images) {
    var chunks=[],offset=0,positions=[0],encoder=new TextEncoder();
    function put(s){var b=typeof s==='string'?encoder.encode(s):s;chunks.push(b);offset+=b.length;}
    function obj(n,s){positions[n]=offset;put(n+' 0 obj\n'+s+'\nendobj\n');}
    put('%PDF-1.4\n');obj(1,'<< /Type /Catalog /Pages 2 0 R >>');
    obj(2,'<< /Type /Pages /Count '+images.length+' /Kids ['+images.map(function(_,i){return (3+i*3)+' 0 R';}).join(' ')+'] >>');
    images.forEach(function(im,i){
      var n=3+i*3,raw=atob(im.split(',')[1]),bytes=new Uint8Array(raw.length);
      for(var j=0;j<raw.length;j++)bytes[j]=raw.charCodeAt(j);
      obj(n,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 841.89 595.28] /Resources << /XObject << /Im '+(n+1)+' 0 R >> >> /Contents '+(n+2)+' 0 R >>');
      positions[n+1]=offset;put((n+1)+' 0 obj\n<< /Type /XObject /Subtype /Image /Width 1684 /Height 1190 /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+bytes.length+' >>\nstream\n');put(bytes);put('\nendstream\nendobj\n');
      var stream='q 841.89 0 0 595.28 0 0 cm /Im Do Q';obj(n+2,'<< /Length '+stream.length+' >>\nstream\n'+stream+'\nendstream');
    });
    var start=offset;put('xref\n0 '+positions.length+'\n0000000000 65535 f \n');
    positions.slice(1).forEach(function(v){put(String(v).padStart(10,'0')+' 00000 n \n');});
    put('trailer\n<< /Size '+positions.length+' /Root 1 0 R >>\nstartxref\n'+start+'\n%%EOF');
    return new Blob(chunks,{type:'application/pdf'});
  }
  async function rankPdfBuild(d) {
    if(document.fonts&&document.fonts.ready)await document.fonts.ready;
    /* لوگو: اگر لود نشد، همان متن قبلی در هدر نوشته می‌شود */
    var logo=await new Promise(function(resolve){
      var im=new Image();
      im.onload=function(){resolve(im);};
      im.onerror=function(){resolve(null);};
      im.src=C.logo||(location.origin+'/wp-content/uploads/dr-farzii-logo.png?v=1');
    });
    var images=[],groups=d.multi?Math.max(1,Math.ceil((d.subjects||[]).length/9)):1,plans=[],font=getComputedStyle(root).fontFamily||'sans-serif';
    for(var group=0;group<groups;group++){var subset=(d.subjects||[]).slice(group*9,group*9+9),rh=d.multi?Math.max(90,Math.ceil(subset.length/4)*64+18):73,perPage=d.multi?Math.max(1,Math.floor(760/rh)):18;for(var at=0;at<d.rows.length;at+=perPage)plans.push({offset:at,count:perPage,rh:rh,subjects:subset,subjectOffset:group*9,group:group});}
    var total=plans.length;
    function date(ts){try{return new Date(ts*1000).toLocaleDateString('fa-IR',{timeZone:C.timezone||'Asia/Tehran'});}catch(e){return new Date(ts*1000).toLocaleDateString('fa-IR');}}
    for(var pg=0;pg<total;pg++){
      var plan=plans[pg],rh=plan.rh;var canvas=document.createElement('canvas');canvas.width=1684;canvas.height=1190;var x=canvas.getContext('2d');
      x.fillStyle='#fff';x.fillRect(0,0,1684,1190);x.direction='rtl';
      function text(t,cx,y,max,size,bold){x.font=(bold?'bold ':'')+(size||23)+'px '+font;x.fillStyle='#263344';x.textAlign='center';x.fillText(fa(t),cx,y,max);}
      function cell(t,l,y,w,height,head,size){x.beginPath();if(x.roundRect)x.roundRect(l,y,w,height,Math.min(23,height/2));else x.rect(l,y,w,height);x.fillStyle=head?'#eef0f2':'#fff';x.fill();if(!head){x.strokeStyle='#afb5bd';x.lineWidth=1.2;x.stroke();}text(t,l+w/2,y+height/2+8,w-18,size||23,head);}
      /* هدر: لوگو در گوشه بالا راست (پس‌زمینه شفاف، روی صفحه سفید) */
      if(logo&&logo.width){
        var lw=340,lh=Math.round(lw*logo.height/logo.width);
        x.imageSmoothingEnabled=true;x.imageSmoothingQuality='high';
        x.drawImage(logo,1644-lw,Math.round(86-lh/2),lw,lh);
      }else{
        text('دکتر فرضی',1470,75,330,35,true);text('سامانه آزمون آنلاین',1470,117,330,21);
      }
      text('DRFARZII.IR',190,80,300,25);
      cell('گزارش نتایج آزمون',40,149,1604,46,true,25);text('صفحه '+(pg+1)+' از '+total,220,181,300,20);
      cell('عنوان آزمون: '+d.title,640,209,1004,50,false,21);cell('تعداد: '+d.n+' | تاریخ آزمون: '+date(d.st),40,209,590,50,false,20);
      var slice=d.rows.slice(plan.offset,plan.offset+plan.count);
      if(groups>1)text('بخش درس‌ها: '+(plan.group+1)+' از '+groups,842,1118,1500,18);
      if(!d.multi){
        var split=Math.ceil(plan.count/2);
        [0,1].forEach(function(col){var left=col===0?862:40;
          cell('نام و نام خانوادگی',left+280,279,500,48,true);cell('رتبه',left+150,279,120,48,true);cell('درصد',left,279,140,48,true);
          slice.slice(col*split,(col+1)*split).forEach(function(r,i){var y=340+i*73;cell(r.name,left+280,y,500,60,false);cell(r.rank,left+150,y,120,60,false);cell(fn(r.pct,2)+'٪',left,y,140,60,false);});
        });
      }else{
        cell('نام و نام خانوادگی',1280,279,364,48,true);cell('رتبه کل',1140,279,130,48,true);cell('درصد کل',970,279,160,48,true);cell('درصد هر درس',40,279,920,48,true);
        slice.forEach(function(r,i){var y=340+i*rh;cell(r.name,1280,y,364,rh-10,false);cell(r.rank,1140,y,130,rh-10,false);cell(fn(r.pct,2)+'٪',970,y,160,rh-10,false);
          cell('',40,y,920,rh-10,false);
          plan.subjects.forEach(function(s,j){var cx=845-(j%4)*230,sy=y+12+Math.floor(j/4)*64;cell('',cx-108,sy,216,56,false);text(s.book+' · '+s.title,cx,sy+22,202,17);text(fn(r.subjects[plan.subjectOffset+j],2)+'٪',cx,sy+46,202,21,true);});
        });
      }
      text('تاریخ صدور: '+date(d.issued)+' · شرکت‌کنندگان رسمی · drfarzii.ir',842,1155,1550,18);
      images.push(canvas.toDataURL('image/jpeg',0.92));
      // Yield between pages so the management interface remains responsive.
      await new Promise(function(resolve){setTimeout(resolve,0);});
    }
    return rankPdfBlob(images);
  }
  function rankPdfShow(id) {
    var win=window.open('','_blank');
    if(!win){toast('اجازه بازشدن تب جدید را بدهید و دوباره تلاش کنید');return;}
    win.opener=null;win.document.title='گزارش رتبه‌بندی';
    win.document.body.textContent='در حال آماده‌سازی گزارش رتبه‌بندی…';win.document.body.dir='rtl';
    api('mrank_pdf',{id:id},function(d){
      if(win.closed)return;
      if(!d.rows||!d.rows.length){win.document.body.textContent='شرکت‌کننده رسمی ثبت نشده است';return;}
      rankPdfBuild(d).then(function(blob){
        if(win.closed)return;var url=URL.createObjectURL(blob),doc=win.document;
        doc.body.textContent='';doc.body.style.cssText='margin:0;background:#edf2f8;font-family:sans-serif;direction:rtl';
        var bar=doc.createElement('div');bar.style.cssText='padding:14px;display:flex;gap:20px;align-items:center;flex-wrap:wrap';
        var title=doc.createElement('strong');title.textContent=d.title;bar.appendChild(title);
        var a=doc.createElement('a');a.href=url;a.download='ranking-'+id+'.pdf';a.textContent='دانلود PDF رتبه‌بندی';a.style.cssText='background:#2563eb;color:white;padding:10px 18px;border-radius:8px;text-decoration:none';bar.appendChild(a);
        var note=doc.createElement('span');note.textContent='اگر پیش‌نمایش روی گوشی نمایش داده نشد، دکمه دانلود را بزنید.';bar.appendChild(note);doc.body.appendChild(bar);
        var frame=doc.createElement('iframe');frame.title='گزارش PDF رتبه‌بندی';frame.src=url;frame.style.cssText='width:100%;height:calc(100vh - 100px);border:0';doc.body.appendChild(frame);
        win.addEventListener('unload',function(){URL.revokeObjectURL(url);},{once:true});
      }).catch(function(){if(!win.closed)win.document.body.textContent='ساخت PDF کامل نشد؛ دوباره تلاش کنید.';});
    },false,function(msg){if(!win.closed)win.document.body.textContent=msg||'دریافت گزارش کامل نشد';});
  }

  function csvOut(d, id) {
    var L = [['رتبه', 'نام', 'موبایل', 'درصد', 'صحیح', 'غلط', 'بدون پاسخ', 'زمان (ثانیه)']];
    d.rows.forEach(function (r) { L.push([r.rank, r.name, '="' + r.mobile + '"', r.pct, r.c, r.w, r.b, r.secs]); });
    var s = '\uFEFF' + L.map(function (r) {
      return r.map(function (c) { c = String(c); return /[",\n]/.test(c) && c.charAt(0) !== '=' ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(',');
    }).join('\r\n');
    var u = URL.createObjectURL(new Blob([s], { type: 'text/csv;charset=utf-8' })), a = document.createElement('a');
    a.href = u; a.download = 'karname-' + id + '.csv'; document.body.appendChild(a); a.click();
    setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(u); }, 500);
  }
  function copyText(t) {
    function fb() {
      var ta = h('textarea', { style: 'position:fixed;opacity:0;top:0;left:0' });
      ta.value = t; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); toast('لینک کپی شد', false); } catch (e) { toast('کپی نشد؛ لینک را دستی کپی کنید'); }
      document.body.removeChild(ta);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(function () { toast('لینک کپی شد', false); }, fb);
    else fb();
  }

  function ptable(rows, c4, id) {
    var t = h('div', { class: 'bse-pt' + (c4 ? ' c4' : '') });
    var heads = c4 ? ['رتبه / نام', 'درصد', 'مدت', 'صحیح / غلط / نزده'] : ['رتبه / نام', 'درصد', 'مدت', 'صحیح / غلط / نزده', 'موبایل', 'کارنامه'];
    t.appendChild(h('div', { class: 'bse-th' }, heads.map(function (x) { return h('span', { text: x }); })));
    rows.forEach(function (r) {
      var cells = [h('span', { class: 'nm' }, [h('i', { class: 'rk', text: fa(r.rank) }), h('span', { text: r.name })]),
        h('b', { text: fn(r.pct, 1) + '٪' }), h('span', { text: hms(r.secs) }), h('span', { text: fa(r.c) + ' / ' + fa(r.w) + ' / ' + fa(r.b) })];
      if (!c4) {
        cells.push(h('span', { class: 'ltr', text: r.mobile || '—' }));
        cells.push(h('a', { class: 'bse-btn sec sm', href: '#/m/u/' + id + '/' + r.uid }, [ico('eye'), 'مشاهده']));
      }
      t.appendChild(h('div', { class: 'bse-tr' }, cells));
    });
    return t;
  }

  /* پوستر (تصویر PNG با canvas) */
  function wrapT(x, t, maxW) {
    var words = String(t).split(' '), lines = [], cur = '';
    words.forEach(function (w) {
      var tt = cur ? cur + ' ' + w : w;
      if (x.measureText(tt).width > maxW && cur) { lines.push(cur); cur = w; } else cur = tt;
    });
    if (cur) lines.push(cur);
    return lines;
  }
  function makePoster(kind, d, id, url) {
    try {
      var W = 1080, HH = 1350, cv = document.createElement('canvas');
      cv.width = W; cv.height = HH;
      var x = cv.getContext('2d');
      var ff = (window.getComputedStyle ? getComputedStyle(root).fontFamily : '') || 'Tahoma, sans-serif';
      var g = x.createLinearGradient(0, 0, W, HH); g.addColorStop(0, '#0a1a4f'); g.addColorStop(1, '#0d5cff');
      x.fillStyle = g; x.fillRect(0, 0, W, HH);
      x.direction = 'rtl'; x.textAlign = 'center'; x.textBaseline = 'middle';
      var T = function (t, y, sz, wt, col, al, px) { x.font = wt + ' ' + sz + 'px ' + ff; x.fillStyle = col; x.textAlign = al || 'center'; x.fillText(t, px === undefined ? W / 2 : px, y); };
      var rr = function (px, py, w, hh, r, col) {
        x.beginPath(); x.moveTo(px + r, py); x.arcTo(px + w, py, px + w, py + hh, r); x.arcTo(px + w, py + hh, px, py + hh, r);
        x.arcTo(px, py + hh, px, py, r); x.arcTo(px, py, px + w, py, r); x.closePath(); x.fillStyle = col; x.fill();
      };
      T('نفرات برتر آزمون', 120, 40, 700, 'rgba(255,255,255,.75)');
      x.font = '900 72px ' + ff;
      var lines = wrapT(x, d.title, 900).slice(0, 3), y0 = 250;
      lines.forEach(function (l, i) { T(l, y0 + i * 98, 72, 900, '#fff'); });
      var cy = y0 + lines.length * 98 + 20, rows, i;
      {
        rows = d.rows.slice(0, 3);
        var cols = ['#f59e0b', '#94a3b8', '#c25e2e'];
        rows.forEach(function (r, k) {
          var yy = cy + 20 + k * 150;
          rr(90, yy, 900, 124, 36, '#ffffff');
          x.beginPath(); x.arc(W - 170, yy + 62, 40, 0, Math.PI * 2); x.fillStyle = cols[k]; x.fill();
          T(fa(k + 1), yy + 64, 44, 900, '#fff', 'center', W - 170);
          T(shortName(r.name), yy + 62, 40, 800, '#0f172a', 'right', W - 240);
          T(fn(r.pct, 1) + '٪', yy + 62, 42, 900, '#0d5cff', 'left', 150);
        });
      }
      T(location.host, HH - 70, 30, 700, 'rgba(255,255,255,.65)');
      var data = cv.toDataURL('image/png');
      modal({ icon: 'sparkles', title: 'پوستر آماده است', ok: 'دانلود تصویر', cancel: 'بستن',
        body: [h('img', { src: data, alt: 'پوستر آزمون', style: 'width:100%;border-radius:16px;margin-bottom:4px' })],
        onok: function () {
          var a = h('a', { href: data, download: 'poster-' + kind + '-' + id + '.png' });
          document.body.appendChild(a); a.click(); document.body.removeChild(a);
        } });
    } catch (e) { if (window.console) console.error(e); toast('ساخت پوستر ممکن نشد'); }
  }

  function mDet(id, tab) {
    api('mstats', { id: id }, function (d) {
      S.off = d.now - Math.floor(Date.now() / 1000);
      var s0 = stat(d), n = d.rows.length, sum = 0, mx = 0, ss = 0;
      d.rows.forEach(function (r) { sum += r.pct; ss += r.secs; if (r.pct > mx) mx = r.pct; });
      var avgS = n ? ss / n : 0, going = d.going || 0;
      var shareUrl = (C.base || (location.origin + location.pathname)) + '#/e/' + id;
      function askDel() {
        modal({ icon: 'trash', danger: true, title: 'حذف آزمون؟', ok: 'حذف آزمون', cancel: 'انصراف',
          body: [h('p', { class: 'bse-cn', text: 'این آزمون و نتیجه‌ی همه‌ی شرکت‌کنندگانش برای همیشه حذف می‌شود.' })],
          onok: function () { api('mdel', { id: id }, function () { toast('آزمون حذف شد', false); location.hash = '#/m'; }); } });
      }
      var mnl = null, mw = h('div', { class: 'bse-mw' });
      function closeMn() { if (mnl && mnl.parentNode) mnl.parentNode.removeChild(mnl); mnl = null; document.removeEventListener('mousedown', outMn); }
      function outMn(e) { if (mnl && !mw.contains(e.target)) closeMn(); }
      mw.appendChild(h('button', { type: 'button', class: 'bse-ib', title: 'بیشتر', onclick: function () {
        if (mnl) { closeMn(); return; }
        mnl = h('div', { class: 'bse-mnl' }, [h('button', { type: 'button', class: 'd', onclick: function () { closeMn(); askDel(); } }, [ico('trash'), 'حذف آزمون'])]);
        mw.appendChild(mnl); document.addEventListener('mousedown', outMn);
      } }, [ico('more')]));
      var body = h('div', {});
      if (tab === 'o') {
        var tcd = h('b'), tlb = h('small');
        var tk = function () {
          if (stat(d) !== s0) { mDet(id, tab); return; }
          if (s0 === 'ended') { tlb.textContent = 'پایان آزمون'; tcd.textContent = dt(d.en); }
          else { tlb.textContent = s0 === 'upcoming' ? 'تا شروع آزمون' : 'تا پایان آزمون'; tcd.textContent = mm((s0 === 'upcoming' ? d.st : d.en) - now()); }
        };
        var stats = [
          ['users', 'b', 'شرکت‌کنندگان رسمی', [fa(n)], n ? null : null],
          ['refresh', 'v', 'در حال آزمون', [fa(going)], going || n ? 'کل شروع‌کرده‌ها: ' + fa(going + n) : null],
          ['clock', 'a', 'میانگین زمان', [n ? dur2(avgS) : '—'], null],
          ['chart', 'g', 'میانگین درصد', [n ? fn(sum / n, 2) : '—', n ? h('small', { text: 'درصد' }) : null], null]];
        body.appendChild(h('div', { class: 'bse-shc' }, [
          h('div', { class: 'bse-shm' }, [h('small', { text: 'لینک آزمون — همین را به شرکت‌کنندگان بدهید' }), h('span', { class: 'lnk', text: shareUrl }),
            h('div', { class: 'bse-da' }, [btn('کپی لینک', 'pri', function () { copyText(shareUrl); }, 'copy')])]),
          h('div', { class: 'bse-tmr' }, [tlb, tcd])]));

        body.appendChild(h('div', { class: 'bse-qst' }, stats.map(function (s) {
          return h('div', {}, [h('span', { class: 'bse-ic ' + s[1] }, [ico(s[0])]), h('p', {}, [h('small', { text: s[2] }), h('b', {}, s[3])]), s[4] ? h('em', { text: s[4] }) : null]);
        })));
        var pc = function (ic, t, desc, ok, kind, why) {
          return h('div', { class: 'bse-pcd' }, [
            h('div', { class: 'bse-pcm' }, [h('h3', {}, [ico(ic), t]), h('p', { text: desc }),
              ok ? btn('ساخت پوستر', 'pri sm', function () { makePoster(kind, d, id, shareUrl); }, 'sparkles') : h('span', { class: 'bse-btn gh sm off', text: why })]),
            h('div', { class: 'bse-pth ' + kind }, [ico(ic)])]);
        };
        body.appendChild(h('div', { class: 'bse-rc' }, [
          h('div', { class: 'bse-sti' }, [h('div', {}, [h('h2', { text: 'پوسترهای آزمون' }), h('p', { text: 'ساخت تصویر نفرات برتر پس از پایان آزمون.' })])]),
          h('div', { class: 'bse-pos' }, [
            pc('trophy', 'نفرات برتر', 'نفرات برتر آزمون را پس از پایان آن معرفی کنید.', s0 === 'ended' && n > 0, 'top', s0 === 'ended' ? 'هنوز کسی شرکت نکرده' : 'بعد از پایان آزمون')])]));
        body.appendChild(h('div', { class: 'bse-rc' }, [
          h('div', { class: 'bse-sti' }, [h('div', {}, [h('h2', { text: 'نفرات برتر' }), h('p', { text: 'تا ۵ نفر اول' })]), n ? h('a', { href: '#/m/k/' + id }, ['همه‌ی نتایج', ico('chl')]) : null]),
          n ? ptable(d.rows.slice(0, 5), true, id) : h('div', { class: 'bse-empty', text: 'هنوز کسی شرکت نکرده است.' })]));
        body.appendChild(h('div', { class: 'bse-rc' }, [
          h('div', { class: 'bse-sti' }, [h('h2', { text: 'فایل‌ها' })]),
          h('div', { class: 'bse-fl2' }, [h('span', { class: 'bse-ic b' }, [ico('file')]), h('div', {}, [h('b', { text: 'فایل PDF سؤالات' }), h('small', { text: fa(d.qn) + ' سؤال' })]), h('div', { class: 'bse-file-links' }, pdfFiles(d).map(function (url, i) { return h('a', { class: 'bse-btn gh sm', href: url, target: '_blank', rel: 'noopener' }, [ico('ext'), pdfName(url, i)]); }))])]));
      } else if (tab === 'k') {
        body.appendChild(h('div', { class: 'bse-rc' }, [
          h('div', { class: 'bse-sti' }, [h('h2', { text: 'کارنامه تجمیعی آزمون' })]),
          h('div', { class: 'bse-fl2' }, [h('span', { class: 'bse-ic g' }, [ico('down')]), h('div', {}, [h('b', { text: 'خروجی Excel' }), h('small', { text: 'نمره، پاسخ‌ها و رتبه‌ی همه‌ی شرکت‌کننده‌ها (فایل CSV که در Excel باز می‌شود)' })]),
            n ? btn('دانلود', 'sec sm', function () { csvOut(d, id); }, 'down') : h('span', { class: 'bse-btn gh sm off', text: 'بدون داده' })])]));
        if(C.admin) body.appendChild(h('div',{class:'bse-rc bse-pdf-export'},[
          h('div',{class:'bse-sti'},[h('h2',{text:'خروجی PDF'})]),
          h('div',{class:'bse-fl2'},[h('span',{class:'bse-ic b'},[ico('file')]),h('div',{},[h('b',{text:'گزارش رتبه‌بندی آزمون'}),h('small',{text:'نمایش رتبه‌بندی و درصد شرکت‌کنندگان رسمی'})]),
            (+d.now >= +d.en+15 && n>0) ? btn('نمایش گزارش PDF','sec sm',function(){rankPdfShow(id);},'eye') : h('span',{class:'bse-btn gh sm off',text:n?'پس از پایان آزمون':'بدون داده'})]),
          h('p',{class:'bse-note',text:'پس از پایان مهلت رسمی آزمون و مهلت ثبت نهایی فعال می‌شود.'})]));
        body.appendChild(h('div', { class: 'bse-rc' }, [
          h('div', { class: 'bse-sti' }, [h('div', {}, [h('h2', { text: 'شرکت‌کنندگان رسمی' }), h('p', { text: n ? 'بیشترین درصد: ' + fn(mx, 2) + ' — کمترین درصد: ' + fn(d.rows[n - 1].pct, 2) + ' — برای بررسی پاسخ‌های هر نفر «مشاهده» را بزنید' : 'هنوز کسی شرکت نکرده است' })])]),
          n ? ptable(d.rows, false, id) : h('div', { class: 'bse-empty', text: 'بعد از شرکت اولین نفر، نتایج اینجا می‌آید.' })]));
      } else {
        var mxd = Math.max.apply(null, d.dist.concat([1])), avgB = Math.min(9, Math.max(0, Math.floor(sum / (n || 1) / 10)));
        var dist = h('div', { class: 'bse-dist' });
        d.dist.forEach(function (v, i) {
          dist.appendChild(h('div', {}, [h('b', { text: fa(v) }), h('i', { class: n && i === avgB ? 'avg' : '', style: 'height:' + (v / mxd * 100 * 0.8) + '%' }), h('small', { text: fa(i * 10) + '–' + fa(i * 10 + 10) })]));
        });
        var easy = 0, mid = 0, hard = 0;
        d.qs.forEach(function (v) { if (v > 70) easy++; else if (v >= 40) mid++; else hard++; });
        var tot = d.qs.length || 1;
        var msg = !n ? 'بعد از شرکت اولین نفر، تحلیل دشواری ساخته می‌شود.'
          : easy / tot > 0.6 ? 'آزمون از حالت متعادل آسان‌تر بوده؛ سؤال‌های آسان شرکت‌کنندگان قوی را از هم جدا نمی‌کنند.'
          : hard / tot > 0.5 ? 'آزمون از حالت متعادل سخت‌تر بوده؛ بیشتر سؤال‌ها کمتر از ۴۰٪ پاسخ درست گرفته‌اند.'
          : 'ترکیب دشواری آزمون متعادل است.';
        var dfr = [['#16a36a', 'آسان (بیش از ٪۷۰ صحیح)', easy], ['#e59a21', 'متوسط (٪۴۰ تا ٪۷۰)', mid], ['#dd4b59', 'دشوار (زیر ٪۴۰)', hard]];
        var ins = h('div', { class: 'bse-ins' });
        d.qs.forEach(function (v, i) {
          ins.appendChild(h('div', {}, [h('span', { text: 'سؤال ' + fa(i + 1) }), h('i', {}, [h('b', { class: v >= 70 ? '' : v >= 40 ? 'y' : 'r', style: 'width:' + v + '%' })]), h('em', { text: fa(v) + '٪' })]));
        });
        body.appendChild(h('div', { class: 'bse-rc' }, [
          h('div', { class: 'bse-sti' }, [h('div', {}, [h('h2', { text: 'توزیع درصد شرکت‌کنندگان' }), h('p', { text: 'بازه‌های ۱۰ درصدی · ' + fa(n) + ' شرکت‌کننده‌ی رسمی' })])]),
          dist, n ? h('span', { class: 'bse-chip', text: 'میانگین ٪' + fn(sum / n, 1) }) : null]));
        body.appendChild(h('div', { class: 'bse-rc' }, [
          h('div', { class: 'bse-sti' }, [h('div', {}, [h('h2', { text: 'ترکیب دشواری آزمون' }), h('p', { text: 'بر اساس درصد پاسخ صحیح هر سؤال' })])]),
          h('div', { class: 'bse-df2' }, dfr.map(function (r) { return h('i', { style: 'width:' + (r[2] / tot * 100) + '%;background:' + r[0] }); })),
          h('div', {}, dfr.map(function (r) { return h('div', { class: 'bse-dfr' }, [h('i', { style: 'background:' + r[0] }), h('span', { text: r[1] }), h('b', { text: fa(r[2]) + ' سؤال · ٪' + fa(Math.round(r[2] / tot * 100)) })]); })),
          h('div', { class: 'bse-note', text: msg })]));
        body.appendChild(h('div', { class: 'bse-rc' }, [
          h('div', { class: 'bse-sti' }, [h('div', {}, [h('h2', { text: 'تحلیل سؤال‌ها' }), h('p', { text: 'درصد پاسخ صحیح تا این لحظه' })])]), ins]));
      }
      if (d.multi && tab === 't') body.appendChild(h('section',{class:'bse-fc'},[h('h2',{text:'میانگین درصد درس‌ها و دفترچه‌ها'}),h('p',{class:'bse-note',text:'تعداد صحیح، غلط و نزده در جدول، مجموع پاسخ‌های شرکت‌کنندگان است.'}),multiReport(d)]));
      var meta = [stBadge(s0), h('span', { class: 'bse-ch2' }, [ico('users'), 'عمومی']), h('span', { text: fa(d.qn) + ' سؤال' }), h('i', { class: 'dot' }),
        h('span', { text: fa(d.dur) + ' دقیقه' }), h('i', { class: 'dot' }), h('span', { text: dt(d.st) + ' تا ' + dt(d.en) })];
      mount(h('div', { class: 'bse-wrap' }, [
        h('div', { class: 'bse-ptop' }, [link('آزمون‌های من', '#/m', 'gh sm', 'back')]),
        h('div', { class: 'bse-mhd' }, [
          h('div', { class: 'bse-mt1' }, [h('span', { class: 'bse-tck' }, [ico(s0 === 'ended' ? 'check' : s0 === 'running' ? 'clock' : 'cal')]),
            h('div', {}, [h('h1', { text: d.title }), h('div', { class: 'bse-mm' }, meta)])]),
          h('div', { class: 'bse-da' }, [link('اتصال به محصول', '#/m/access/' + id, 'gh', 'list'), link('ویرایش آزمون', '#/m/edit/' + id, 'gh', 'edit'), link('پیش‌نمایش', '#/p/' + id, 'gh', 'eye'), mw])]),
        h('nav', { class: 'bse-seg' }, [['o', 'نمای کلی', 's'], ['k', 'کارنامه', 'k'], ['t', 'تحلیل', 't']].map(function (t) {
          return h('a', { href: '#/m/' + t[2] + '/' + id, class: tab === t[0] ? 'on' : '', text: t[1] });
        })), body]));
      if (tab === 'o') { tk(); S.timer = setInterval(tk, 500); }
    });
  }

  function mAccess(id) {
    api('access_get', {id:id}, function(d) {
      var chosen = {}, names = {}, page = 1, query = '', loading = false, saving = false;
      d.selected.forEach(function(p){ chosen[p.id] = true; names[p.id] = p.name; });
      var selected = h('div'), results = h('div'), status = h('p', {role:'status'});
      var days = h('input', {type:'number', min:0, max:3650, step:1, value:d.days, 'aria-label':'مدت دسترسی به روز'});
      var search = h('input', {type:'search', placeholder:'نام محصول', 'aria-label':'جستجوی محصول'});
      function paintSelected() {
        selected.textContent = '';
        Object.keys(chosen).forEach(function(pid) {
          selected.appendChild(h('div', {class:'bse-file-links'}, [h('span', {text:names[pid] + ' (#' + pid + ')'}), btn('حذف اتصال', 'gh sm', function(){ if(saving)return; delete chosen[pid]; paintSelected(); paintRows(lastItems); })]));
        });
        if (!Object.keys(chosen).length) selected.appendChild(h('p',{text:'بدون محصول: آزمون فقط برای مدیر قابل دسترسی است.'}));
      }
      var lastItems = [];
      function paintRows(items) {
        lastItems = items; results.textContent = '';
        items.forEach(function(p){
          names[p.id] = p.name;
          var input = h('input',{type:'checkbox', 'aria-label':p.name}); input.checked = !!chosen[p.id];
          input.addEventListener('change',function(){if(saving){input.checked=!!chosen[p.id];return;} if(input.checked)chosen[p.id]=true;else delete chosen[p.id];paintSelected();});
          results.appendChild(h('label',{style:'display:flex;gap:10px;padding:8px'},[input,p.name + ' (#' + p.id + ')']));
        });
        if(!items.length) results.appendChild(h('p',{text:'محصولی پیدا نشد.'}));
      }
      var more = btn('صفحه بعد', 'gh sm', function(){load(false);});
      function load(reset) {
        if(loading)return;loading=true;
        if(reset){page=1;query=search.value.trim();}else page++;
        status.textContent='در حال جستجو…';
        api('access_search',{id:id,q:query,page:page},function(r){loading=false;status.textContent='';paintRows(r.items);more.hidden=!r.more;},false,function(){loading=false;status.textContent='جستجو انجام نشد؛ دوباره تلاش کنید.';if(!reset)page--;});
      }
      var save = btn('ذخیره اتصال', 'pri', function(){
        if(saving)return;
        if(!days.value.trim() || !days.checkValidity()){status.textContent='مدت دسترسی باید عدد صحیح بین صفر و ۳۶۵۰ باشد.';return;}
        saving=true;save.disabled=true;days.disabled=true;status.textContent='در حال ذخیره…';
        api('access_save',{id:id,products:JSON.stringify(Object.keys(chosen).map(Number)),days:days.value},function(){saving=false;save.disabled=false;days.disabled=false;status.textContent='اتصال محصول ذخیره شد.';},false,function(){saving=false;save.disabled=false;days.disabled=false;status.textContent='ذخیره انجام نشد؛ دوباره تلاش کنید.';});
      });
      mount(h('div',{class:'bse-wrap'},[
        h('div',{class:'bse-h'},[h('h1',{text:'اتصال به محصول: ' + d.title}),link('بازگشت به آزمون','#/m/s/'+id,'gh sm','back')]),
        h('section',{class:'bse-sec'},[h('h2',{text:'محصول‌های متصل'}),selected,h('h2',{text:'انتخاب محصول'}),h('div',{class:'bse-da'},[search,btn('جستجو','gh',function(){load(true);})]),results,more,
        h('label',{},['مدت دسترسی بعد از خرید (روز؛ صفر یعنی نامحدود)',days]),h('p',{text:'خرید هر یک از محصول‌های انتخاب‌شده، طبق شرایط فعلی دسترسی، این آزمون را فعال می‌کند.'}),save,status])
      ]));
      paintSelected();paintRows(d.items);more.hidden=!d.more;
    });
  }

  /* ---------- فرم ساخت و ویرایش آزمون ---------- */
  function singleSolution(F,onBusy){
    var list=h('div',{class:'bse-upload-list'}),status=h('small',{role:'status'}),busy=false;
    function paint(){list.textContent='';if(F.explanation_pdf)list.appendChild(h('div',{class:'bse-upload-row'},[h('a',{href:F.explanation_pdf,target:'_blank',rel:'noopener',text:pdfName(F.explanation_pdf,0)}),btn('حذف پاسخ‌نامه','gh sm',function(){if(busy)return;F.explanation_pdf='';paint();},'trash')]));}
    var input=h('input',{type:'file',accept:'.pdf,application/pdf','aria-label':'فایل پاسخ‌نامه تشریحی تک‌درس',onchange:function(){
      var file=this.files&&this.files[0];if(!file||busy)return;if(!/\.pdf$/i.test(file.name)){toast('فقط PDF پاسخ‌نامه را انتخاب کنید');this.value='';return;}
      busy=true;onBusy(true);input.disabled=true;status.textContent='در حال بارگذاری پاسخ‌نامه…';
      var fd=new FormData();fd.append('action','bse_up');fd.append('n',C.nonce);fd.append('f',file);
      function finish(){busy=false;onBusy(false);input.disabled=false;input.value='';}
      post(fd,function(r){finish();if(r&&r.url){F.explanation_pdf=r.url;status.textContent='پاسخ‌نامه بارگذاری شد.';paint();}else status.textContent='آپلود انجام نشد؛ دوباره انتخاب کنید.';},false,function(reason){finish();status.textContent=reason||'آپلود انجام نشد؛ دوباره انتخاب کنید.';});
    }});paint();
    return h('section',{class:'bse-fc bse-single-solution'},[h('h2',{text:'پاسخ‌نامهٔ تشریحی'}),h('div',{class:'bse-up'},[input,status]),list,h('p',{class:'bse-note',text:'اختیاری؛ دکمهٔ پاسخ‌نامه بعد از انتشار نتیجه، این PDF را نمایش می‌دهد.'})]);
  }

  function mForm(id) {
    var F = { explanation_pdf: '', title: '', pdf: '', pdfs: [], qn: 20, dur: 25, st: 0, en: 0, neg: 1, early_results: 0, key: [] }, wrap = h('div', {}), saving = false, uploading = false, solutionUploading = false;
    mount(h('div', { class: 'bse-wrap' }, [
      h('div', { class: 'bse-h' }, [h('div', {}, [h('h1', { text: id ? 'ویرایش آزمون' : 'ساخت آزمون' }), h('p', { text: 'اطلاعات آزمون، کلید پاسخ و زمان‌بندی' })]), link('انصراف', id ? '#/m/s/' + id : '#/m', 'gh sm', 'back')]), wrap]));
    if (id) api('mget', { id: id }, function (d) {
      F.explanation_pdf = d.explanation_pdf || ''; F.title = d.title; F.pdf = d.pdf; F.pdfs = pdfFiles(d).slice(); F.qn = d.qn; F.dur = d.dur; F.st = d.st; F.en = d.en; F.neg = d.neg; F.early_results = d.early_results ? 1 : 0; F.key = d.key || []; if (d.multi) { multiForm(id, d); return; } draw();
    }); else draw();

    function fld(l, e, note) { return h('label', { class: 'bse-fl' }, [h('span', { text: l }), e, note ? h('em', { text: note }) : null]); }
    function draw() {
      wrap.textContent = '';
      while (F.key.length < F.qn) F.key.push(0);
      F.key.length = F.qn;
      var kg = h('div', { class: 'bse-kg' }), sumT = h('h3'), sumKv = h('div', { class: 'bse-kv' });
      function sumUp() {
        sumT.textContent = F.title || 'آزمون بدون عنوان';
        sumKv.textContent = '';
        [['تعداد سؤال', fa(F.qn)], ['مدت', fa(F.dur) + ' دقیقه'], ['شروع', F.st ? dt(F.st) : '—'], ['پایان مهلت', F.en ? dt(F.en) : '—'], ['نمره منفی', F.neg ? 'دارد' : 'ندارد'], ['انتشار نتیجه', F.early_results ? 'پس از پایان زمان شخصی' : 'پس از پایان مهلت شرکت'],
          ['کلید ثبت‌شده', fa(F.key.filter(function (v) { return v; }).length) + ' از ' + fa(F.qn)]].forEach(function (r) {
          sumKv.appendChild(h('div', {}, [h('span', { text: r[0] }), h('b', { text: r[1] })]));
        });
      }
      function drawKey() {
        kg.textContent = '';
        for (var i = 0; i < F.qn; i++) (function (i) {
          var bs = [1, 2, 3, 4].map(function (o) {
            return h('button', { type: 'button', text: fa(o), onclick: function () { F.key[i] = o; paint(); sumUp(); } });
          });
          function paint() { bs.forEach(function (b, j) { b.classList.toggle('sel', F.key[i] === j + 1); }); }
          paint();
          kg.appendChild(h('div', { class: 'bse-sq' }, [h('span', { class: 'bse-qn', text: fa(i + 1) }), h('div', { class: 'bse-og' }, bs)]));
        })(i);
      }
      var ps = h('small', { text: 'می‌توانید چند PDF انتخاب کنید یا در چند مرحله فایل اضافه کنید.' });
      var upBox = h('div', { class: 'bse-up' }), fileList = h('div', { class: 'bse-upload-list' });
      function renderFiles() {
        fileList.textContent = ''; F.pdf = F.pdfs[0] || '';
        upBox.classList.toggle('ok', !!F.pdfs.length);
        F.pdfs.forEach(function (url, i) {
          fileList.appendChild(h('div', { class: 'bse-upload-row' }, [
            h('a', { href: url, target: '_blank', rel: 'noopener', text: pdfName(url, i) }),
            btn('حذف از آزمون', 'gh sm', function () {
              if (uploading) return;
              F.pdfs.splice(i, 1); renderFiles();
            }, 'trash')]));
        });
      }
      var pf = h('input', { type: 'file', accept: '.pdf,application/pdf', multiple: 'multiple', onchange: function () {
        var queue = Array.from(this.files || []); if (!queue.length || uploading) return;
        if (queue.some(function (f) { return !/\.pdf$/i.test(f.name); })) {
          toast('فقط فایل PDF انتخاب کنید'); this.value = ''; return;
        }
        uploading = true; pf.disabled = true;
        var failed = [], added = 0, total = queue.length;
        function next() {
          if (!queue.length) {
            uploading = false; pf.disabled = false; pf.value = '';
            ps.textContent = fa(added) + ' فایل اضافه شد.' + (failed.length ? ' آپلود ناموفق: ' + failed.join('، ') + '؛ دوباره انتخاب کنید.' : '');
            renderFiles(); return;
          }
          var f = queue.shift(); ps.textContent = 'در حال آپلود: ' + f.name;
          var fd = new FormData(); fd.append('action', 'bse_up'); fd.append('n', C.nonce); fd.append('f', f);
          post(fd, function (r) {
            if (r && r.url) { if (F.pdfs.indexOf(r.url) < 0) F.pdfs.push(r.url); added++; }
            else failed.push(f.name);
            renderFiles(); next();
          }, false, function (reason) { failed.push(f.name + (reason ? ' — ' + reason : '')); next(); });
        }
        next();
      } });
      upBox.appendChild(pf); upBox.appendChild(ps); upBox.appendChild(fileList); renderFiles();
      var qi = h('input', { type: 'number', class: 'bse-in', min: 1, max: 300, value: F.qn, onchange: function () {
        F.qn = Math.max(1, Math.min(300, parseInt(this.value, 10) || 1)); this.value = F.qn;
        while (F.key.length < F.qn) F.key.push(0);
        F.key.length = F.qn; drawKey(); sumUp();
      } });
      var quick = h('input', { type: 'text', class: 'bse-in', dir: 'ltr', placeholder: 'مثلاً 2,2,3,1,4,... (پشت‌سرهم)', oninput: function () {
        var v = this.value.replace(/[۰-۹]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c); }).replace(/[^1-4]/g, '');
        for (var i = 0; i < F.qn; i++) F.key[i] = +v.charAt(i) || 0;
        drawKey(); sumUp();
      } });
      var neg = h('input', { type: 'checkbox', onchange: function () { F.neg = this.checked ? 1 : 0; sumUp(); } });
      neg.checked = !!F.neg;
      var early = h('input', { type: 'checkbox', onchange: function () { F.early_results = this.checked ? 1 : 0; sumUp(); } });
      early.checked = !!F.early_results;
      var save = btn(id ? 'ذخیره تغییرات' : 'ذخیره و انتشار', 'pri wide lg', function () {
        if (saving) return;
        if (uploading || solutionUploading) { toast('تا پایان آپلود فایل‌ها صبر کنید'); return; }
        var miss = F.key.filter(function (v) { return !v; }).length;
        if (!F.title.trim()) { toast('عنوان آزمون را وارد کنید'); return; }
        if (!F.pdfs.length) { toast('حداقل یک فایل PDF سؤالات را آپلود کنید'); return; }
        if (miss) { toast('کلید ' + fa(miss) + ' سؤال هنوز مشخص نشده است'); return; }
        if (!F.st || !F.en) { toast('تاریخ و ساعت شروع و پایان را کامل کنید'); return; }
        if (F.en <= F.st) { toast('پایان مهلت باید بعد از شروع باشد'); return; }
        saving = true; save.classList.add('off');
        api('msave', { id: id, title: F.title, pdf: F.pdf, pdfs: JSON.stringify(F.pdfs), qn: F.qn, dur: F.dur, st: F.st, en: F.en, neg: F.neg, early_results: F.early_results, key: JSON.stringify(F.key), explanation_pdf: F.explanation_pdf },
          function (r) { toast('آزمون ذخیره شد', false); location.hash = '#/m/s/' + r.id; },
          false, function () { saving = false; save.classList.remove('off'); });
      }, 'check');
      wrap.appendChild(h('div', { class: 'bse-fm' }, [
        h('div', {}, [
          h('div', { class: 'bse-fc bse-first-info' }, [h('h2', { text: 'اطلاعات آزمون' }),
            fld('عنوان آزمون *', h('input', { type: 'text', class: 'bse-in', value: F.title, placeholder: 'مثال: ریاضی نوبت اول', oninput: function () { F.title = this.value; sumUp(); } })),
            h('h3',{class:'bse-top-schedule-title',text:'زمان‌بندی آزمون'}),
            h('div', { class: 'bse-two' }, [fld('شروع آزمون *', dtField(F.st, function (t) { F.st = t; sumUp(); })), fld('پایان مهلت آزمون *', dtField(F.en, function (t) { F.en = t; sumUp(); }))]),
            fld('مدت پاسخ‌گویی (دقیقه)', h('input', { type: 'number', class: 'bse-in', min: 1, value: F.dur, onchange: function () { F.dur = Math.max(1, parseInt(this.value, 10) || 1); this.value = F.dur; sumUp(); } }),
              'مهلت هر نفر: کمترِ «شروع او + مدت» و «پایان مهلت آزمون» است.'),
            fld('فایل‌های PDF سؤالات *', upBox)]),
          h('div', { class: 'bse-fc' }, [h('h2', { text: 'سؤال‌ها و کلید' }),
            fld('تعداد سؤال', qi), fld('ورود سریع کلید', quick, 'شماره‌ی گزینه‌ی درست هر سؤال را پشت‌سرهم بنویسید؛ کلید زیر خودکار پر می‌شود.'),
            h('div', { class: 'bse-fl' }, [h('span', { text: 'کلید پاسخ‌نامه *' }), kg])]),
          singleSolution(F,function(value){solutionUploading=value;}),
          h('div', { class: 'bse-fc' }, [h('h2', { text: 'تنظیمات' }),
            h('label', { class: 'bse-sw' }, [neg, h('span', { text: 'نمره منفی (هر ۳ پاسخ غلط، ۱ نمره کم می‌کند)' })]),
            h('label', { class: 'bse-sw' }, [early, h('span', { text: 'نمایش نتیجه و پاسخ‌نامه پس از پایان مدت پاسخ‌گویی هر فرد' })]),
            h('p', { class: 'bse-note', text: 'با فعال‌بودن این گزینه، حتی ثبت زودهنگام تا پایان زمان پاسخ‌گویی منتظر می‌ماند. سپس نمره، کلید و پاسخ‌نامه باز می‌شوند؛ رتبه و نفرات برتر تا پایان مهلت شرکت موقت‌اند.' })])]),
        h('aside', { class: 'bse-sum' }, [sumT, sumKv, id ? h('div', { class: 'bse-note', text: 'با ذخیره‌ی تغییرات، نتیجه‌ی شرکت‌کنندگان با کلید جدید دوباره محاسبه می‌شود.' }) : null, save, link('انصراف', id ? '#/m/s/' + id : '#/m', 'gh wide')])]));
      drawKey(); sumUp();
    }
  }

  /* چنددرس: ویرایشگر و پاسخ‌گویی مستقل؛ توابع تک‌درس دست‌نخورده می‌مانند. */
  function chooseType() {
    function card(multi){return h('section',{class:'bse-type-card '+(multi?'is-multi':'is-single')},[
      h('span',{class:'bse-type-tag',text:multi?'چنددرس':'تک‌درس'}),
      h('div',{class:'bse-type-icon'},[ico(multi?'copy':'file')]),
      h('h2',{text:multi?'آزمون چنددرس':'آزمون تک‌درس'}),
      h('p',{text:multi?'چند درس و یک یا چند دفترچه، با ضریب مستقل برای هر درس.':'یک درس، یک زمان پاسخ‌گویی.'}),
      link(multi?'ساخت آزمون چنددرس':'ساخت آزمون تک‌درس',multi?'#/m/multi':'#/m/single','pri wide')]);}
    mount(h('div',{class:'bse-wrap bse-type-chooser'},[
      h('h1',{text:'انتخاب نوع آزمون'}),
      h('div',{class:'bse-type-grid'},[card(false),card(true)]),
      h('div',{class:'bse-type-back'},[link('بازگشت','#/m','gh sm','back')])]));
  }
  function multiReport(d) {
    return h('section',{class:'bse-fc bsem-report'},(d.books||[]).map(function(b){
      return h('div',{class:'bsem-book-result'},[h('h3',{text:b.title+' — '+fn(b.pct,2)+'٪'}),
        h('div',{class:'bsem-table'},[h('div',{class:'bsem-tr bsem-head'},['درس','ضریب','درصد','صحیح / غلط / نزده'].map(function(t){return h('b',{text:t});}))].concat(b.subjects.map(function(s){return h('div',{class:'bsem-tr'},[h('span',{text:s.title}),h('span',{text:fa(s.weight)}),h('b',{text:fn(s.pct,2)+'٪'}),h('bdi',{dir:'ltr',text:fa(s.correct+' / '+s.wrong+' / '+s.blank)})]);}))) ]);
    }));
  }
  function multiForm(id, data) {
    if (!document.getElementById('bsem-editor-style-v31')) { var style=document.createElement('style');style.id='bsem-editor-style-v31';style.textContent="/* v3.1 — فقط فرم چنددرس؛ مستقل از قواعد فرم تک‌درس و قالب وردپرس */\n.bse .bsem-form{--blue:#258bf0;--blue-dark:#1679d5;--blue-soft:#e2f1ff;--border:#e5e0d8;--border-strong:#d8d2c9;--soft:#faf8f5;--surface:#fff;--ink:#17212f;--muted:#718093;container-type:inline-size;max-width:1280px!important;padding:20px!important;background:#faf8f5;border-radius:18px;line-height:1.7}\n.bse .bsem-form h1,.bse .bsem-form h2,.bse .bsem-form h3,.bse .bsem-form p{margin:0;text-align:right}\n.bse .bsem-form h1{font-size:21px!important;font-weight:850;line-height:1.7}\n.bse .bsem-form h2{font-size:15px!important;font-weight:800}\n.bse .bsem-form .bse-btn{min-height:34px;height:auto;padding:6px 11px;border-radius:9px;font-size:12px;font-weight:750;box-shadow:none;white-space:nowrap;gap:6px}\n.bse .bsem-form .bse-btn.pri{background:#258bf0;border:1.5px solid #17212f;box-shadow:2px 2px 0 #17212f;color:#fff;padding:9px 18px}\n.bse .bsem-form .bse-btn.gh{background:white;border:1px solid #e5e0d8;color:#526076}\n.bse .bsem-form .bse-btn.gh:hover{background:#f4f8fc;border-color:#b6d5f1}\n.bse .bsem-header{display:flex!important;justify-content:space-between;align-items:center;gap:14px;margin:0 0 22px}\n.bse .bsem-header small{display:block;color:#7b8795;font-size:11px;margin-bottom:3px}\n.bse .bsem-header-actions{display:flex!important;align-items:center;gap:9px}\n.bse .bsem-form .bsem-editor{display:grid!important;grid-template-columns:minmax(0,1fr) 292px!important;gap:20px;align-items:start;direction:rtl}\n.bse .bsem-main{min-width:0;display:block}\n.bse .bsem-general,.bse .bsem-book,.bse .bsem-keys{background:#fff;border:1px solid #e5e0d8;border-radius:15px;box-shadow:0 2px 3px #26323802;overflow:hidden}\n.bse .bsem-general{padding:18px;margin-bottom:23px}\n.bse .bsem-general>h2{margin-bottom:14px}\n.bse .bsem-form .bse-fl{display:block!important;min-width:0;margin:0}\n.bse .bsem-form .bse-fl>span{display:block;color:#677587;font-size:11px;font-weight:650;margin:0 0 5px}\n.bse .bsem-form .bse-in{width:100%!important;min-width:0;height:38px!important;min-height:38px!important;padding:6px 10px!important;border:1px solid #ded8d0!important;border-radius:8px!important;background:#fff!important;font-size:12px!important;line-height:1.5!important;box-shadow:none!important;color:#243248}\n.bse .bsem-form .bse-in:focus{border-color:#258bf0!important;outline:2px solid #e2f1ff;outline-offset:1px}\n.bse .bsem-form input[type=number]{appearance:textfield;text-align:center;direction:ltr}\n.bse .bsem-form input[type=number]::-webkit-inner-spin-button{appearance:none}\n.bse .bsem-dates{display:grid!important;grid-template-columns:1fr 1fr;gap:12px;margin-top:14px}\n.bse .bsem-dates .bse-dt{min-width:0}\n.bse .bsem-dates input{font-size:11px!important}\n.bse .bsem-settings{margin-top:15px;border-top:1px solid #eee9e3;padding-top:10px;font-size:12px}\n.bse .bsem-settings summary{cursor:pointer;color:#526076;font-weight:750;padding:4px 0}\n.bse .bsem-settings .bse-sw{display:flex!important;align-items:center;gap:8px;margin:12px 0;font-size:12px}\n.bse .bsem-settings p{font-size:11px;color:#778393;line-height:1.9}\n.bse .bsem-section-title{display:flex!important;align-items:center;justify-content:space-between;gap:10px;margin:0 0 11px}\n.bse .bsem-section-title>span{color:#7b8795;font-size:10px}\n.bse .bsem-book{padding:16px;margin:0 0 15px}\n.bse .bsem-book-head{display:flex!important;align-items:center;justify-content:space-between;gap:8px;margin-bottom:14px}\n.bse .bsem-book-label{display:flex!important;align-items:center;gap:8px;font-size:13px}\n.bse .bsem-book-label>span{display:grid;place-items:center;width:26px;height:26px;background:#e2f1ff;color:#1683e7;border-radius:8px;font-size:12px;font-weight:800}\n.bse .bsem-form .bsem-tools{display:flex!important;gap:5px;margin:0;flex-wrap:nowrap}\n.bse .bsem-tools .bse-btn{font-size:10px;min-height:27px;padding:3px 6px;gap:3px}\n.bse .bsem-tools .bse-i{width:12px;height:12px}\n.bse .bsem-book-meta{display:grid!important;grid-template-columns:minmax(0,1fr) 122px;gap:12px;align-items:end}\n.bse .bsem-upload{padding:10px 0;margin:10px 0 12px;border-bottom:1px solid #eee9e3}\n.bse .bsem-upload-caption{display:flex!important;align-items:center;gap:7px;font-size:11px;color:#738093}\n.bse .bsem-upload-caption>.bse-btn{margin-right:auto;border-style:dashed;color:#258bf0;font-size:10px;min-height:28px}\n.bse .bsem-form input.bsem-file-input{display:none!important}\n.bse .bsem-upload>small{display:block;color:#258bf0;font-size:10px}\n.bse .bsem-file{display:flex!important;align-items:center;gap:8px;padding:7px 9px;background:#f7fafc;border:1px solid #e6edf1;border-radius:8px;margin-top:8px}\n.bse .bsem-file>.bse-i{color:#258bf0;width:16px;height:16px;flex:none}\n.bse .bsem-file a{font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:ltr;text-align:right;min-width:0;flex:1}\n.bse .bsem-file .bse-btn{border:0;background:transparent;min-height:24px;padding:2px 5px;font-size:10px;color:#8994a1}\n.bse .bsem-form .bsem-sub-head,.bse .bsem-form .bsem-sub{display:grid!important;grid-template-columns:minmax(0,1fr) 82px 68px 29px!important;gap:8px;align-items:center}\n.bse .bsem-sub-head{color:#788394;font-size:10px;padding:0 3px 7px}\n.bse .bsem-sub-head>span:not(:first-child){text-align:center}\n.bse .bsem-form .bsem-sub{border:0!important;padding:0!important;margin:0 0 8px!important}\n.bse .bsem-sub .bse-fl>span{position:absolute!important;width:1px!important;height:1px!important;overflow:hidden;clip-path:inset(50%)}\n.bse .bsem-sub>.bse-btn{width:29px;min-height:29px;border:0!important;background:transparent!important;padding:4px;overflow:hidden;font-size:0!important;gap:0;color:#97a1ac}\n.bse .bsem-sub>.bse-btn>.bse-i{width:15px;height:15px;flex:none}\n.bse .bsem-sub>.bse-btn:hover{color:#e14e61}\n.bse .bsem-book-foot{display:flex!important;align-items:center;justify-content:space-between;margin-top:10px}\n.bse .bsem-book-foot>.bse-btn{color:#258bf0!important;background:#eff7ff!important;border-color:transparent!important;font-size:10px}\n.bse .bsem-book-foot>small{font-size:10px;color:#8a95a2}\n.bse .bsem-books>.bse-btn{width:100%;padding:11px;border-style:dashed;background:transparent;color:#258bf0}\n.bse .bsem-form .bsem-keys{position:sticky;top:48px;padding:0!important;min-width:0;align-self:start}\n.bse .bsem-key-top{display:flex!important;align-items:center;justify-content:space-between;padding:16px 15px 11px}\n.bse .bsem-key-top>h2{font-size:14px!important}\n.bse .bsem-key-top>b{font-size:11px;color:#258bf0}\n.bse .bsem-progress{height:3px;background:#f1ede7}\n.bse .bsem-progress>i{height:3px;display:block;background:#258bf0;transition:width .15s}\n.bse .bsem-quick{padding:12px 14px;border-bottom:1px solid #eee9e3}\n.bse .bsem-quick .bse-in{height:33px!important;min-height:33px!important;font-size:11px!important}\n.bse .bsem-key-scroll{max-height:65vh;min-height:120px;overflow-y:auto;overscroll-behavior:contain;scrollbar-width:thin;padding:0 13px 12px}\n.bse .bsem-key-book{display:flex!important;align-items:center;justify-content:space-between;padding:14px 2px 7px;font-size:11px;border-top:1px solid #eae5de;margin-top:8px}\n.bse .bsem-key-book:first-child{border-top:0;margin-top:0}\n.bse .bsem-key-book>span{font-size:10px;color:#8a95a2}\n.bse .bsem-key-sub{display:flex!important;align-items:center;justify-content:space-between;background:#faf8f5;border:1px solid #efeae4;border-radius:8px;padding:6px 8px;font-size:10px;margin:5px 0}\n.bse .bsem-key-sub>small{font-size:9px;color:#8290a0}\n.bse .bsem-form .bsem-key-row{display:flex!important;flex-wrap:nowrap!important;align-items:center;gap:7px;width:100%;padding:4px 0!important;margin:0!important;border:0!important;border-radius:0!important;border-bottom:1px solid #f3efea!important;background:transparent}\n.bse .bsem-qnum{display:grid!important;place-items:center;width:26px;height:26px;flex:none;border:1px solid #e2dcd4;border-radius:50%;font-size:10px;color:#526076}\n.bse .bsem-options{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr));gap:5px;flex:1;min-width:0}\n.bse .bsem-form .bsem-choice{display:block!important;width:100%!important;height:28px!important;min-height:28px!important;padding:0!important;margin:0!important;background:#fff!important;border:1px solid #dbd5cd!important;border-radius:7px!important;color:#4d617c!important;font-size:11px!important;box-shadow:none!important;line-height:26px!important;text-align:center!important}\n.bse .bsem-form .bsem-choice.sel{background:#258bf0!important;border:1.5px solid #17212f!important;color:#fff!important;box-shadow:1px 1px 0 #17212f!important}\n.bse .bsem-form .bsem-choice:hover{border-color:#258bf0!important}\n.bse .bsem-error{background:#fff1f2;border:1px solid #f8c3cb;border-radius:10px;color:#b72840;padding:12px 15px;margin-bottom:15px;font-size:12px}\n.bse .bsem-error[hidden]{display:none!important}\n.bse .bsem-invalid{outline:2px solid #ef6175!important;outline-offset:4px}\n.bse .bsem-lock-note{font-size:12px;color:#7c6333;margin-bottom:14px}\n.bse .bsem-form button:disabled{opacity:.35;cursor:not-allowed}\n@container(max-width:760px){.bse .bsem-form .bsem-editor{grid-template-columns:minmax(0,1fr)!important}.bse .bsem-form .bsem-keys{position:static}.bse .bsem-key-scroll{max-height:450px}.bse .bsem-header{align-items:flex-start}.bse .bsem-header h1{font-size:18px!important}.bse .bsem-section-title{flex-wrap:wrap}}\n@container(max-width:480px){.bse .bsem-dates{grid-template-columns:1fr}.bse .bsem-book-meta{grid-template-columns:minmax(0,1fr) 90px}.bse .bsem-form .bsem-sub-head,.bse .bsem-form .bsem-sub{grid-template-columns:minmax(0,1fr) 61px 51px 24px!important;gap:5px}.bse .bsem-book{padding:12px}.bse .bsem-book-head{flex-wrap:wrap}.bse .bsem-header{flex-wrap:wrap}.bse .bsem-header-actions{width:100%;justify-content:flex-end}.bse .bsem-tools .bse-btn{font-size:9px}.bse .bsem-form .bse-in{padding:5px 7px!important}}\n@media(max-width:600px){.bse .bsem-form{padding:12px!important}.bse .bsem-form .bsem-editor{grid-template-columns:minmax(0,1fr)!important}.bse .bsem-form .bsem-keys{position:static}}\n\n.bse .bsem-form .bsem-sub>.bse-fl{grid-column:auto!important}\n.bse .bsem-form .bse-dfb{height:38px;border-radius:8px;font-size:11px;padding:0 9px;gap:6px}\n.bse .bsem-form .bse-time24 select{height:38px;min-height:38px;font-size:11px;border-radius:8px}\n";document.head.appendChild(style); }
    if(!document.getElementById('bsem-style-v33')){var extraStyle=document.createElement('style');extraStyle.id='bsem-style-v33';extraStyle.textContent="/* تقویم باید بتواند از کادر اطلاعات آزمون بیرون بیاید. */\n.bse .bsem-form .bsem-general{overflow:visible!important;position:relative;z-index:5}\n.bse .bsem-form .bsem-main{overflow:visible!important}\n.bse .bsem-form .bse-cal{z-index:1000;max-width:calc(100vw - 32px)}\n.bse .bsem-form .bsem-solution{background:#fff;border:1px solid #e5e0d8;border-radius:15px;padding:18px;margin-top:20px}\n.bse .bsem-form .bsem-solution>h2{margin:0 0 14px;font-size:14px!important}\n.bse .bsem-form .bsem-solution-drop{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:24px 15px;border:1.5px dashed #d5e2ed;border-radius:12px;background:#fafcfe;text-align:center;transition:background .15s,border-color .15s}\n.bse .bsem-form .bsem-solution-drop.drag{background:#e2f1ff;border-color:#258bf0}\n.bse .bsem-form .bsem-solution-drop>.bse-i{width:35px;height:35px;padding:8px;border-radius:10px;color:#258bf0;background:#eaf6ff}\n.bse .bsem-form .bsem-solution-drop>b{font-size:12px;font-weight:750}\n.bse .bsem-form .bsem-solution-drop>p{font-size:11px;color:#8391a0;text-align:center}\n.bse .bsem-form .bsem-solution-drop>.bse-btn{background:#17212f;color:white;border:0;padding:8px 15px}\n.bse .bsem-form .bsem-solution>small{display:block;margin-top:8px;color:#258bf0;font-size:11px}\n.bse .bsem-form .bsem-solution.has-file .bsem-solution-drop{padding:15px}\n";document.head.appendChild(extraStyle);}
    data=data||{};
    var F={explanation_pdf:data.explanation_pdf||'',title:data.title||'',st:data.st||0,en:data.en||0,neg:data.neg===0?0:1,early_results:data.early_results?1:0,books:JSON.parse(JSON.stringify(data.books||[]))};
    var cursor=0,all=data.key||[],busy=false,uploads=0,locked=!!data.multi_locked;
    F.books.forEach(function(b){b.subjects.forEach(function(s){s._key=all.slice(cursor,cursor+s.count);cursor+=s.count;});});
    function newSub(){return {title:'',count:10,weight:1,_key:[]};}
    function newBook(){return {title:'دفترچه '+fa(F.books.length+1),duration:20,pdfs:[],subjects:[newSub()]};}
    if(!F.books.length)F.books.push(newBook());
    function fld(label,el){return h('label',{class:'bse-fl'},[h('span',{text:label}),el]);}
    function inp(label,value,change,type,min,max,disabled){var el=h('input',{class:'bse-in',type:type||'text',value:value,onchange:function(){notice.hidden=true;if(errorTarget)errorTarget.classList.remove('bsem-invalid');change(this.value);}});if(min!==undefined)el.min=min;if(max!==undefined)el.max=max;el.disabled=!!disabled;return fld(label,el);}
    var container=h('div',{class:'bsem-books'}),keyArea=h('div',{class:'bsem-key-scroll'}),summary=h('span'),filledText=h('b'),fill=h('i'),notice=h('div',{class:'bsem-error',role:'alert',hidden:'hidden'}),errorTarget=null;
    function totals(){var q=0,t=0,n=0;F.books.forEach(function(b){t+=+b.duration;b.subjects.forEach(function(s){q+=+s.count;n+=s._key.filter(function(v){return v>=1&&v<=4;}).length;});});return {q:q,t:t,n:n};}
    function update(){var t=totals();summary.textContent=fa(F.books.length)+' دفترچه · '+fa(t.q)+' سؤال · '+fa(t.t)+' دقیقه';filledText.textContent=fa(t.n)+' از '+fa(t.q);fill.style.width=(t.q?100*t.n/t.q:0)+'%';}
    function fail(message,target){notice.hidden=false;notice.textContent=message;toast(message);if(errorTarget)errorTarget.classList.remove('bsem-invalid');errorTarget=target||notice;errorTarget.classList.add('bsem-invalid');errorTarget.scrollIntoView({behavior:'smooth',block:'center'});var el=errorTarget.querySelector('input:not([disabled])');if(el)el.focus({preventScroll:true});}
    function keys(){
      keyArea.textContent='';var q=0;
      F.books.forEach(function(b,bi){
        keyArea.appendChild(h('div',{class:'bsem-key-book'},[h('b',{text:b.title||'دفترچه '+fa(bi+1)}),h('span',{text:fa(b.duration)+' دقیقه'})]));
        b.subjects.forEach(function(s){
          while(s._key.length<s.count)s._key.push(0);s._key.length=s.count;
          var start=q;keyArea.appendChild(h('div',{class:'bsem-key-sub'},[h('b',{text:s.title||'نام درس'}),h('small',{text:'سؤال '+fa(q+1)+' تا '+fa(q+s.count)})]));
          for(var j=0;j<s.count;j++)(function(j){var bs=[1,2,3,4].map(function(v){return h('button',{type:'button',class:'bsem-choice'+(s._key[j]===v?' sel':''),'aria-label':'سؤال '+fa(start+j+1)+' گزینه '+fa(v),'aria-pressed':s._key[j]===v?'true':'false',text:fa(v),onclick:function(){s._key[j]=v;bs.forEach(function(el,k){el.classList.toggle('sel',k+1===v);el.setAttribute('aria-pressed',k+1===v?'true':'false');});update();}});});
            keyArea.appendChild(h('div',{class:'bse-sq bsem-key-row'},[h('span',{class:'bsem-qnum',text:fa(start+j+1)}),h('div',{class:'bsem-options'},bs)]));
          })(j);q+=s.count;
        });
      });update();
    }
    function draw(){
      container.textContent='';var offset=0;
      F.books.forEach(function(b,bi){
        var box=h('section',{class:'bsem-book','data-book':bi}),tools=h('div',{class:'bsem-tools'});
        function tool(text,icon,fn,disabled){var bt=btn(text,'gh sm',function(){if(uploads||busy)return;fn();draw();keys();},icon);bt.disabled=locked||disabled;tools.appendChild(bt);}
        tool('بالا','chr',function(){var x=F.books.splice(bi,1)[0];F.books.splice(bi-1,0,x);},bi===0);
        tool('پایین','chl',function(){var x=F.books.splice(bi,1)[0];F.books.splice(bi+1,0,x);},bi===F.books.length-1);
        tool('حذف دفترچه','trash',function(){F.books.splice(bi,1);},F.books.length===1);
        box.appendChild(h('div',{class:'bsem-book-head'},[h('div',{class:'bsem-book-label'},[h('span',{text:fa(bi+1)}),h('b',{text:'دفترچه '+fa(bi+1)})]),tools]));
        var name=inp('عنوان دفترچه',b.title,function(v){b.title=v;keys();},'text',undefined,undefined,locked);
        var duration=inp('مدت دفترچه (دقیقه)',b.duration,function(v){b.duration=Math.max(1,Math.min(1440,Math.floor(+v)||1));draw();keys();},'number',1,1440,locked);
        box.appendChild(h('div',{class:'bsem-book-meta'},[name,duration]));
        var files=h('div',{class:'bsem-file-list'}),status=h('small',{role:'status'});
        b.pdfs.forEach(function(url,fi){var del=btn('حذف','gh sm',function(){if(uploads||busy)return;b.pdfs.splice(fi,1);draw();},'x');del.disabled=locked;files.appendChild(h('div',{class:'bsem-file'},[ico('file'),h('a',{href:url,target:'_blank',rel:'noopener',text:pdfName(url,fi)}),del]));});
        var up=h('input',{type:'file',accept:'.pdf,application/pdf',multiple:'multiple',class:'bsem-file-input','aria-label':'PDF دفترچه '+fa(bi+1),onchange:function(){
          var queue=Array.from(this.files||[]);if(!queue.length)return;if(queue.some(function(f){return !/\.pdf$/i.test(f.name);})){fail('دفترچه '+fa(bi+1)+': فقط فایل PDF انتخاب کنید.',box);return;}
          uploads++;up.disabled=true;
          function next(){if(!queue.length){uploads--;up.disabled=locked;up.value='';draw();return;}var file=queue.shift();status.textContent='در حال آپلود '+file.name;var fd=new FormData();fd.append('action','bse_up');fd.append('n',C.nonce);fd.append('f',file);post(fd,function(r){if(r&&r.url&&b.pdfs.indexOf(r.url)<0){b.pdfs.push(r.url);notice.hidden=true;if(errorTarget)errorTarget.classList.remove('bsem-invalid');}next();},false,function(reason){fail(reason||('آپلود فایل «'+file.name+'» در دفترچه '+fa(bi+1)+' انجام نشد؛ دوباره انتخاب کنید.'),box);next();});}next();
        }});up.disabled=locked;
        var upload=btn(b.pdfs.length?'افزودن فایل دیگر':'بارگذاری PDF سؤالات','gh sm',function(){up.click();},'plus');upload.disabled=locked;
        box.appendChild(h('div',{class:'bsem-upload'},[h('div',{class:'bsem-upload-caption'},[ico('file'),h('span',{text:'فایل سؤالات'}),upload]),up,files,status]));
        var table=h('div',{class:'bsem-sub-table'},[h('div',{class:'bsem-sub-head'},['نام درس','تعداد سؤال','ضریب',''].map(function(t){return h('span',{text:t});}))]);
        b.subjects.forEach(function(s,si){
          var from=offset+1;offset+=+s.count;
          var row=h('div',{class:'bsem-sub','data-sub':si});
          row.appendChild(inp('نام درس',s.title,function(v){s.title=v;keys();},'text',undefined,undefined,locked));
          row.appendChild(inp('تعداد سؤال',s.count,function(v){s.count=Math.max(1,Math.min(1000,Math.floor(+v)||1));draw();keys();},'number',1,1000,locked));
          row.appendChild(inp('ضریب',s.weight,function(v){s.weight=+v;keys();},'number',0.01,1000,locked));
          var del=btn('حذف درس','gh sm',function(){if(uploads||busy)return;b.subjects.splice(si,1);draw();keys();},'trash');del.disabled=locked||b.subjects.length===1;del.title='حذف درس';row.appendChild(del);table.appendChild(row);
        });box.appendChild(table);
        var add=btn('افزودن درس','gh sm',function(){if(uploads||busy)return;b.subjects.push(newSub());draw();keys();},'plus');add.disabled=locked;
        box.appendChild(h('div',{class:'bsem-book-foot'},[add,h('small',{text:fa(b.subjects.reduce(function(n,s){return n+s.count;},0))+' سؤال در این دفترچه'})]));container.appendChild(box);
      });
      var add=btn('افزودن دفترچه','gh wide',function(){if(uploads||busy)return;F.books.push(newBook());draw();keys();},'plus');add.disabled=locked;container.appendChild(add);update();
    }
    var neg=h('input',{type:'checkbox',onchange:function(){F.neg=this.checked?1:0;}});neg.checked=!!F.neg;
    var early=h('input',{type:'checkbox',onchange:function(){F.early_results=this.checked?1:0;}});early.checked=!!F.early_results;
    var save=btn(id?'ذخیره تغییرات':'ذخیره و انتشار','pri',function(){
      if(busy)return;if(uploads){fail('آپلود فایل‌ها هنوز تمام نشده است.');return;}
      notice.hidden=true;if(errorTarget)errorTarget.classList.remove('bsem-invalid');
      if(!F.title.trim()){fail('عنوان آزمون را وارد کنید.',general);return;}
      if(!F.st||F.en<=F.st){fail('تاریخ و ساعت شروع و پایان شرکت را کامل کنید؛ پایان باید بعد از شروع باشد.',general);return;}
      var t=totals(),key=[],books=F.books.map(function(b){return {title:b.title,duration:b.duration,pdfs:b.pdfs,subjects:b.subjects.map(function(s){key=key.concat(s._key);return {title:s.title,count:s.count,weight:s.weight};})};});
      if(t.q>1000||t.t>1440){fail('حداکثر ۱۰۰۰ سؤال و ۱۴۴۰ دقیقه مجاز است.');return;}
      for(var bi=0;bi<books.length;bi++){
        var b=books[bi],box=container.querySelector('[data-book="'+bi+'"]'),prefix='دفترچه '+fa(bi+1)+' «'+(b.title||'بدون عنوان')+'»: ';
        if(!b.title.trim()){fail('عنوان دفترچه '+fa(bi+1)+' را وارد کنید.',box);return;}
        if(!b.pdfs.length){fail(prefix+'فایل PDF سؤالات بارگذاری نشده است.',box.querySelector('.bsem-upload'));return;}
        for(var si=0;si<b.subjects.length;si++){var s=b.subjects[si],row=box.querySelector('[data-sub="'+si+'"]');if(!s.title.trim()){fail(prefix+'نام درس '+fa(si+1)+' خالی است.',row);return;}if(!(s.weight>0&&s.weight<=1000)){fail(prefix+'ضریب درس «'+s.title+'» باید بیشتر از صفر و حداکثر ۱۰۰۰ باشد.',row);return;}}
      }
      for(var qi=0;qi<key.length;qi++)if(!(key[qi]>=1&&key[qi]<=4)){fail('گزینه صحیح سؤال '+fa(qi+1)+' در کلید مشخص نشده است.',keyArea);return;}
      busy=true;save.disabled=true;
      api('mm_save',{id:id,title:F.title,st:F.st,en:F.en,neg:F.neg,early_results:F.early_results,books:JSON.stringify(books),key:JSON.stringify(key),explanation_pdf:F.explanation_pdf},function(r){busy=false;toast('آزمون چنددرس ذخیره شد',false);location.hash='#/m/s/'+r.id;},false,function(){busy=false;save.disabled=false;});
    },'check');
    var st=dtField(F.st,function(t){F.st=t;}),en=dtField(F.en,function(t){F.en=t;});
    if(locked){st.querySelectorAll('input,button,select').forEach(function(e){e.disabled=true;});en.querySelectorAll('input,button,select').forEach(function(e){e.disabled=true;});}
    var general=h('section',{class:'bsem-general'},[h('h2',{text:'اطلاعات آزمون'}),inp('عنوان آزمون',F.title,function(v){F.title=v;}),h('h3',{class:'bse-top-schedule-title',text:'زمان‌بندی آزمون'}),h('div',{class:'bsem-dates'},[fld('شروع شرکت',st),fld('پایان مهلت شرکت',en)]),h('details',{class:'bsem-settings'},[h('summary',{text:'تنظیمات نمره و انتشار نتیجه'}),h('label',{class:'bse-sw'},[neg,h('span',{text:'نمره منفی؛ هر سه غلط، یک درست'})]),h('label',{class:'bse-sw'},[early,h('span',{text:'انتشار نتیجه پس از پایان زمان شخصی'})]),h('p',{text:'هر دفترچه زمان مستقل دارد. زمان باقی‌مانده منتقل نمی‌شود. تحویل زودتر، موعد انتشار نتیجه را جلو نمی‌اندازد.'})])]);
    var quick=h('input',{class:'bse-in',dir:'ltr',placeholder:'مثلاً ۱۲۳۴۱۲…','aria-label':'ورود سریع کلید همه سؤال‌ها',oninput:function(){var text=this.value.replace(/[۰-۹]/g,function(c){return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c);}).replace(/[١-٤]/g,function(c){return '١٢٣٤'.indexOf(c)+1;}).replace(/[^1-4]/g,'');var i=0;F.books.forEach(function(b){b.subjects.forEach(function(s){for(var j=0;j<s.count;j++)s._key[j]=+text.charAt(i++)||0;});});keys();}});
    var sidebar=h('aside',{class:'bsem-keys'},[h('div',{class:'bsem-key-top'},[h('h2',{text:'کلید پاسخ‌نامه'}),filledText]),h('div',{class:'bsem-progress'},[fill]),h('div',{class:'bsem-quick'},[fld('ورود سریع کلید',quick)]),keyArea]);
    /* پاسخ‌نامهٔ تشریحی کل آزمون، مستقل از PDF سؤال‌های دفترچه‌ها. */
    var solutionBox=h('section',{class:'bsem-solution'}),solutionFiles=h('div',{class:'bsem-solution-files'}),solutionStatus=h('small',{role:'status','aria-live':'polite'}),solutionBusy=false;
    function paintSolution(){
      solutionFiles.textContent='';solutionBox.classList.toggle('has-file',!!F.explanation_pdf);
      if(F.explanation_pdf)solutionFiles.appendChild(h('div',{class:'bsem-file'},[ico('file'),h('a',{href:F.explanation_pdf,target:'_blank',rel:'noopener',text:pdfName(F.explanation_pdf,0)}),btn('حذف','gh sm',function(){if(solutionBusy)return;F.explanation_pdf='';paintSolution();},'x')]));
    }
    function uploadSolution(files){
      if(solutionBusy||busy)return;var file=files&&files[0];if(!file)return;
      if(files.length!==1||!/\.pdf$/i.test(file.name)){fail('برای پاسخ‌نامهٔ تشریحی یک فایل PDF انتخاب کنید.',solutionBox);return;}
      solutionBusy=true;uploads++;solutionInput.disabled=true;solutionStatus.textContent='در حال بارگذاری '+file.name+'…';
      var fd=new FormData();fd.append('action','bse_up');fd.append('n',C.nonce);fd.append('f',file);
      function finish(){solutionBusy=false;uploads--;solutionInput.disabled=false;solutionInput.value='';}
      post(fd,function(r){finish();if(r&&r.url){F.explanation_pdf=r.url;notice.hidden=true;solutionStatus.textContent='پاسخ‌نامهٔ تشریحی بارگذاری شد.';paintSolution();}else{solutionStatus.textContent='';fail('بارگذاری پاسخ‌نامهٔ تشریحی انجام نشد؛ دوباره تلاش کنید.',solutionBox);}},false,function(reason){finish();solutionStatus.textContent=reason||'بارگذاری پاسخ‌نامهٔ تشریحی انجام نشد؛ دوباره انتخاب کنید.';});
    }
    var solutionInput=h('input',{type:'file',accept:'.pdf,application/pdf',class:'bsem-file-input','aria-label':'فایل پاسخ‌نامه تشریحی',onchange:function(){uploadSolution(this.files);}});
    var drop=h('div',{class:'bsem-solution-drop'},[ico('file'),h('b',{text:'بارگذاری پاسخ‌نامهٔ تشریحی'}),h('p',{text:'فایل PDF را اینجا رها کنید یا انتخاب کنید.'}),btn('انتخاب فایل','gh',function(){solutionInput.click();},'file'),solutionInput]);
    drop.addEventListener('dragover',function(e){e.preventDefault();drop.classList.add('drag');});drop.addEventListener('dragleave',function(){drop.classList.remove('drag');});drop.addEventListener('drop',function(e){e.preventDefault();drop.classList.remove('drag');uploadSolution(e.dataTransfer.files);});
    solutionBox.appendChild(h('h2',{text:'پاسخ‌نامهٔ تشریحی'}));solutionBox.appendChild(drop);solutionBox.appendChild(solutionFiles);solutionBox.appendChild(solutionStatus);paintSolution();

    mount(h('div',{class:'bse-wrap bsem-form'},[h('header',{class:'bsem-header'},[h('div',{},[h('small',{text:'آزمون‌های من / آزمون چنددرس'}),h('h1',{text:id?'ویرایش آزمون چنددرس':'ساخت آزمون چنددرس'})]),h('div',{class:'bsem-header-actions'},[link('انصراف',id?'#/m/s/'+id:'#/m','gh'),save])]),notice,
      locked?h('p',{class:'bsem-lock-note',text:'شرکت‌کننده ثبت شده است؛ ساختار و زمان‌بندی قفل است. عنوان، کلید و تنظیمات نتیجه قابل ویرایش‌اند.'}):null,
      h('div',{class:'bsem-editor'},[h('main',{class:'bsem-main'},[general,h('div',{class:'bsem-section-title'},[h('h2',{text:'دفترچه‌ها و درس‌ها'}),summary]),container,solutionBox]),sidebar])]));draw();keys();
  }
  function multiTake(id,d,preview) {
    S.off=d.now-Math.floor(Date.now()/1000);
    var A={},dirty=false,busy=false,finishing=false,done=false,retry=null,lastSend=0,retryAt=0,failures=0;
    Object.keys(d.answers||{}).forEach(function(k){A[k]=+d.answers[k];});
    var clock=h('b'),tbox=h('div',{class:'bse-tm'},[ico('clock'),clock,h('small',{text:'باقی‌مانده دفترچه'})]),progress=h('span'),count=h('p'),status=h('small',{role:'status','aria-live':'polite',text:'پاسخ‌ها ذخیره شده‌اند'});
    var sheet=h('aside',{class:'bse-sh'}),scroll=h('div',{class:'bse-shs'}),mob=mobShell(sheet,[h('b',{text:'پاسخ‌برگ'}),h('span',{text:d.book.title})]);
    var submit=btn(d.index+1<d.book_count?'تحویل و شروع دفترچه بعد':'ثبت نهایی آزمون','pri wide',ask,'check');
    function update(){var n=Object.keys(A).length;count.textContent=fa(n)+' پاسخ · '+fa(d.qn-n)+' بدون پاسخ';progress.style.width=(100*n/d.qn)+'%';}
    var draft=answerDraft(id,preview,d,d.index);dirty=draft.restore(A);
    function active(){return !done&&S.ov&&S.ov.contains(sheet);}
    function plan(){
      if(!active()||busy)return;
      if(dirty&&!finishing&&retryAt<=Date.now()&&d.deadline-now()<=2){clearTimeout(retry);retry=null;send(true);return;}
      if(retry!==null)return;
      var wait=Math.max(retryAt-Date.now(),finishing?0:lastSend+2500-Date.now(),finishing?0:1000);
      retry=setTimeout(function(){retry=null;send();},Math.max(0,wait));
    }
    function send(force){
      if(!active()||busy||(!dirty&&!finishing))return;
      if(!force&&retryAt>Date.now()){plan();return;}
      clearTimeout(retry);retry=null;busy=true;dirty=false;lastSend=Date.now();var final=finishing;
      status.textContent=final?'در حال تحویل دفترچه…':'در حال ذخیره…';
      (preview==='practice'?practiceApi:preview?previewApi:api)(final?'submit':'save',{id:id,book:d.index,answers:JSON.stringify(A)},function(r){
        busy=false;if(!active())return;failures=0;retryAt=0;
        if(r.over){done=true;draft.clear();clearTimeout(retry);location.hash=preview?previewHash('result',id,preview):'#/r/'+id;return;}
        if(r.index!==d.index){done=true;draft.clear();clearTimeout(retry);multiTake(id,r,preview);return;}
        if(!dirty)draft.clear();status.textContent=dirty?'پاسخ‌های تازه در انتظار ذخیره‌اند…':'پاسخ‌ها ذخیره شده‌اند';
        if(finishing)send(true);else if(dirty)plan();
      },true,function(){
        busy=false;if(!active())return;dirty=true;failures++;retryAt=Date.now()+saveRetryDelay(failures);
        status.textContent='ذخیره روی سرور تأیید نشد؛ با فاصله دوباره تلاش می‌کنیم. صفحه را نبندید.';
        if(finishing&&!final)send(true);else plan();
      });
    }
    function finish(){if(done||finishing)return;finishing=true;clearTimeout(retry);retry=null;retryAt=0;submit.disabled=true;scroll.querySelectorAll('button').forEach(function(b){b.disabled=true;});S.mdl.slice().forEach(function(c){c();});send(true);}
    function ask(){var n=Object.keys(A).length;modal({icon:'check',title:'این دفترچه تحویل داده شود؟',ok:d.index+1<d.book_count?'تحویل و شروع بعدی':'پایان آزمون',body:[rules([fa(n)+' سؤال پاسخ داده‌اید و '+fa(d.qn-n)+' سؤال بدون پاسخ است.','پس از تحویل، امکان بازگشت و تغییر پاسخ‌های این دفترچه وجود ندارد.',d.index+1<d.book_count?'زمان دفترچه بعد فوراً شروع می‌شود.':'پاسخ‌های کل آزمون ثبت نهایی می‌شود.'])],onok:finish});}
    d.book.subjects.forEach(function(s){
      scroll.appendChild(h('h3',{class:'bsem-group',text:s.title+' · سؤال '+fa(s.from)+' تا '+fa(s.to)}));
      for(var q=s.from;q<=s.to;q++)(function(q){var bs=[1,2,3,4].map(function(v){return h('button',{type:'button',text:fa(v),onclick:function(){if(finishing||now()>=d.deadline){finish();return;}if(A[q]===v)delete A[q];else A[q]=v;bs.forEach(function(b,i){b.classList.toggle('sel',A[q]===i+1);});dirty=true;draft.write(A);status.textContent='پاسخ‌های تازه در انتظار ذخیره‌اند…';update();plan();}});});bs.forEach(function(b,i){b.classList.toggle('sel',A[q]===i+1);});scroll.appendChild(h('div',{class:'bse-sq'},[h('span',{class:'bse-qn',text:fa(q)}),h('div',{class:'bse-og'},bs)]));})(q);
    });
    sheet.appendChild(h('div',{class:'bse-shh',onclick:mob.close},[h('b',{text:'پاسخ‌برگ · برای بستن بزنید'})]));
    sheet.appendChild(h('div',{class:'bse-shd'},[h('h2',{text:d.book.title}),count]));sheet.appendChild(scroll);sheet.appendChild(status);sheet.appendChild(h('div',{class:'bse-shf'},[submit]));
    overlay([h('header',{class:'bse-ah'},[h('div',{class:'bse-at'},[h('b',{text:(preview==='practice'?'آزمون تمرینی · ':preview?'پیش‌نمایش · ':'')+d.title}),h('span',{text:d.book.title+' · دفترچه '+fa(d.index+1)+' از '+fa(d.book_count)})]),tbox]),h('div',{class:'bse-pg'},[progress]),h('div',{class:'bse-lay'},[pdfViewer(d.book),sheet]),mob.bd,mob.fab]);
    function tick(){clock.textContent=mm(d.deadline-now());tbox.classList.toggle('urg',d.deadline-now()<60);if(now()>=d.deadline)finish();else if(d.deadline-now()<=2&&dirty&&!finishing)plan();}
    S.timer=setInterval(tick,500);update();tick();if(dirty){status.textContent='پاسخ‌های ذخیره‌نشدهٔ این تب بازیابی شد؛ در انتظار ذخیره روی سرور…';plan();}
  }

  /* پیش‌نمایش از API و فضای ذخیره‌سازی جدا استفاده می‌کند. */
  var previewTokens={};
  function previewHash(view,id,mode){return (mode==='practice'?'#/practice/':'#/preview/')+view+'/'+id;}
  function previewToken(id,value,mode){
    var trialMode=mode==='practice'?'practice':'preview', memoryKey=trialMode+'_'+id;
    var key='bse_'+trialMode+'_'+id;
    if(value){previewTokens[memoryKey]=value;try{sessionStorage.setItem(key,value);}catch(e){}}
    if(previewTokens[memoryKey])return previewTokens[memoryKey];
    try{return sessionStorage.getItem(key)||'';}catch(e){return '';}
  }
  function previewApi(op,data,cb,quiet,err,mode){
    var f=new FormData();f.append('action',mode==='practice'?'bse_practice':'bse_preview');f.append('n',C.nonce);f.append('op',op);
    for(var k in data||{})f.append(k,data[k]);f.append('token',previewToken(data.id,null,mode));
    post(f,function(d){if(d.token)previewToken(data.id,d.token,mode);(cb||function(){})(d);},quiet,err||function(){if(op==='result'||op==='start')location.hash=previewHash('info',data.id,mode);});
  }
  function previewNotice(){return h('div',{class:'bsep-notice',role:'note',style:'padding:14px 18px;margin:0 0 18px;border:1px solid #c9e6ff;border-radius:14px;background:#e2f1ff;color:#0967a8;font-size:13px;font-weight:650;line-height:1.9;'},[ico('eye'),' این کارنامه پیش‌نمایش است؛ در نتایج آزمون، میانگین و رتبه‌بندی شرکت‌کنندگان ثبت نمی‌شود.']);}
  function previewInfo(id){
    previewApi('get',{id:id},function(d){
      var starting=false;
      mount(h('div',{class:'bse-pf'},[h('div',{class:'bse-ptop'},[link('بازگشت به مدیریت آزمون','#/m/s/'+id,'gh sm','back')]),
        h('section',{class:'bse-pc'},[h('div',{class:'bse-cv'},[h('span',{class:'bse-st soon',text:'پیش‌نمایش مدیر'}),h('h1',{text:d.title})]),
          h('div',{class:'bse-kv'},[h('p',{text:'این آزمون آزمایشی است و در شرکت‌کنندگان، آمار و رتبه‌بندی ثبت نمی‌شود. پیامک کارنامه هم ارسال نمی‌شود.'}),h('p',{text:'نتیجه و پاسخ‌نامه بلافاصله پس از پایان پیش‌نمایش نمایش داده می‌شود؛ حتی اگر زمان برگزاری رسمی شروع نشده یا تمام شده باشد.'}),h('p',{text:fa(d.qn)+' سؤال · '+fa(d.dur)+' دقیقه'+(d.multi?' · '+fa(d.book_count)+' دفترچه':'')})]),
          h('div',{class:'bse-ac'},[btn('شروع پیش‌نمایش تازه','pri wide lg',function(){if(starting)return;starting=true;previewApi('reset',{id:id},function(){location.hash=previewHash('take',id);},false,function(){starting=false;});},'play'),previewToken(id)?link('ادامه یا مشاهده پیش‌نمایش قبلی',previewHash('take',id),'gh wide'):null])])]));
    });
  }

  function practiceApi(op,data,cb,quiet,err){previewApi(op,data,cb,quiet,err,'practice');}
  function practiceNotice(){return h('div',{class:'bsep-notice',role:'note',style:'padding:14px 18px;margin:0 0 18px;border:1px solid #c9e6ff;border-radius:14px;background:#e2f1ff;color:#0967a8;font-size:13px;line-height:1.9;'},['این کارنامهٔ آزمون تمرینی است؛ در نتایج رسمی، میانگین و رتبه‌بندی شرکت‌کنندگان ثبت نمی‌شود و پیامک ندارد.']);}
  function practiceInfo(id){
    practiceApi('get',{id:id},function(d){var starting=false;
      mount(h('div',{class:'bse-pf'},[h('div',{class:'bse-ptop'},[link('بازگشت به آزمون','#/e/'+id,'gh sm','back')]),h('section',{class:'bse-pc'},[h('div',{class:'bse-cv'},[h('span',{class:'bse-st soon',text:'آزمون تمرینی'}),h('h1',{text:d.title})]),h('div',{class:'bse-kv'},[h('p',{text:'مهلت آزمون رسمی پایان یافته است. می‌توانید هر تعداد بار که بخواهید تمرین کنید؛ هر بار با پاسخ‌های خالی و زمان کامل شروع می‌شود.'}),h('p',{text:'پس از پایان تمرین، نتیجه و پاسخ‌نامه فوراً نمایش داده می‌شود. تمرین در رتبه‌بندی، میانگین و تعداد شرکت‌کنندگان رسمی اثری ندارد و پیامک ارسال نمی‌شود.'}),h('p',{text:fa(d.qn)+' سؤال · '+fa(d.dur)+' دقیقه'+(d.multi?' · '+fa(d.book_count)+' دفترچه':'')})]),h('div',{class:'bse-ac'},[btn('شروع آزمون تمرینی تازه','pri wide lg',function(){if(starting)return;starting=true;practiceApi('reset',{id:id},function(){location.hash=previewHash('take',id,'practice');},false,function(){starting=false;});},'play'),previewToken(id,null,'practice')?link('ادامه یا نتیجهٔ تمرین قبلی',previewHash('take',id,'practice'),'gh wide'):null])])]));
    });
  }

  /* ---------- مسیریابی ---------- */
  function route() {
    var p = location.hash.replace(/^#\/?/, '').split('/'), a = p[0], i = +p[p.length - 1] || 0;
    if (!C.in) {
      mount(h('div', { class: 'bse-pf' }, [h('section', { class: 'bse-pc' }, [
        h('div', { class: 'bse-cv' }, [h('h1', { text: 'ورود به حساب' })]),
        h('div', { class: 'bse-kv' }, [h('div', {}, [h('span', { text: 'برای شرکت در آزمون‌ها ابتدا وارد حساب کاربری شوید.' })])]),
        h('div', { class: 'bse-ac' }, [link('ورود / ثبت‌نام', C.login, 'pri lg wide')])])]));
      return;
    }
    if(a==='practice'){
      if(p[1]==='take')vTake(i,'practice');else if(p[1]==='result')vResult(i,'practice');else if(p[1]==='answers')vAnswers(i,0,'practice');else practiceInfo(i);return;
    }
    if(a==='preview' && C.mgr){
      if(p[1]==='take')vTake(i,true);else if(p[1]==='result')vResult(i,true);else if(p[1]==='answers')vAnswers(i,0,true);else previewInfo(i);return;
    }
    if(a==='p' && C.mgr){previewInfo(i);return;}
    if (a === 'e' && C.mgr) mDet(i, 'o'); else if (a === 'e' || a === 'p') vInfo(i); else if (a === 't') vTake(i); else if (a === 'r') vResult(i); else if (a === 'a') vAnswers(i); else if (a === 'b') vBoard(i);
    else if (a === 'm' && C.mgr) {
      var s = p[1];
      if (s === 'access') mAccess(i); else if (s === 'multi') multiForm(0); else if (s === 'single') mForm(0); else if (s === 'new') chooseType(); else if (s === 'edit') mForm(i); else if (s === 's') mDet(i, 'o'); else if (s === 'k') mDet(i, 'k'); else if (s === 't') mDet(i, 't'); else if (s === 'u') vAnswers(+p[2] || 0, +p[3] || 0); else mMan();
    } else vList();
  }

  var f = new FormData(); f.append('action', 'bse_boot');
  post(f, function (b) {
    C.admin = !!b.admin; C.uid = +b.uid || 0; C.upload_max = +b.upload_max || 0; C.in = b.in; C.mgr = b.mgr; C.nonce = b.nonce; S.off = b.now - Math.floor(Date.now() / 1000);
    window.addEventListener('hashchange', route); route();
  });
})();
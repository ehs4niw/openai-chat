<?php
/**
 * Plugin Name: DrFarzi Three Day Login
 * Description: Persistent, non-sliding 72-hour login for non-administrator accounts.
 * Version: 1.1.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 */
defined('ABSPATH') || exit;

final class DRF_Three_Day_Login {
    private static $sending = false;

    public static function eligible($user_id) {
        return $user_id > 0 && !user_can($user_id, 'manage_options');
    }

    public static function expiration($seconds, $user_id, $remember) {
        return self::eligible($user_id) ? 3 * DAY_IN_SECONDS : $seconds;
    }

    public static function persistent($send, $expire, $expiration, $user_id, $scheme, $token) {
        // Respect a previous security veto. Only transform a newly issued session cookie.
        // Reuse its existing token: never resurrect sessions or refresh them on page views.
        if (!$send || self::$sending || $expire || !$token || !self::eligible($user_id)) {
            return $send;
        }
        self::$sending = true;
        try {
            wp_set_auth_cookie($user_id, true, 'secure_auth' === $scheme, $token);
        } finally {
            self::$sending = false;
        }
        return false; // The persistent cookies replace the original session-only cookies.
    }
}

add_filter('auth_cookie_expiration', array('DRF_Three_Day_Login', 'expiration'), PHP_INT_MAX, 3);
add_filter('send_auth_cookies', array('DRF_Three_Day_Login', 'persistent'), PHP_INT_MAX, 6);

final class DRF_Strict_Mobile {
    const MESSAGE = 'شماره موبایل معتبر نیست؛ شماره را با صفر وارد کنید (مثلاً 09123456789).';

    public static function normalize($value) {
        if (!is_string($value)) { return ''; }
        $value = trim(strtr($value, array_combine(
            preg_split('//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY),
            str_split('01234567890123456789')
        )));
        return preg_match('/\A09[0-9]{9}\z/', $value) ? $value : '';
    }

    public static function guard() {
        $action = isset($_REQUEST['action']) && is_string($_REQUEST['action']) ? $_REQUEST['action'] : '';
        $fields = 'bs_pass_login' === $action ? array('phone') : array('otp_reg_phone', 'otp_phone');
        // Legacy handlers prefer the registration field when both are present.
        $field = $fields[0];
        foreach ($fields as $candidate) {
            if (isset($_POST[$candidate])) { $field = $candidate; break; }
        }
        $phone = self::normalize(isset($_POST[$field]) ? wp_unslash($_POST[$field]) : null);
        if (!$phone) {
            wp_send_json_error(array('message' => self::MESSAGE));
            return;
        }
        $_POST[$field] = $phone;
    }

    public static function assets() {
        if ('studiare' !== get_template()) { return; }
        wp_enqueue_script('drf-strict-mobile', plugins_url('strict-mobile.js', __FILE__), array(), '1.1.0', false);
    }
}

foreach (array('bs_pass_login', 'check_and_send_combined_otp', 'verify_combined_otp',
    'otp_send_verification_code', 'otp_validate_otp', 'otp_login_validate_otp', 'combined_otp_validate_otp') as $drf_phone_action) {
    add_action('wp_ajax_' . $drf_phone_action, array('DRF_Strict_Mobile', 'guard'), -1000);
    add_action('wp_ajax_nopriv_' . $drf_phone_action, array('DRF_Strict_Mobile', 'guard'), -1000);
}
unset($drf_phone_action);
add_action('wp_enqueue_scripts', array('DRF_Strict_Mobile', 'assets'), 0);

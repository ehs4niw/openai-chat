(function () {
    'use strict';
    var message = 'شماره موبایل معتبر نیست؛ شماره را با صفر وارد کنید (مثلاً 09123456789).';
    function digits(s) {
        return String(s).replace(/[۰-۹]/g, function (d) { return String(d.charCodeAt(0) - 1776); })
            .replace(/[٠-٩]/g, function (d) { return String(d.charCodeAt(0) - 1632); });
    }
    function phoneFor(form) {
        return form && form.querySelector('#bs_pl_phone, #otp_reg_phone, #otp_phone');
    }
    function validate(input, event) {
        if (!input) { return; }
        var value = digits(input.value).trim();
        input.value = value;
        if (/^09[0-9]{9}$/.test(value)) {
            input.setCustomValidity('');
            return;
        }
        event.preventDefault();
        event.stopImmediatePropagation();
        input.setCustomValidity(message);
        input.reportValidity();
    }
    document.addEventListener('click', function (event) {
        var button = event.target.closest && event.target.closest('#send-combined-otp, #send-otp, #send-login-otp');
        if (button) { validate(phoneFor(button.closest('form')), event); }
    }, true);
    document.addEventListener('submit', function (event) {
        if (event.target.matches('#combined-otp-form, #otp-registration-form, #otp-login-form, #bs-pass-form')) {
            validate(phoneFor(event.target), event);
        }
    }, true);
    document.addEventListener('input', function (event) {
        if (event.target.matches('#otp_phone, #otp_reg_phone, #bs_pl_phone')) {
            event.target.value = digits(event.target.value);
            event.target.setCustomValidity('');
        }
    }, true);
})();

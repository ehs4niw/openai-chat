<?php defined('ABSPATH') || exit; ?>
<div data-als-login
     data-request="<?php echo esc_url(rest_url('alpha-sms/v1/request')); ?>"
     data-verify="<?php echo esc_url(rest_url('alpha-sms/v1/verify')); ?>"
     data-register="<?php echo esc_url(rest_url('alpha-sms/v1/register')); ?>"
     dir="rtl" style="max-width:420px;margin:25px auto;padding:28px;border:1px solid #dce6e4;border-radius:18px;background:white">
    <h2>ورود یا ثبت‌نام با موبایل</h2>
    <form method="post" data-step="request">
        <label>شماره موبایل <input name="phone" inputmode="tel" autocomplete="tel-national" placeholder="09123456789" maxlength="11" required></label>
        <button>ارسال کد</button>
    </form>
    <form method="post" data-step="verify" hidden>
        <label>کد پیامکی <input name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required></label>
        <button>تأیید کد</button>
    </form>
    <form method="post" data-step="register" hidden>
        <label>نام <input name="first_name" autocomplete="given-name" maxlength="50" required></label>
        <label>نام خانوادگی <input name="last_name" autocomplete="family-name" maxlength="50" required></label>
        <label>گروه آزمایشی
            <select name="exam_group" required>
                <option value="">انتخاب کنید</option>
                <?php foreach (als_exam_groups() as $group): ?>
                    <option><?php echo esc_html($group); ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>رمز عبور <input name="password" type="password" autocomplete="new-password" minlength="8" maxlength="72" required></label>
        <button>ثبت‌نام و رزرو جلسه</button>
    </form>
    <button type="button" data-restart hidden>تغییر شماره یا دریافت کد جدید</button>
    <p data-message role="status" aria-live="polite"></p>
</div>

<?php
/**
 * Plugin Name: Alpha SMS Login | ورود پیامکی آلفا
 * Description: ورود و ثبت نام با پیامک الگوی ملی پیامک، مستقل از هسته آلفا.
 * Version: 0.2.5
 * Requires PHP: 8.0
 */
defined('ABSPATH') || exit;
function als_phone($v){$v=strtr((string)$v,['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);return preg_match('/^09\d{9}$/',$v)?$v:false;}
function alpha_sms_digits($value) {
    if (!is_string($value)) return '';
    return strtr($value, array_combine(
        preg_split('//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY),
        str_split('01234567890123456789')
    ));
}
function als_use_alpha_header_login() {
    return !is_user_logged_in() && defined('ALPHA_VERSION') && version_compare(ALPHA_VERSION, '0.3.2', '>=');
}

add_filter('amzshyar_header_myaccount_url', function ($url) {
    return als_use_alpha_header_login() ? esc_url(home_url('/alpha-panel/')) : $url;
}, PHP_INT_MAX);

add_filter('amzshyar_header_btn_login_popbox_class', function ($enabled) {
    return als_use_alpha_header_login() ? false : $enabled;
}, PHP_INT_MAX);

add_filter('amzshyar_header_btn_login_class', function ($classes) {
    if (!als_use_alpha_header_login()) return $classes;
    return implode(' ', array_diff(preg_split('/\s+/', trim($classes)), ['open-popbox-login', 'loginx-popup-open']));
}, PHP_INT_MAX);

function als_key($kind,$phone){return 'als_'.hash_hmac('sha256',$kind.'|'.$phone,wp_salt('auth'));}
function als_error($message,$status=400){return new WP_Error('alpha_sms',$message,['status'=>$status]);}
add_action('admin_init',function(){register_setting('als_settings','als_pattern',['sanitize_callback'=>'absint']);register_setting('als_settings','als_api_token',['sanitize_callback'=>function($v){return trim(sanitize_text_field($v));}]);});
add_action('admin_menu',function(){add_options_page('ورود پیامکی آلفا','ورود پیامکی آلفا','manage_options','alpha-sms-login',function(){if(!current_user_can('manage_options'))return;echo '<div class="wrap"><h1>تنظیمات ورود پیامکی آلفا</h1><p>توکن را فقط در این صفحه وارد کنید. توکن در بسته نصب قرار نگرفته است.</p><form method="post" action="options.php">';settings_fields('als_settings');echo '<table class="form-table"><tr><th>شناسه الگو (Body ID)</th><td><input name="als_pattern" type="number" value="'.esc_attr(get_option('als_pattern',430007)).'"></td></tr><tr><th>توکن API</th><td><input name="als_api_token" type="password" autocomplete="new-password" value="" placeholder="برای تغییر، توکن جدید را وارد کنید"><p>اگر خالی بگذارید، توکن فعلی حفظ می‌شود.</p></td></tr></table>';submit_button();echo '</form><p>شورت‌کد فرم ورود: <code>[alpha_sms_login]</code></p></div>';});});
// Preserve existing secret when a settings form is submitted with blank token.
add_filter('pre_update_option_als_api_token',function($value,$old){return $value===''?$old:$value;},10,2);
add_action('rest_api_init',function(){
 register_rest_route('alpha-sms/v1','/request',['methods'=>'POST','permission_callback'=>'__return_true','callback'=>function($r){
  if(is_user_logged_in())return als_error('شما قبلاً وارد شده‌اید.');
  $p=als_phone($r->get_param('phone'));if(!$p)return als_error('شماره موبایل معتبر نیست.');
  $token=get_option('als_api_token','');$pattern=(int)get_option('als_pattern',430007);if(!$token||!$pattern)return als_error('سرویس پیامک هنوز تنظیم نشده است.',503);
  $ip=isset($_SERVER['REMOTE_ADDR'])?sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])):'';
  $ipkey='als_ip_'.hash_hmac('sha256',$ip,wp_salt('nonce'));$n=(int)get_transient($ipkey);if($n>=12)return als_error('تعداد درخواست‌ها زیاد است. بعداً تلاش کنید.',429);
  set_transient($ipkey,$n+1,15*MINUTE_IN_SECONDS);
  if(get_transient(als_key('cooldown',$p)))return als_error('لطفاً پیش از درخواست مجدد صبر کنید.',429);
  $code=(string)random_int(100000,999999);
  // Melipayamak pattern OTP endpoint. Pattern must accept one argument for verification code.
  $url='https://console.melipayamak.com/api/send/otp/'.rawurlencode($token);
  $res=wp_remote_post($url,['timeout'=>15,'headers'=>['Content-Type'=>'application/json'],'body'=>wp_json_encode(['bodyId'=>$pattern,'to'=>$p,'args'=>[$code]])]);
  if(is_wp_error($res))return als_error('ارتباط با سرویس پیامک برقرار نشد.',502);
  $body=json_decode(wp_remote_retrieve_body($res),true);$status=wp_remote_retrieve_response_code($res);
  if($status<200||$status>=300||!is_array($body)||(!empty($body['status'])&&in_array(strtolower((string)$body['status']),['error','failed'],true))||isset($body['code'])&&(int)$body['code']<0)return als_error('ارسال پیامک ناموفق بود؛ تنظیمات سرویس را بررسی کنید.',502);
  set_transient(als_key('otp',$p),['hash'=>wp_hash_password($code),'attempts'=>0],3*MINUTE_IN_SECONDS);
  set_transient(als_key('cooldown',$p),1,60);
  return ['ok'=>true,'expires_in'=>180,'resend_in'=>60];
 }]);
 register_rest_route('alpha-sms/v1','/verify',['methods'=>'POST','permission_callback'=>'__return_true','callback'=>function($r){
  $p=als_phone($r->get_param('phone'));$code=alpha_sms_digits($r->get_param('code'));if(!$p||!preg_match('/^\d{6}$/',$code))return als_error('شماره یا کد معتبر نیست.');
  $k=als_key('otp',$p);$state=get_transient($k);if(!is_array($state))return als_error('کد منقضی شده است. دوباره درخواست دهید.',400);
  if(($state['attempts']??0)>=5){delete_transient($k);return als_error('تعداد تلاش‌های ناموفق بیش از حد است.',429);}
  if(!wp_check_password($code,$state['hash'])){$state['attempts']++;set_transient($k,$state,3*MINUTE_IN_SECONDS);return als_error('کد واردشده صحیح نیست.',400);}
  delete_transient($k);
  return als_after_verification($p);
 }]);
 register_rest_route('alpha-sms/v1', '/register', [
  'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'als_register_verified',
 ]);
});

function als_phone_logins($phone) {
    $national = substr($phone, 1);
    return [$phone, $national, '98' . $national, '+98' . $national, '0098' . $national];
}

function als_amoozeshyar_phone_matches($user, $phone) {
    return in_array((string) get_user_meta($user->ID, 'amzshyar_phone', true), als_phone_logins($phone), true);
}

function als_student_account($user) {
    return $user->roles && !array_diff($user->roles, ['subscriber', 'customer', 'alpha_student'])
        && !user_can($user, 'edit_users') && !user_can($user, 'manage_options')
        && !user_can($user, 'alpha_manage') && !user_can($user, 'alpha_booking');
}

function als_account_for_phone($phone) {
    $matches = [];
    foreach (['alpha_phone', 'billing_phone'] as $key) {
        foreach (get_users(['meta_key' => $key, 'meta_value' => $phone, 'number' => 2]) as $user) {
            $matches[$user->ID] = $user;
        }
    }
    foreach (als_phone_logins($phone) as $login) {
        $user = get_user_by('login', $login);
        if ($user) $matches[$user->ID] = $user;
    }
    $theme_matches = get_users([
        'meta_key' => 'amzshyar_phone', 'meta_value' => als_phone_logins($phone),
        'meta_compare' => 'IN', 'number' => 2,
    ]);
    foreach ($theme_matches as $user) {
        if (!isset($matches[$user->ID]) && !als_student_account($user)) {
            return als_error('برای ورود به این حساب از روش قبلی استفاده کنید یا با پشتیبانی تماس بگیرید.', 403);
        }
        $matches[$user->ID] = $user;
    }
    if (count($matches) > 1) return als_error('چند حساب با این شماره وجود دارد؛ با پشتیبانی تماس بگیرید.', 409);
    return $matches ? reset($matches) : false;
}

function als_needs_profile_setup($user, $phone) {
    global $wpdb;
    if (!function_exists('alpha_first_visit_lead') || !get_role('alpha_student')
        || (!in_array($user->user_login, als_phone_logins($phone), true) && !als_amoozeshyar_phone_matches($user, $phone))
        || !als_student_account($user)
        || get_user_meta($user->ID, 'alpha_first_visit', true)
        || get_user_meta($user->ID, 'alpha_exam_group', true)
        || alpha_first_visit_lead($user->ID) || $wpdb->last_error) {
        return false;
    }

    $student = $wpdb->get_var($wpdb->prepare(
        'SELECT id FROM ' . alpha_table('students') . ' WHERE user_id=%d LIMIT 1', $user->ID
    ));
    return !$student && !$wpdb->last_error;
}

function als_sign_in($user, $phone) {
    update_user_meta($user->ID, 'alpha_phone', $phone);
    if (defined('ALPHA_VERSION') && get_role('alpha_student') && !user_can($user, 'alpha_access') && !user_can($user, 'manage_options')) {
        $user->add_role('alpha_student');
    }
    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID, true, is_ssl());
    do_action('wp_login', $user->user_login, $user);
    return ['ok' => true, 'redirect' => esc_url_raw(home_url('/alpha-panel/'))];
}

function als_exam_groups() {
    return ['تجربی', 'ریاضی', 'انسانی', 'فنی و زبان', 'مشاوره شغلی', 'سایر'];
}

function als_after_verification($phone) {
    $user = als_account_for_phone($phone);
    if (is_wp_error($user)) return $user;
    if ($user && !als_needs_profile_setup($user, $phone)) return als_sign_in($user, $phone);

    if (!defined('ALPHA_VERSION') || version_compare(ALPHA_VERSION, '0.3.2', '<') || !get_role('alpha_student')) {
        return als_error('ثبت‌نام فعلاً در دسترس نیست.', 503);
    }
    $token = bin2hex(random_bytes(32));
    if (!set_transient(als_key('registration', $token), ['phone' => $phone, 'user_id' => $user ? (int) $user->ID : 0], 10 * MINUTE_IN_SECONDS)) {
        return als_error('ثبت‌نام فعلاً در دسترس نیست.', 503);
    }
    return ['ok' => true, 'registration_token' => $token];
}

function als_register_verified($request) {
    global $wpdb;
    $token = $request->get_param('registration_token');
    if (!is_string($token) || !preg_match('/\A[a-f0-9]{64}\z/', $token)) {
        return als_error('ابتدا شماره موبایل را تأیید کنید.', 403);
    }
    $key = als_key('registration', $token);
    $grant = get_transient($key);
    if (!is_array($grant) || empty($grant['phone'])) return als_error('مهلت ثبت‌نام تمام شده است. دوباره کد پیامکی بگیرید.', 403);
    if (!defined('ALPHA_VERSION') || version_compare(ALPHA_VERSION, '0.3.2', '<') || !get_role('alpha_student')) {
        return als_error('ثبت‌نام فعلاً در دسترس نیست.', 503);
    }

    $first = $request->get_param('first_name');
    $last = $request->get_param('last_name');
    $group = $request->get_param('exam_group');
    $password = $request->get_param('password');
    $first = is_string($first) ? sanitize_text_field($first) : '';
    $last = is_string($last) ? sanitize_text_field($last) : '';
    if ($first === '' || $last === '' || mb_strlen($first) > 50 || mb_strlen($last) > 50 || !in_array($group, als_exam_groups(), true)) {
        return als_error('نام، نام خانوادگی و گروه آزمایشی معتبر وارد کنید.');
    }
    if (!is_string($password) || strlen($password) < 8 || strlen($password) > 72 || trim($password) !== $password || str_contains($password, chr(0))) {
        return als_error('رمز عبور باید حداقل ۸ کاراکتر و حداکثر ۷۲ بایت باشد و ابتدا یا انتهای آن فاصله نباشد.');
    }

    $phone = $grant['phone'];
    $lock = substr(als_key('registration-lock', $phone), 0, 64);
    if ((int) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 3)', $lock)) !== 1) {
        return als_error('ثبت‌نام در حال پردازش است. دوباره تلاش کنید.', 409);
    }
    try {
        if (get_transient($key) !== $grant) return als_error('دوباره شماره موبایل را تأیید کنید.', 403);
        $existing = als_account_for_phone($phone);
        if (is_wp_error($existing)) return $existing;
        $target = $existing ? (int) $existing->ID : 0;
        if ($target !== $grant['user_id'] || ($existing && !als_needs_profile_setup($existing, $phone))) {
            delete_transient($key);
            return als_error('وضعیت حساب تغییر کرده است. دوباره از طریق کد پیامکی وارد شوید.', 409);
        }
        $data = [
            'user_pass' => $password,
            'first_name' => $first,
            'last_name' => $last,
            'display_name' => $first . ' ' . $last,
            'meta_input' => [
                'alpha_phone' => $phone,
                'alpha_exam_group' => $group,
                'alpha_first_visit' => 'pending',
            ],
        ];
        if ($existing) {
            $data['ID'] = $target;
            $id = wp_update_user($data);
        } else {
            $data['user_login'] = $phone;
            $data['role'] = 'alpha_student';
            $id = wp_insert_user($data);
        }
        if (is_wp_error($id)) return als_error('ایجاد حساب انجام نشد.', 500);
        delete_transient($key);
        return als_sign_in(get_userdata($id), $phone);
    } finally {
        $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
    }
}
add_shortcode('alpha_sms_login',function(){if(is_user_logged_in())return '<p>شما وارد شده‌اید. <a href="'.esc_url(home_url('/alpha-panel/')).'">ورود به پنل</a></p>';
 wp_enqueue_script('alpha-sms-login', plugins_url('login.js', __FILE__), [], '0.2.5', true);
 ob_start();
 require __DIR__ . '/login-form.php';
 return ob_get_clean();
});

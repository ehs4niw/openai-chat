document.querySelectorAll('[data-als-login]').forEach(root => {
    const message = root.querySelector('[data-message]');
    const restart = root.querySelector('[data-restart]');
    const forms = [...root.querySelectorAll('form[data-step]')];
    let phone = '';
    let registrationToken = '';

    function show(step) {
        forms.forEach(form => { form.hidden = form.dataset.step !== step; });
        restart.hidden = step === 'request';
        forms.find(form => form.dataset.step === step).querySelector('input').focus();
    }

    restart.addEventListener('click', () => {
        phone = '';
        registrationToken = '';
        forms.filter(form => form.dataset.step !== 'request').forEach(form => form.reset());
        message.textContent = '';
        show('request');
    });

    forms.forEach(form => form.addEventListener('submit', async event => {
        event.preventDefault();
        const step = form.dataset.step;
        const data = Object.fromEntries(new FormData(form));
        if (step === 'verify') data.phone = phone;
        if (step === 'register') data.registration_token = registrationToken;
        const submit = form.querySelector('button');
        submit.disabled = true;
        restart.disabled = true;
        message.textContent = 'در حال بررسی…';
        try {
            const response = await fetch(root.dataset[step], {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.message || 'ارتباط با سایت برقرار نشد.');
            if (result.redirect) {
                window.location.assign(result.redirect);
            } else if (step === 'request') {
                phone = data.phone;
                message.textContent = 'کد تأیید ارسال شد.';
                show('verify');
            } else {
                registrationToken = result.registration_token;
                message.textContent = 'شماره تأیید شد. مشخصات ثبت‌نام را وارد کنید.';
                show('register');
            }
        } catch (error) {
            message.textContent = error.message;
        } finally {
            submit.disabled = false;
            restart.disabled = false;
        }
    }));
});

<?php
defined('ABSPATH') || exit;

add_action('init', function () {
    global $wpdb;
    if (get_option('alpha_booking_pending_stage_fixed')) return;

    $leads = alpha_table('leads');
    $bookings = alpha_table('bookings');
    $audit = alpha_table('audit');
    $manual_reserved = '%' . $wpdb->esc_like('"to":"reserved"') . '%';
    // Restore only cards left in the former automatic stage by a pending request.
    $updated = $wpdb->query($wpdb->prepare(
        "UPDATE {$leads} l
         SET l.stage='new', l.updated_at=UTC_TIMESTAMP()
         WHERE l.stage='reserved'
           AND EXISTS (
               SELECT 1 FROM {$bookings} b
               WHERE b.lead_id=l.id AND b.status='pending'
                 AND NOT EXISTS (
                     SELECT 1 FROM {$bookings} later WHERE later.lead_id=l.id AND later.id>b.id
                 )
                 AND EXISTS (
                     SELECT 1 FROM {$audit} requested
                     WHERE requested.kind='booking' AND requested.entity_id=b.id
                       AND requested.event='booking_requested'
                 )
           )
           AND NOT EXISTS (
               SELECT 1 FROM {$audit} manual
               WHERE manual.kind='lead' AND manual.entity_id=l.id
                 AND manual.event='stage_changed' AND manual.detail LIKE %s
           )",
        $manual_reserved
    ));
    if ($updated !== false) update_option('alpha_booking_pending_stage_fixed', true, false);
}, 10);

const cache = {
  get(key, fallback = null) {
    try { return JSON.parse(localStorage.getItem('spinach-' + key)) ?? fallback; }
    catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem('spinach-' + key, JSON.stringify(value)); }
    catch {}
  }
};
const fa = value => Number(value).toLocaleString('fa-IR');
const advisors = ['مشاور برنامه‌ریزی', 'مشاور تحلیل آزمون', 'مشاور کنکور تجربی'];
const advisor = advisors[Number(new URLSearchParams(location.search).get('advisor'))] || advisors[0];
const advisorLabel = document.querySelector('[data-advisor]');
if (advisorLabel) advisorLabel.textContent = advisor;

document.querySelectorAll('[data-viewer]').forEach(viewer => {
  const papers = [...viewer.querySelectorAll('.paper')];
  let index = 0;
  viewer.addEventListener('click', event => {
    const action = event.target.dataset.view;
    if (!action) return;
    if (action === 'zoom') viewer.classList.toggle('zoom');
    if (action === 'next') index = (index + 1) % papers.length;
    if (action === 'prev') index = (index + papers.length - 1) % papers.length;
    papers.forEach((paper, i) => { paper.hidden = i !== index; });
    viewer.querySelector('[data-counter]').textContent = 'صفحهٔ ' + fa(index + 1) + ' از ' + fa(papers.length);
  });
});
document.querySelectorAll('[data-filter]').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('[data-filter]').forEach(item => {
    item.classList.toggle('success', item === button);
    item.setAttribute('aria-pressed', String(item === button));
  });
  document.querySelectorAll('[data-category]').forEach(item => {
    item.hidden = button.dataset.filter !== 'همه' && item.dataset.category !== button.dataset.filter;
  });
}));
document.querySelectorAll('[data-note]').forEach(button => button.addEventListener('click', () => {
  const status = button.closest('form')?.querySelector('.status');
  if (status) status.textContent = button.dataset.note;
  else {
    const note = document.createElement('span');
    note.textContent = button.dataset.note;
    button.replaceWith(note);
  }
}));
document.querySelector('[data-mark]')?.addEventListener('click', event => {
  const button = event.currentTarget;
  const marked = button.getAttribute('aria-pressed') === 'true';
  button.setAttribute('aria-pressed', String(!marked));
  button.textContent = marked ? 'نشانک' : 'نشانک ثبت شد';
});
document.querySelector('[data-mode]')?.addEventListener('click', () => document.body.classList.toggle('reading'));

function updateBooking() {
  const request = cache.get('booking');
  document.querySelectorAll('[data-booking-status]').forEach(box => {
    if (!request) return;
    box.textContent = request.approved
      ? 'جلسه تأیید شد • ' + request.approved + ' • ' + request.advisor
      : 'در انتظار تأیید مشاور • ' + request.advisor + ' • ' + request.slots.join('، ');
  });
  const choices = document.querySelector('[data-request-slots]');
  if (!choices) return;
  const note = document.querySelector('[data-advisor-request]');
  note.textContent = request ? request.advisor : 'درخواست نمونه • دانش‌آموز دوازدهم';
  if (!request) return;
  choices.replaceChildren();
  for (const slot of request.slots) {
    const label = document.createElement('label');
    const radio = document.createElement('input');
    label.className = 'slot';
    radio.type = 'radio';
    radio.name = 'appointment';
    radio.required = true;
    radio.value = slot;
    radio.checked = slot === request.approved;
    label.append(radio, ' ' + slot);
    choices.append(label);
  }
  if (request.approved) note.textContent += ' • زمان قطعی: ' + request.approved;
}
function updateStudy() {
  const box = document.querySelector('[data-study]');
  if (!box) return;
  box.replaceChildren();
  const entries = cache.get('study', []);
  if (!entries.length) box.textContent = 'هنوز زمانی ثبت نشده است.';
  for (const entry of entries) {
    const item = document.createElement('div');
    item.className = 'cover-note section';
    const date = new Date(entry.date + 'T12:00:00').toLocaleDateString('fa-IR-u-ca-persian');
    item.textContent = date + ' | ' + entry.subject + ' • ' + entry.topic + ' | ' + fa(entry.minutes) + ' دقیقه';
    box.append(item);
  }
}
const studyForm = document.querySelector('[data-form=study]');
const studyDate = studyForm?.querySelector('[type=date]');
if (studyDate) {
  const today = new Date();
  studyDate.value = [today.getFullYear(), String(today.getMonth() + 1).padStart(2, '0'), String(today.getDate()).padStart(2, '0')].join('-');
}
const timer = document.querySelector('[data-timer]');
let tick;
let elapsed = 0;
let start;
document.querySelector('[data-time]')?.addEventListener('click', event => {
  const button = event.currentTarget;
  if (tick) {
    clearInterval(tick);
    tick = null;
    elapsed += Date.now() - start;
    button.textContent = 'ادامهٔ زمان‌سنج';
    const [hours, minutes] = studyForm.querySelectorAll('[type=number]');
    hours.value = Math.floor(elapsed / 3600000);
    minutes.value = Math.floor(elapsed / 60000) % 60;
    return;
  }
  start = Date.now();
  button.textContent = 'توقف زمان‌سنج';
  tick = setInterval(() => {
    const seconds = Math.floor((Date.now() - start + elapsed) / 1000);
    timer.textContent = [Math.floor(seconds / 3600), Math.floor(seconds / 60) % 60, seconds % 60].map(n => String(n).padStart(2, '0')).join(':');
  }, 250);
});

document.querySelectorAll('form[data-form]').forEach(form => form.addEventListener('submit', event => {
  event.preventDefault();
  const status = form.querySelector('.status');
  const type = form.dataset.form;
  if (type === 'login') { location.href = 'student.html'; return; }
  if (type === 'booking') {
    const slots = [...form.querySelectorAll('input:checked')].map(input => input.value);
    if (slots.length !== 3) {
      status.textContent = 'برای ثبت درخواست، دقیقاً سه زمان آزاد انتخاب کن.';
      return;
    }
    cache.set('booking', {advisor, slots});
    updateBooking();
    status.textContent = 'درخواست ثبت شد. پیامک به مشاور و مدیر کل در نسخهٔ اجرایی ارسال می‌شود.';
    return;
  }
  if (type === 'approve') {
    const selected = form.querySelector('input:checked').value;
    const request = cache.get('booking', {advisor: 'مشاور نمونه', slots: [...form.querySelectorAll('input')].map(input => input.value)});
    if (request.approved && request.approved !== selected) {
      status.textContent = 'برای این درخواست قبلاً یک زمان قطعی ثبت شده است.';
      return;
    }
    cache.set('booking', {...request, approved: selected});
    updateBooking();
    status.textContent = 'زمان قطعی ثبت شد و در پیشخوان دانش‌آموز قابل مشاهده است.';
    return;
  }
  if (type === 'study') {
    const numbers = form.querySelectorAll('[type=number]');
    const minutes = 60 * Number(numbers[0].value) + Number(numbers[1].value);
    if (!minutes || minutes > 1440) { status.textContent = 'زمان مطالعه را بین ۱ دقیقه و ۲۴ ساعت وارد کن.'; return; }
    const entries = cache.get('study', []);
    entries.unshift({date: studyDate.value, subject: form.querySelector('select').value, topic: form.querySelector('[type=text]').value, minutes});
    cache.set('study', entries);
    updateStudy();
  }
  if (type === 'article') {
    const [state, home] = form.querySelectorAll('select');
    cache.set('article', {title: form.querySelector('[type=text]').value, text: form.querySelector('textarea').value, state: state.value, home: home.value});
  }
  status.textContent = form.dataset.message;
}));
const article = cache.get('article');
if (article) {
  const list = document.querySelector('[data-article-list]');
  if (list) list.textContent = 'آخرین ذخیرهٔ محلی: ' + article.title + ' • ' + article.state;
  if (article.state === 'منتشر شده' && article.home === 'مقالهٔ معرفی') {
    const content = document.querySelector('.editorial');
    if (content) {
      document.querySelector('h1').textContent = article.title;
      const paragraph = document.createElement('p');
      paragraph.textContent = article.text;
      content.replaceChildren(paragraph);
    }
  }
}
updateBooking();
updateStudy();
document.querySelector('[data-book-gallery]')?.addEventListener('click', event => {
  const view = event.target.dataset.bookShot;
  if (!view) return;
  const image = event.currentTarget.querySelector('[data-book-display]');
  image.className = 'book-display ' + view;
  image.textContent = view === 'inside' ? 'زیست‌شناسی • فصل سوم' : 'زیست‌شناسی جامع کنکور';
});

/* Alpha booking: Persian calendar + explicit 24-hour clock; native datetime-local retained for React. */
(function(){'use strict';
const dateFmt=new Intl.DateTimeFormat('en-US-u-ca-persian-nu-latn',{year:'numeric',month:'numeric',day:'numeric',timeZone:'UTC'});
const monthFmt=new Intl.DateTimeFormat('fa-IR-u-ca-persian',{year:'numeric',month:'long',timeZone:'UTC'});
const digits=new Intl.NumberFormat('fa-IR',{useGrouping:false});
const pad=n=>String(n).padStart(2,'0');
const parts=d=>{const x=Object.fromEntries(dateFmt.formatToParts(d).filter(p=>p.type!=='literal').map(p=>[p.type,+p.value]));return [x.year,x.month,x.day]};
function greg(y,m,d){let start=Date.UTC(y+620,0,1,12);for(let i=0;i<760;i++){let x=new Date(start+i*86400000),p=parts(x);if(p[0]===y&&p[1]===m&&p[2]===d)return x;}return null}
const days=(y,m)=>greg(y,m,31)?31:greg(y,m,30)?30:29;
const icon=(type)=>type==='calendar'?'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4M17 3v4M3 10h18"/></svg>':'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>';
let active=null;
function init(input){if(input.dataset.alphaJalali)return;input.dataset.alphaJalali='1';
const wrap=document.createElement('div');wrap.className='alpha-jalali-control';input.before(wrap);wrap.append(input);input.classList.add('alpha-jalali-native');input.tabIndex=-1;
const trigger=document.createElement('button');trigger.type='button';trigger.className='alpha-jalali-trigger';wrap.append(trigger);
const popup=document.createElement('div');popup.className='alpha-jalali-popup';popup.hidden=true;const host=()=>input.closest('dialog')||document.body;host().append(popup);['pointerdown','mousedown','mouseup','click','touchstart'].forEach(type=>popup.addEventListener(type,e=>e.stopPropagation()));
let today=parts(new Date()),selected=[...today],shown=today.slice(0,2),hour='14',minute='00';
function sync(){let v=input.value;if(/^\d{4}-\d\d-\d\dT\d\d:\d\d/.test(v)){let [date,time]=v.split('T'),[y,m,d]=date.split('-').map(Number);selected=parts(new Date(Date.UTC(y,m-1,d,12)));shown=selected.slice(0,2);[hour,minute]=time.split(':');}trigger.innerHTML=`<span class="alpha-jalali-trigger-date">${icon('calendar')}<span>${v?`${selected[0]}/${pad(selected[1])}/${pad(selected[2])}`:'انتخاب تاریخ شمسی'}</span></span><span class="alpha-jalali-trigger-time">${icon('clock')}<b dir="ltr">${v?`${hour}:${minute}`:'--:--'}</b></span>`;}
function setValue(){let d=greg(...selected);if(!d)return;let value=`${d.getUTCFullYear()}-${pad(d.getUTCMonth()+1)}-${pad(d.getUTCDate())}T${hour}:${minute}`;let setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;setter.call(input,value);input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));sync()}
function position(){
  // <dialog>.showModal() puts the dialog in the browser top layer: anything outside it is inert and drawn underneath.
  // So the popup must live INSIDE the dialog. Fallback to body when there is no dialog.
  const h=host();if(popup.parentElement!==h)h.append(popup);
  if(h===document.body){popup.style.position='fixed';popup.style.width=Math.min(510,Math.max(280,window.innerWidth-32))+'px';popup.style.left='50%';popup.style.top='50%';popup.style.transform='translate(-50%,-50%)';popup.style.zIndex='2147483647';popup.style.pointerEvents='auto';return}
  const cw=h.clientWidth,ch=h.clientHeight;
  popup.style.position='absolute';popup.style.right='auto';popup.style.bottom='auto';popup.style.transform='none';popup.style.zIndex='50';popup.style.pointerEvents='auto';
  popup.style.width=Math.min(510,Math.max(250,cw-20))+'px';popup.style.maxHeight=Math.max(240,ch-16)+'px';
  popup.style.left=Math.max(8,(cw-popup.offsetWidth)/2)+'px';
  popup.style.top=Math.max(8,h.scrollTop+(ch-popup.offsetHeight)/2)+'px';
}
function close(){popup.hidden=true;if(active===popup)active=null}
function render(){popup.replaceChildren();const header=document.createElement('div');header.className='alpha-jalali-head';const prev=document.createElement('button'),next=document.createElement('button'),title=document.createElement('strong');prev.type=next.type='button';prev.textContent='‹';next.textContent='›';title.textContent=monthFmt.format(greg(...shown,1));prev.onclick=()=>move(-1);next.onclick=()=>move(1);header.append(prev,title,next);
const body=document.createElement('div');body.className='alpha-jalali-body';const calendar=document.createElement('div');calendar.className='alpha-jalali-calendar';calendar.append(header);const grid=document.createElement('div');grid.className='alpha-jalali-grid';['ش','ی','د','س','چ','پ','ج'].forEach(t=>{let e=document.createElement('span');e.textContent=t;grid.append(e)});let first=greg(...shown,1),offset=(first.getUTCDay()+1)%7;for(let i=0;i<offset;i++)grid.append(document.createElement('span'));for(let d=1;d<=days(...shown);d++){let b=document.createElement('button');b.type='button';b.textContent=digits.format(d);if(selected[0]===shown[0]&&selected[1]===shown[1]&&selected[2]===d)b.className='selected';b.onclick=()=>{selected=[...shown,d];render()};grid.append(b)}calendar.append(grid);
const clock=document.createElement('div');clock.className='alpha-jalali-clock';let caption=document.createElement('div');caption.className='alpha-jalali-clock-label';caption.textContent='ساعت (۲۴ ساعته)';clock.append(caption);
const fa=s=>String(s).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);const chev=up=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="${up?'M6 15l6-6 6 6':'M6 9l6 6 6-6'}"/></svg>`;
const controls=document.createElement('div');controls.className='alpha-jalali-clock-controls';const boxes={};const chips=[];
function refresh(){boxes.h.textContent=fa(hour);boxes.m.textContent=fa(minute);chips.forEach(([c,hh,mm])=>c.classList.toggle('on',hh===hour&&mm===minute))}
function col(key,step,wrapAt){const c=document.createElement('div');c.className='alpha-jalali-clock-col';const mk=dir=>{const s=document.createElement('button');s.type='button';s.className='alpha-jalali-step';s.setAttribute('aria-label',dir>0?'افزایش':'کاهش');s.innerHTML=chev(dir>0);s.onclick=()=>{if(key==='h')hour=pad((+hour+dir*step+wrapAt)%wrapAt);else minute=pad((+minute+dir*step+wrapAt)%wrapAt);refresh()};return s};const v=document.createElement('div');v.className='alpha-jalali-clock-box';boxes[key]=v;c.append(mk(1),v,mk(-1));return c}
const sep=document.createElement('span');sep.className='alpha-jalali-clock-sep';sep.textContent=':';controls.append(col('h',1,24),sep,col('m',5,60));clock.append(controls);
const presets=document.createElement('div');presets.className='alpha-jalali-chips';[['09','00'],['12','00'],['14','30'],['18','00']].forEach(([hh,mm])=>{const c=document.createElement('button');c.type='button';c.className='alpha-jalali-chip';c.dir='ltr';c.textContent=fa(hh+':'+mm);c.onclick=()=>{hour=hh;minute=mm;refresh()};chips.push([c,hh,mm]);presets.append(c)});clock.append(presets);refresh();
body.append(calendar,clock);popup.append(body);
const footer=document.createElement('div');footer.className='alpha-jalali-footer';let cancel=document.createElement('button'),confirm=document.createElement('button');cancel.type=confirm.type='button';cancel.textContent='انصراف';confirm.textContent='✓ تأیید';cancel.className='alpha-jalali-cancel';confirm.className='alpha-jalali-done';cancel.onclick=close;confirm.onclick=()=>{setValue();close()};footer.append(cancel,confirm);popup.append(footer);requestAnimationFrame(position)}
function move(dir){let n=shown[0]*12+shown[1]-1+dir;shown=[Math.floor(n/12),((n%12)+12)%12+1];render()}
['pointerdown','mousedown','mouseup','touchstart'].forEach(type=>trigger.addEventListener(type,e=>e.stopPropagation()));trigger.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();if(active&&active!==popup)active.hidden=true;if(!popup.hidden){close();return}sync();active=popup;popup.hidden=false;render()});sync();
const cleanup=new MutationObserver(()=>{if(!input.isConnected){popup.remove();cleanup.disconnect()}});cleanup.observe(document.body,{childList:true,subtree:true});
}
function scan(){document.querySelectorAll('input[type="datetime-local"]').forEach(el=>{if(el.name==='starts_at'||el.name==='ends_at')init(el)})}
let scheduled=false;new MutationObserver(()=>{if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;scan()})}).observe(document.documentElement,{childList:true,subtree:true});document.addEventListener('pointerdown',e=>{if(active&&!active.contains(e.target)&&!e.target.closest('.alpha-jalali-trigger')){active.hidden=true;active=null}});window.addEventListener('resize',()=>{if(active)requestAnimationFrame(()=>{active&&active.isConnected&&positionActive()})});function positionActive(){/* centered picker uses responsive CSS */}document.addEventListener('keydown',e=>{if(e.key==='Escape'&&active){e.preventDefault();e.stopPropagation();active.hidden=true;active=null}},true);scan();
})();

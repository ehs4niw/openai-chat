document.querySelectorAll('.alpha-first-visit form[data-alpha-action]').forEach(form => {
    form.addEventListener('submit', async event => {
        event.preventDefault();
        const action = form.dataset.alphaAction;
        const button = form.querySelector('button');
        const message = form.querySelector('[data-message]');
        const data = Object.fromEntries(new FormData(form));
        if (action === 'reserve') data.request_key = alphaFirstVisit.requestKey;
        button.disabled = true;
        message.textContent = 'در حال ثبت…';
        try {
            const response = await fetch(alphaFirstVisit[action], {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': alphaFirstVisit.nonce },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.message || 'ثبت اطلاعات انجام نشد.');
            window.location.assign(alphaFirstVisit.panel);
        } catch (error) {
            message.textContent = error.message;
            button.disabled = false;
        }
    });
});

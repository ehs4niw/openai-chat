<?php
defined('ABSPATH') || exit;
$format_date = fn($value) => wp_date('l j F، H:i', strtotime($value . ' UTC'), new DateTimeZone('Asia/Tehran'));
?>
<main class="alpha-first-visit" dir="rtl">
    <header><a href="<?php echo esc_url(home_url('/')); ?>">مشاوران آلفا</a></header>
    <section>
        <h1>رزرو جلسه معارفه رایگان</h1>
        <?php if ($booking): ?>
            <p><?php echo esc_html($booking['title'] . ' | ' . $format_date($booking['starts_at'])); ?></p>
            <p role="status"><?php echo $booking['status'] === 'pending' ? 'در انتظار تأیید' : 'تأیید شده'; ?></p>
            <details>
                <summary>تکمیل پرونده</summary>
                <form method="post" data-alpha-action="profile">
                    <?php foreach (alpha_first_visit_profile_fields() as $section => $fields): ?>
                        <fieldset>
                            <legend><?php echo esc_html($section); ?></legend>
                            <?php foreach ($fields as $name => $label): ?>
                                <label><?php echo esc_html($label); ?>
                                    <input name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($data[$name] ?? ''); ?>"
                                        <?php if (in_array($name, ['national_id', 'grade', 'city'], true)) echo 'required'; ?>
                                        <?php if ($name === 'national_id' || str_ends_with($name, '_phone')) echo 'inputmode="numeric"'; ?>>
                                </label>
                            <?php endforeach; ?>
                        </fieldset>
                    <?php endforeach; ?>
                    <button>ذخیره پرونده</button>
                    <p data-message role="status"></p>
                </form>
            </details>
        <?php elseif ($slots): ?>
            <form method="post" data-alpha-action="reserve">
                <label>زمان جلسه
                    <select name="slot_id" required>
                        <option value="">انتخاب کنید</option>
                        <?php foreach ($slots as $slot): ?>
                            <option value="<?php echo esc_attr($slot['id']); ?>"><?php echo esc_html($slot['title'] . ' | ' . $format_date($slot['starts_at'])); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <button>رزرو تایم</button>
                <p data-message role="status"></p>
            </form>
        <?php else: ?>
            <p>در حال حاضر وقت خالی برای جلسه معارفه رایگان وجود ندارد.</p>
        <?php endif; ?>
    </section>
</main>

<?php
defined('ABSPATH') || exit;
function alpha_activate(){
    global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$charset=$wpdb->get_charset_collate();
    $schemas=[
    'leads'=>"id bigint unsigned NOT NULL AUTO_INCREMENT, user_id bigint unsigned NOT NULL DEFAULT 0, name varchar(200) NOT NULL, phone varchar(20) NOT NULL, data longtext NOT NULL, stage varchar(40) NOT NULL DEFAULT 'new', owner_id bigint unsigned NOT NULL DEFAULT 0, booking_token_hash varchar(64) NOT NULL DEFAULT '', booking_token_expires datetime DEFAULT NULL, created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY  (id), KEY user_id (user_id), KEY phone (phone), KEY stage (stage)",
    'followups'=>"id bigint unsigned NOT NULL AUTO_INCREMENT, lead_id bigint unsigned NOT NULL, actor_id bigint unsigned NOT NULL, body text NOT NULL, next_at varchar(30) NOT NULL DEFAULT '', created_at datetime NOT NULL, PRIMARY KEY  (id), KEY lead_id (lead_id)",
    'students'=>"id bigint unsigned NOT NULL AUTO_INCREMENT, lead_id bigint unsigned NOT NULL, user_id bigint unsigned NOT NULL DEFAULT 0, consultant_id bigint unsigned NOT NULL DEFAULT 0, name varchar(200) NOT NULL, phone varchar(20) NOT NULL, data longtext NOT NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), UNIQUE KEY lead_id (lead_id), KEY user_id (user_id), KEY consultant_id (consultant_id)",
    'notes'=>"id bigint unsigned NOT NULL AUTO_INCREMENT, student_id bigint unsigned NOT NULL, actor_id bigint unsigned NOT NULL, body text NOT NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), KEY student_id (student_id)",
    'booking_topics'=>"id bigint unsigned NOT NULL AUTO_INCREMENT, title varchar(200) NOT NULL, free_intro tinyint NOT NULL DEFAULT 0, active tinyint NOT NULL DEFAULT 1, PRIMARY KEY  (id)",
    'slots'=>"active tinyint NOT NULL DEFAULT 1, revision bigint unsigned NOT NULL DEFAULT 1, id bigint unsigned NOT NULL AUTO_INCREMENT, consultant_id bigint unsigned NOT NULL DEFAULT 0, topic_id bigint unsigned NOT NULL DEFAULT 0, title varchar(200) NOT NULL, starts_at datetime NOT NULL, ends_at datetime NOT NULL, capacity int unsigned NOT NULL, reserved int unsigned NOT NULL DEFAULT 0, PRIMARY KEY  (id), KEY starts_at (starts_at), KEY topic_id (topic_id)",
    'bookings'=>"id bigint unsigned NOT NULL AUTO_INCREMENT, slot_id bigint unsigned NOT NULL, lead_id bigint unsigned NOT NULL DEFAULT 0, user_id bigint unsigned NOT NULL, status varchar(20) NOT NULL DEFAULT 'pending', request_key varchar(64) NOT NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), UNIQUE KEY request_key (request_key), KEY slot_id (slot_id), KEY user_id (user_id)",
    'services'=>"id bigint unsigned NOT NULL AUTO_INCREMENT, title varchar(200) NOT NULL, price bigint unsigned NOT NULL, active tinyint NOT NULL DEFAULT 1, PRIMARY KEY  (id)",
    'invoices'=>"id bigint unsigned NOT NULL AUTO_INCREMENT, student_id bigint unsigned NOT NULL, service_id bigint unsigned NOT NULL, title varchar(200) NOT NULL, amount bigint unsigned NOT NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), KEY student_id (student_id)",
    'payments'=>"id bigint unsigned NOT NULL AUTO_INCREMENT, invoice_id bigint unsigned NOT NULL, amount bigint unsigned NOT NULL, file_id bigint unsigned NOT NULL DEFAULT 0, status varchar(20) NOT NULL DEFAULT 'pending', created_by bigint unsigned NOT NULL, reviewed_by bigint unsigned NOT NULL DEFAULT 0, created_at datetime NOT NULL, PRIMARY KEY  (id), KEY invoice_id (invoice_id)",
    'installments'=>"id bigint unsigned NOT NULL AUTO_INCREMENT, invoice_id bigint unsigned NOT NULL, amount bigint unsigned NOT NULL, due_at date NOT NULL, PRIMARY KEY  (id), KEY invoice_id (invoice_id)",
    'files'=>"id bigint unsigned NOT NULL AUTO_INCREMENT, owner_id bigint unsigned NOT NULL, student_id bigint unsigned NOT NULL DEFAULT 0, name varchar(250) NOT NULL, mime varchar(100) NOT NULL, data longtext NOT NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), KEY student_id (student_id)",
    'audit'=>"id bigint unsigned NOT NULL AUTO_INCREMENT, actor_id bigint unsigned NOT NULL, kind varchar(40) NOT NULL, entity_id bigint unsigned NOT NULL, event varchar(80) NOT NULL, detail longtext NOT NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), KEY entity_id (entity_id)",
    'notifications'=>"id bigint unsigned NOT NULL AUTO_INCREMENT, user_id bigint unsigned NOT NULL, body text NOT NULL, is_read tinyint NOT NULL DEFAULT 0, created_at datetime NOT NULL, PRIMARY KEY  (id), KEY user_id (user_id)"
    ];
    foreach($schemas as $name=>$columns){$columns=str_replace(', ',",\n",$columns);dbDelta('CREATE TABLE '.alpha_table($name)." (\n$columns\n) ENGINE=InnoDB $charset;");}
    if(!defined('ALPHA_TESTING')||!ALPHA_TESTING){
        foreach(array_keys($schemas) as $name){$t=alpha_table($name);$engine=$wpdb->get_var($wpdb->prepare('SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s',$t));if(strtolower((string)$engine)!=='innodb')wp_die('فعال‌سازی متوقف شد: جداول آلفا باید با InnoDB و پشتیبانی از تراکنش ساخته شوند.');}
    }
    if (!get_option('alpha_booking_topics_seeded')) {
        $topics = alpha_table('booking_topics');
        alpha_dbcheck($wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO {$topics} (id,title,free_intro) VALUES (1,%s,1),(2,%s,0)",
            'جلسه معارفه رایگان', 'جلسه معرفی'
        )));
        update_option('alpha_booking_topics_seeded', true, false);
    }
    $roles=['alpha_manager'=>['مدیر آلفا',alpha_caps()], 'alpha_reception'=>['پذیرش آلفا',['alpha_access','alpha_admissions','alpha_booking','alpha_profiles']], 'alpha_finance'=>['مالی آلفا',['alpha_access','alpha_profiles','alpha_finance','alpha_reports']], 'alpha_consultant'=>['مشاور آلفا',['alpha_access','alpha_consult']], 'alpha_student'=>['دانش‌آموز آلفا',['alpha_access','alpha_student']]];
    foreach($roles as $slug=>[$label,$caps]){add_role($slug,$label,['read'=>true]);$r=get_role($slug);foreach($caps as $cap)$r->add_cap($cap);}
    $admin=get_role('administrator');if($admin)foreach(alpha_caps() as $cap)$admin->add_cap($cap);
    foreach(['alpha-panel'=>['پنل مشاوران آلفا','[alpha_panel]'],'alpha-intake'=>['فرم معرفی آلفا','[alpha_intake]']] as $slug=>[$title,$content])if(!get_page_by_path($slug))wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_name'=>$slug,'post_title'=>$title,'post_content'=>$content]);
    update_option('alpha_schema_version',ALPHA_VERSION,false);
}

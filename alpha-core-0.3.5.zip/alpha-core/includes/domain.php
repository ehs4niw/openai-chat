<?php
defined('ABSPATH') || exit;
function alpha_caps(){return ['alpha_access','alpha_admissions','alpha_booking','alpha_profiles','alpha_finance','alpha_reports','alpha_manage','alpha_student','alpha_consult'];}
function alpha_table($name){global $wpdb;return $wpdb->prefix.'alpha_'.$name;}
function alpha_now(){return current_time('mysql',true);}
function alpha_error($m,$status=400){return new WP_Error('alpha_error',$m,['status'=>$status]);}
function alpha_fail($m,$status=400){throw new RuntimeException($m,$status);}
function alpha_route($path,$methods,$callback,$cap){
    register_rest_route('alpha/v1',$path,['methods'=>$methods,'callback'=>function($r)use($callback){try{return $callback($r);}catch(Throwable $e){if($e instanceof RuntimeException&&$e->getCode()>=400&&$e->getCode()<=499)return alpha_error($e->getMessage(),$e->getCode());error_log('Alpha: '.$e->getMessage());return alpha_error('عملیات انجام نشد؛ دوباره تلاش کنید.',500);}},'permission_callback'=>function()use($cap){return $cap===null ? true : (is_user_logged_in()&&current_user_can($cap)?true:alpha_error('دسترسی مجاز نیست.',403));}]);
}
function alpha_dbcheck($result){global $wpdb;if($result===false)throw new RuntimeException('Database operation failed');return $result;}
function alpha_tx($fn){global $wpdb;alpha_dbcheck($wpdb->query('START TRANSACTION'));try{$r=$fn();alpha_dbcheck($wpdb->query('COMMIT'));return $r;}catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}}
function alpha_insert($table,$data){global $wpdb;alpha_dbcheck($wpdb->insert(alpha_table($table),$data));return (int)$wpdb->insert_id;}
function alpha_audit($kind,$id,$event,$detail=[]){alpha_insert('audit',['actor_id'=>get_current_user_id(),'kind'=>$kind,'entity_id'=>$id,'event'=>$event,'detail'=>wp_json_encode($detail),'created_at'=>alpha_now()]);do_action('alpha_event',$event,$kind,$id);}
function alpha_get($table,$id,$lock=false){global $wpdb;$row=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.alpha_table($table).' WHERE id=%d'.($lock?' FOR UPDATE':''),$id),ARRAY_A);if($wpdb->last_error)throw new RuntimeException('Database read failed');if(!$row)alpha_fail('رکورد یافت نشد.',404);return $row;}
function alpha_digits($s){return strtr((string)$s,array_combine(preg_split('//u','۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩',-1,PREG_SPLIT_NO_EMPTY),str_split('01234567890123456789')));}
function alpha_phone($s){$v=trim(alpha_digits($s));if(!preg_match('/\A09[0-9]{9}\z/',$v))alpha_fail('شماره موبایل باید ۱۱ رقم و با ۰۹ شروع شود.');return $v;}
function alpha_money($s){$v=alpha_digits($s);if(!preg_match('/\A[0-9]{1,15}\z/',$v)||((int)$v)<1)alpha_fail('مبلغ ریالی معتبر وارد کنید.');return (int)$v;}
function alpha_text($v,$max=300){if(!is_scalar($v))alpha_fail('مقدار ورودی معتبر نیست.');$s=sanitize_textarea_field((string)$v);if(mb_strlen($s)>$max)alpha_fail('متن بیش از حد طولانی است.');return $s;}
function alpha_limit($r){return min(100,max(1,(int)($r['limit']?:50)));}
function alpha_profile_access($id,$financial=false){$s=alpha_get('students',$id);if(current_user_can('alpha_manage')||current_user_can($financial?'alpha_finance':'alpha_profiles'))return $s;if($financial&&current_user_can('alpha_consult'))alpha_fail('دسترسی مالی مجاز نیست.',403);if((int)$s['user_id']===get_current_user_id()&&current_user_can('alpha_student'))return $s;if(!$financial&&current_user_can('alpha_consult')&&(int)$s['consultant_id']===get_current_user_id())return $s;alpha_fail('دسترسی به این پرونده مجاز نیست.',403);}
function alpha_rate($bucket,$max=10){$ip=$_SERVER['REMOTE_ADDR']??'';$key='alpha_rate_'.hash_hmac('sha256',$bucket.'|'.$ip,wp_salt('nonce'));$n=(int)get_transient($key);if($n>=$max)alpha_fail('تعداد درخواست زیاد است؛ چند دقیقه دیگر تلاش کنید.',429);set_transient($key,$n+1,10*MINUTE_IN_SECONDS);}
function alpha_module($slug){add_filter('alpha_modules',function($a)use($slug){$a[]=$slug;return $a;});}
function alpha_upload($r){
    alpha_rate('upload_'.get_current_user_id(),30);
    $f=$r->get_file_params()['file']??null;if(!$f||$f['error']!==UPLOAD_ERR_OK||$f['size']>5*1024*1024||$f['size']<1)alpha_fail('فایل سالم با حجم حداکثر ۵ مگابایت انتخاب کنید.');
    if(!is_uploaded_file($f['tmp_name']))alpha_fail('بارگذاری معتبر نیست.');
    $type=wp_check_filetype_and_ext($f['tmp_name'],$f['name'],['jpg|jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','pdf'=>'application/pdf']);
    if(empty($type['type']))alpha_fail('فقط تصویر JPG، PNG، WebP یا PDF مجاز است.');
    if($type['type']==='application/pdf'&&file_get_contents($f['tmp_name'],false,null,0,5)!=='%PDF-')alpha_fail('فایل PDF معتبر نیست.');
    $student=(int)$r['student_id'];if($student)alpha_profile_access($student);
    $id=alpha_insert('files',['owner_id'=>get_current_user_id(),'student_id'=>$student,'name'=>sanitize_file_name($f['name']),'mime'=>$type['type'],'data'=>base64_encode(file_get_contents($f['tmp_name'])),'created_at'=>alpha_now()]);
    alpha_audit('file',$id,'file_uploaded');return ['id'=>$id,'name'=>sanitize_file_name($f['name'])];
}
function alpha_file_url($id){return add_query_arg('_wpnonce',wp_create_nonce('alpha_file_'.(int)$id),admin_url('admin-post.php?action=alpha_file&id='.(int)$id));}
function alpha_download(){
    global $wpdb;
    try{if(!is_user_logged_in())alpha_fail('ورود لازم است.',403);$id=absint($_GET['id']??0);if(!wp_verify_nonce($_GET['_wpnonce']??'','alpha_file_'.$id))alpha_fail('اعتبار درخواست پایان یافته است.',403);$f=alpha_get('files',$id);
    if(!current_user_can('alpha_manage')&&!current_user_can('alpha_finance')&&(int)$f['owner_id']!==get_current_user_id()){
        $invoice_id=$wpdb->get_var($wpdb->prepare('SELECT invoice_id FROM '.alpha_table('payments').' WHERE file_id=%d LIMIT 1',$id));
        if($invoice_id){$invoice=alpha_get('invoices',$invoice_id);alpha_profile_access((int)$invoice['student_id'],true);}else{if(!$f['student_id'])alpha_fail('دسترسی مجاز نیست.',403);alpha_profile_access((int)$f['student_id']);}
    }
    nocache_headers();header('X-Content-Type-Options: nosniff');header('Content-Type: '.$f['mime']);header('Content-Disposition: attachment; filename="download"; filename*=UTF-8\'\''.rawurlencode($f['name']));echo base64_decode($f['data']);exit;
    }catch(Throwable $e){wp_die(esc_html('دسترسی به فایل مجاز نیست.'),'خطا',['response'=>403]);}
}

<?php
defined('ABSPATH') || exit;
add_action('alpha_register_routes',function(){
 alpha_route('/overview','GET',function(){
  global $wpdb;$uid=get_current_user_id();$manager=current_user_can('alpha_manage');$reception=current_user_can('alpha_admissions');$financial=current_user_can('alpha_finance');$consult=current_user_can('alpha_consult')&&!$manager&&!$reception&&!$financial;
  $where=($manager||$reception||$financial)?'':($consult?$wpdb->prepare(' WHERE consultant_id=%d',$uid):$wpdb->prepare(' WHERE user_id=%d',$uid));
  $students=$wpdb->get_results('SELECT id,lead_id,user_id,consultant_id,name,phone,data,created_at FROM '.alpha_table('students').$where.' ORDER BY id DESC LIMIT 6',ARRAY_A);
  foreach($students as &$s){$s['data']=json_decode($s['data'],true);$s['consultant_name']=$s['consultant_id']?(get_userdata($s['consultant_id'])->display_name??''):'';}unset($s);
  $count=(int)$wpdb->get_var('SELECT COUNT(*) FROM '.alpha_table('students').$where);$leads=[];$stage=[];$activity=[];
  if($manager||$reception){$leads=$wpdb->get_results('SELECT stage,COUNT(*) AS total FROM '.alpha_table('leads').' GROUP BY stage',ARRAY_A);foreach($leads as $row)$stage[$row['stage']]=(int)$row['total'];$activity=$wpdb->get_results('SELECT actor_id,kind,entity_id,event,created_at FROM '.alpha_table('audit').' ORDER BY id DESC LIMIT 6',ARRAY_A);}
  $since=gmdate('Y-m-d H:i:s',time()-220*DAY_IN_SECONDS);$daily=function($table,$condition='',$sum=false)use($wpdb,$since){$rows=$wpdb->get_results($wpdb->prepare('SELECT created_at'.($sum?',amount':'').' FROM '.alpha_table($table).' WHERE created_at>=%s'.$condition,$since),ARRAY_A);$days=[];foreach($rows as $r){$d=(new DateTimeImmutable($r['created_at'],new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Tehran'))->format('Y-m-d');$days[$d]=($days[$d]??0)+($sum?(int)$r['amount']:1);}ksort($days);return $days;};
  $chart=['registrations'=>[],'leads'=>[],'payments'=>[]];if($manager||$reception){$chart['registrations']=$daily('students');$chart['leads']=$daily('leads');}
  $money=['total'=>0,'paid'=>0,'balance'=>0,'pending'=>0,'next_amount'=>0];
  if($financial){$money['total']=(int)$wpdb->get_var('SELECT COALESCE(SUM(amount),0) FROM '.alpha_table('invoices'));$money['paid']=(int)$wpdb->get_var('SELECT COALESCE(SUM(amount),0) FROM '.alpha_table('payments')." WHERE status='approved'");$money['pending']=(int)$wpdb->get_var('SELECT COUNT(*) FROM '.alpha_table('payments')." WHERE status='pending'");$chart['payments']=$daily('payments'," AND status='approved'",true);}
  elseif(!$consult&&!$reception){$money['total']=(int)$wpdb->get_var($wpdb->prepare('SELECT COALESCE(SUM(i.amount),0) FROM '.alpha_table('invoices').' i JOIN '.alpha_table('students').' s ON s.id=i.student_id WHERE s.user_id=%d',$uid));$money['paid']=(int)$wpdb->get_var($wpdb->prepare('SELECT COALESCE(SUM(p.amount),0) FROM '.alpha_table('payments')." p JOIN ".alpha_table('invoices').' i ON i.id=p.invoice_id JOIN '.alpha_table('students')." s ON s.id=i.student_id WHERE s.user_id=%d AND p.status='approved'",$uid));}
  $money['balance']=$money['total']-$money['paid'];
  $bookWhere=($manager||$reception)?'':($consult?$wpdb->prepare(' AND sl.consultant_id=%d',$uid):$wpdb->prepare(' AND (b.user_id=%d OR b.lead_id IN (SELECT lead_id FROM '.alpha_table('students').' WHERE user_id=%d))',$uid,$uid));
  $upcoming=$wpdb->get_results("SELECT b.id,b.user_id,b.lead_id,b.status,sl.title,sl.starts_at,sl.ends_at,sl.consultant_id,COALESCE(l.name,u.display_name,'') AS name FROM ".alpha_table('bookings').' b JOIN '.alpha_table('slots').' sl ON sl.id=b.slot_id LEFT JOIN '.alpha_table('leads').' l ON l.id=b.lead_id LEFT JOIN '.$wpdb->users." u ON u.ID=b.user_id WHERE sl.starts_at>=UTC_TIMESTAMP() AND b.status IN ('pending','approved')".$bookWhere.' ORDER BY sl.starts_at LIMIT 50',ARRAY_A);
  return ['students'=>$students,'student_count'=>$count,'stages'=>$stage,'chart'=>$chart,'money'=>$money,'upcoming'=>$upcoming,'activities'=>$activity];
 },'alpha_access');
});

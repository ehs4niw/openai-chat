<?php
defined('ABSPATH') || exit;

function alpha_first_visit_active() {
    return is_user_logged_in() && current_user_can('alpha_student')
        && get_user_meta(get_current_user_id(), 'alpha_first_visit', true) === 'pending';
}

function alpha_first_visit_lead($uid) {
    global $wpdb;
    return $wpdb->get_row($wpdb->prepare(
        'SELECT * FROM ' . alpha_table('leads') . ' WHERE user_id=%d ORDER BY id LIMIT 1', $uid
    ), ARRAY_A);
}

function alpha_first_visit_booking($lead_id, $lock = false) {
    global $wpdb;
    return $wpdb->get_row($wpdb->prepare(
        'SELECT b.status,s.title,s.starts_at FROM ' . alpha_table('bookings') . ' b JOIN '
        . alpha_table('slots') . " s ON s.id=b.slot_id WHERE b.lead_id=%d AND b.status IN ('pending','approved') ORDER BY b.id DESC LIMIT 1"
        . ($lock ? ' FOR UPDATE' : ''), $lead_id
    ), ARRAY_A);
}

function alpha_is_free_intro($title) {
    $title = strtr($title, ['ي' => 'ی', 'ك' => 'ک']);
    return str_contains($title, 'معارفه') && str_contains($title, 'رایگان');
}

function alpha_first_visit_profile_fields() {
    return [
        'مشخصات فردی' => [
            'father' => 'نام پدر', 'birth' => 'تاریخ تولد شمسی', 'birth_place' => 'محل تولد',
            'national_id' => 'کد ملی', 'guardian' => 'ولی جهت پیگیری', 'city' => 'شهر',
        ],
        'خانواده و تماس' => [
            'father_education' => 'تحصیلات پدر', 'father_job' => 'شغل پدر', 'father_phone' => 'موبایل پدر',
            'mother_education' => 'تحصیلات مادر', 'mother_job' => 'شغل مادر', 'mother_phone' => 'موبایل مادر',
            'brothers' => 'تعداد برادر', 'sisters' => 'تعداد خواهر', 'birth_order' => 'فرزند چندم',
            'address' => 'نشانی منزل',
        ],
        'تحصیل و آشنایی' => [
            'grade' => 'پایه تحصیلی', 'major' => 'رشته تحصیلی', 'school' => 'مدرسه یا دانشگاه',
            'gpa' => 'معدل سال گذشته', 'interest_major' => 'رشته دانشگاهی مورد علاقه',
            'interest_job' => 'شغل مورد علاقه', 'personality' => 'تیپ شخصیتی', 'source' => 'شیوه آشنایی',
            'referrer' => 'نام معرف', 'past_services' => 'خدمات قبلی',
        ],
    ];
}

function alpha_prepare_first_visit_lead($uid) {
    alpha_tx(function () use ($uid) {
        global $wpdb;
        if (!$wpdb->get_var($wpdb->prepare("SELECT ID FROM {$wpdb->users} WHERE ID=%d FOR UPDATE", $uid))) {
            throw new RuntimeException('Account lock failed');
        }
        if (alpha_first_visit_lead($uid)) return;
        $user = wp_get_current_user();
        $data = [
            'first_name' => $user->first_name,
            'last_name' => $user->last_name,
            'exam_group' => get_user_meta($uid, 'alpha_exam_group', true),
            'major' => get_user_meta($uid, 'alpha_exam_group', true),
        ];
        $id = alpha_insert('leads', [
            'user_id' => $uid, 'name' => $user->display_name,
            'phone' => alpha_phone(get_user_meta($uid, 'alpha_phone', true)),
            'data' => wp_json_encode($data), 'stage' => 'new',
            'created_at' => alpha_now(), 'updated_at' => alpha_now(),
        ]);
        alpha_audit('lead', $id, 'intake_created');
    });
}

add_action('alpha_register_routes', function () {
    alpha_route('/first-visit/reserve', 'POST', function ($r) {
        if (!alpha_first_visit_active()) alpha_fail('دسترسی مجاز نیست.', 403);
        if (!function_exists('alpha_reserve') || !defined('ALPHA_BOOKING_FIRST_VISIT')) {
            alpha_fail('رزرو آنلاین در حال حاضر در دسترس نیست.', 409);
        }
        alpha_prepare_first_visit_lead(get_current_user_id());
        return alpha_reserve([
            'slot_id' => (int) $r['slot_id'], 'user_id' => 0,
            'request_key' => (string) $r['request_key'],
        ], 0, true);
    }, 'alpha_student');

    alpha_route('/first-visit/profile', 'POST', function ($r) {
        if (!alpha_first_visit_active()) alpha_fail('دسترسی مجاز نیست.', 403);
        if (!function_exists('alpha_lead_data')) alpha_fail('فرم پرونده در دسترس نیست.', 409);
        $uid = get_current_user_id();
        $result = alpha_tx(function () use ($r, $uid) {
            global $wpdb;
            $lead = alpha_first_visit_lead($uid);
            if (!$lead) alpha_fail('ابتدا جلسه معارفه را رزرو کنید.', 409);
            $booking = alpha_first_visit_booking($lead['id'], true);
            if (!$booking) alpha_fail('ابتدا جلسه معارفه را رزرو کنید.', 409);
            $lead = alpha_get('leads', $lead['id'], true);
            $previous = json_decode($lead['data'], true) ?: [];
            $submitted = alpha_lead_data($r);
            foreach (array_keys(array_merge(...array_values(alpha_first_visit_profile_fields()))) as $field) {
                if ($r->has_param($field)) $previous[$field] = $submitted[$field];
            }
            $previous['national_id'] = alpha_digits($previous['national_id'] ?? '');
            if (!preg_match('/\A[0-9]{10}\z/', $previous['national_id']) || empty($previous['grade']) || empty($previous['city'])) {
                alpha_fail('کد ملی ۱۰ رقمی، پایه و شهر را وارد کنید.');
            }
            foreach (['father_phone', 'mother_phone'] as $field) {
                if (!empty($previous[$field])) $previous[$field] = alpha_phone($previous[$field]);
            }
            $data = wp_json_encode($previous);
            alpha_dbcheck($wpdb->update(alpha_table('leads'), ['data' => $data, 'updated_at' => alpha_now()], ['id' => $lead['id']]));
            alpha_dbcheck($wpdb->update(alpha_table('students'), ['data' => $data], ['lead_id' => $lead['id']]));
            alpha_audit('lead', $lead['id'], 'profile_completed');
            $changed = alpha_dbcheck($wpdb->update($wpdb->usermeta, ['meta_value' => 'complete'], [
                'user_id' => $uid, 'meta_key' => 'alpha_first_visit', 'meta_value' => 'pending',
            ]));
            if (!$changed) alpha_fail('پرونده قبلاً تکمیل شده است. صفحه را تازه کنید.', 409);
            return ['ok' => true];
        });
        wp_cache_delete($uid, 'user_meta');
        return $result;
    }, 'alpha_student');
});

function alpha_first_visit_view() {
    global $wpdb;
    $lead = alpha_first_visit_lead(get_current_user_id());
    $booking = $lead ? alpha_first_visit_booking($lead['id']) : null;
    $data = $lead ? (json_decode($lead['data'], true) ?: []) : [];
    $slots = [];
    if (!$booking && defined('ALPHA_BOOKING_FIRST_VISIT')) {
        $rows = $wpdb->get_results('SELECT id,title,starts_at FROM ' . alpha_table('slots')
            . ' WHERE active=1 AND reserved<capacity AND starts_at>UTC_TIMESTAMP() ORDER BY starts_at', ARRAY_A);
        $slots = array_slice(array_values(array_filter($rows, fn($slot) => alpha_is_free_intro($slot['title']))), 0, 100);
    }
    wp_enqueue_script('alpha-first-visit', plugins_url('assets/first-visit.js', dirname(__DIR__) . '/alpha-core.php'), [], ALPHA_VERSION, true);
    wp_localize_script('alpha-first-visit', 'alphaFirstVisit', [
        'reserve' => rest_url('alpha/v1/first-visit/reserve'),
        'profile' => rest_url('alpha/v1/first-visit/profile'),
        'nonce' => wp_create_nonce('wp_rest'),
        'requestKey' => wp_generate_uuid4(),
        'panel' => home_url('/alpha-panel/'),
    ]);
    ob_start();
    require __DIR__ . '/../templates/first-visit.php';
    return ob_get_clean();
}

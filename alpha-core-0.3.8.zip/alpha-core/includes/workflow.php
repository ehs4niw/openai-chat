<?php
defined('ABSPATH') || exit;
function alpha_resume_state(){
 global $wpdb;$uid=get_current_user_id();$draft=get_user_meta($uid,'alpha_intake_draft',true);if(!is_array($draft))$draft=['step'=>0,'data'=>[]];
 $lead=$wpdb->get_row($wpdb->prepare('SELECT id FROM '.alpha_table('leads').' WHERE user_id=%d ORDER BY id LIMIT 1',$uid),ARRAY_A);
 if($lead){$booking=$wpdb->get_row($wpdb->prepare('SELECT b.id,b.status,s.starts_at,s.title FROM '.alpha_table('bookings').' b JOIN '.alpha_table('slots').' s ON s.id=b.slot_id WHERE b.lead_id=%d ORDER BY b.id DESC LIMIT 1',$lead['id']),ARRAY_A);$token=bin2hex(random_bytes(24));$wpdb->update(alpha_table('leads'),['booking_token_hash'=>hash('sha256',$token),'booking_token_expires'=>gmdate('Y-m-d H:i:s',time()+12*HOUR_IN_SECONDS)],['id'=>$lead['id']]);$draft['lead']=['id'=>(int)$lead['id'],'booking_token'=>$token,'requested'=>(bool)$booking,'booking'=>$booking];}
 return $draft;
}
add_action('alpha_register_routes',function(){
 alpha_route('/intake/draft','POST',function($r){$step=(int)$r['step'];if($step<0||$step>2)alpha_fail('مرحله معتبر نیست.');$data=alpha_lead_data($r);$data['phone']=alpha_phone($r['phone']??'');if(!$data['first_name']||!$data['last_name'])alpha_fail('نام و نام خانوادگی لازم است.');update_user_meta(get_current_user_id(),'alpha_intake_draft',['step'=>$step,'data'=>$data]);return ['ok'=>true];},'read');
});
add_action('init',function(){if(get_option('alpha_schema_version')!==ALPHA_VERSION)alpha_activate();},4);
add_action('wp_login',function($login,$user){if(!user_can($user,'alpha_access')&&get_user_meta($user->ID,'alpha_phone',true))$user->add_role('alpha_student');},20,2);
function alpha_panel_brand_logo() {
    if (function_exists('amzshyar_ops_get')) {
        $logo = esc_url_raw((string) amzshyar_ops_get('header-logo', ''), ['http', 'https']);
        if ($logo) return $logo;
    }

    $id = (int) get_theme_mod('custom_logo');
    return $id ? (wp_get_attachment_image_url($id, 'full') ?: '') : '';
}

add_filter('get_site_icon_url', function ($url, $size) {
    if (!is_page(['alpha-panel', 'alpha-intake'])) return $url;
    $id = (int) get_option('alpha_panel_icon_id');
    if ($id) {
        $icon = wp_get_attachment_image_url($id, [$size, $size]);
        if ($icon) return $icon;
    }
    if ($url) return $url;

    return function_exists('amzshyar_ops_get')
        ? esc_url_raw((string) amzshyar_ops_get('favicon', ''), ['http', 'https'])
        : '';
}, 20, 2);

add_action('admin_init',function(){
 register_setting('general','alpha_panel_icon_id',['type'=>'integer','sanitize_callback'=>'absint']);
 add_settings_field('alpha_panel_icon_id','نمادک پنل آلفا',function(){
 wp_enqueue_media();$id=(int)get_option('alpha_panel_icon_id',0);echo '<input type="hidden" id="alpha_panel_icon_id" name="alpha_panel_icon_id" value="'.esc_attr($id).'">';echo '<img id="alpha-icon-preview" src="'.esc_url($id?wp_get_attachment_image_url($id,'thumbnail'):'').'" style="max-width:64px;display:block;margin-bottom:8px"><button type="button" class="button" id="alpha-select-icon">انتخاب تصویر نمادک</button> <button type="button" class="button" id="alpha-remove-icon">استفاده از نمادک سایت</button><p class="description">تصویر آلفا را از کتابخانه رسانه انتخاب و تغییرات را ذخیره کنید.</p>';
 ?>
 <script>document.getElementById('alpha-select-icon').onclick=function(){const frame=wp.media({title:'نمادک پنل آلفا',library:{type:'image'},multiple:false});frame.on('select',function(){const x=frame.state().get('selection').first().toJSON();document.getElementById('alpha_panel_icon_id').value=x.id;document.getElementById('alpha-icon-preview').src=x.url});frame.open()};document.getElementById('alpha-remove-icon').onclick=function(){document.getElementById('alpha_panel_icon_id').value=0;document.getElementById('alpha-icon-preview').src=''};</script>
 <?php
 },'general');
});

<?php
/**
 * Plugin Name: فونت اختصاصی دانشگران — ایران‌یکان X
 * Description: نصب فونت خریداری‌شده برای daneshgaranedu.ir؛ برای بازنشر عمومی نیست.
 * Version: 1.0.0
 */
if(!defined('ABSPATH'))exit;
function dgs_private_font_install(){
 if(!current_user_can('activate_plugins'))wp_die('دسترسی ندارید.');$uploads=wp_upload_dir();if(!empty($uploads['error']))wp_die('مسیر بارگذاری آماده نیست.');$dir=$uploads['basedir'].'/daneshgaran-fonts';if(!wp_mkdir_p($dir))wp_die('پوشه فونت ساخته نشد.');
 foreach(array('IRANYekanXVF.woff2','IRANYekanXVF.woff') as $file){$source=__DIR__.'/fonts/'.$file;$target=$dir.'/'.$file;if(!copy($source,$target)||hash_file('sha256',$source)!==hash_file('sha256',$target))wp_die('کپی فونت کامل نشد.');@chmod($target,0644);}
 copy(__DIR__.'/FontLicense.txt',$dir.'/FontLicense.txt');
}
register_activation_hook(__FILE__,'dgs_private_font_install');

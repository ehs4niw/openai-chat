/* Studio design states only: no server calls, payment, SMS, or authentication. */
(()=>{'use strict';const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)],q=new URLSearchParams(location.search),page=document.body.dataset.page;
const showMode=n=>{$$('[data-mode-content]').forEach(x=>x.classList.toggle('hidden',x.dataset.modeContent!==String(n)));$$('[data-mode]').forEach(x=>x.classList.toggle('active',x.dataset.mode===String(n)))};
$$('[data-mode]').forEach(el=>el.onclick=()=>showMode(el.dataset.mode));if(q.has('mode'))showMode(q.get('mode'));
const modeLinks={};
$$('a[href]').forEach(a=>{try{const u=new URL(a.href);if(u.pathname===location.pathname&&u.searchParams.has('mode'))a.addEventListener('click',e=>{e.preventDefault();showMode(u.searchParams.get('mode'));history.replaceState(null,'',u);scrollTo({top:0,behavior:'smooth'})})}catch{}});
if(page==='07-learning'){
 function resource(name){
  if(name==='results'){location.href='11-results.html';return}if(name==='info'){location.href='04-course.html';return}
  $$('[data-resource-content]').forEach(x=>x.classList.toggle('hidden',x.dataset.resourceContent!==name));$$('[data-learning-tab]').forEach(x=>x.classList.toggle('active',x.dataset.learningTab===name));
 }
 $$('[data-resource]').forEach(x=>x.onclick=()=>resource(x.dataset.resource));$$('[data-learning-tab]').forEach(x=>x.onclick=()=>resource(x.dataset.learningTab));if(q.get('view')==='book')resource('book');
 const full=q.get('view')==='full',unlocked=Number(localStorage.getItem('spinach-unlocked')||0)>=2;
 if(full||unlocked){const lesson=$('[data-session="3"]');if(lesson){lesson.classList.remove('locked');lesson.querySelector('svg').innerHTML='<path d="m9 5 11 7-11 7Z"/>'}}
 if(full){$$('.video-row.locked').forEach(x=>x.classList.remove('locked'));$('.course-progress h3').textContent='دسترسی کامل دوره'}
 $$('[data-session]').forEach(x=>{x.onclick=()=>{if(x.classList.contains('locked'))return;$$('[data-session]').forEach(y=>y.classList.remove('active'));x.classList.add('active');$('.video-titles span').textContent=$('span',x).textContent;resource('video')}});
 $$('[data-chapter]').forEach(x=>x.onclick=()=>{if(Number(x.dataset.chapter)>3&&!full)return;$$('[data-chapter]').forEach(y=>y.classList.remove('active'));x.classList.add('active');$('.lesson-panel h2').textContent=$('b',x).textContent});
}
if(page==='04-course'){
 const names={offline:['دوره آفلاین','زیست جامع دوازدهم','۱٬۹۹۰٬۰۰۰'],online:['دوره آنلاین','کلاس آنلاین زیست دوازدهم','۲٬۴۹۰٬۰۰۰'],pack:['پک آموزشی','پک جامع کنکور تجربی','۶٬۲۹۰٬۰۰۰']};
 function kind(name){const v=names[name]||names.offline;$$('[data-course-kind]').forEach(x=>x.classList.toggle('active',x.dataset.courseKind===name));const aside=$('aside');if(aside){$('h2',aside).textContent=v[1];$('.badge',aside).textContent=v[0];$('.price-big',aside).innerHTML=v[2]+' <small>تومان</small>'}}
 $$('[data-course-kind]').forEach(x=>x.onclick=()=>kind(x.dataset.courseKind));if(q.get('view')==='pack')kind('pack');
}
if(page==='03-store'){
 const labels={'همه محصولات':null,'دوره آموزشی':'course','کتاب فیزیکی':'book','پک آموزشی':'package'};$$('.tabs .tab').forEach(el=>el.onclick=()=>{$$('.tabs .tab').forEach(x=>x.classList.remove('active'));el.classList.add('active');$$('[data-kind]').forEach(x=>x.classList.toggle('hidden',!!labels[el.textContent]&&x.dataset.kind!==labels[el.textContent]))});if(q.get('view')==='book')$$('.tabs .tab').find(x=>x.textContent==='کتاب فیزیکی')?.click()
}
if(page==='28-auth')$$('[data-auth-form]').forEach(f=>f.addEventListener('submit',e=>{e.preventDefault()}));
$$('[data-complete-quiz]').forEach(a=>a.addEventListener('click',()=>localStorage.setItem('spinach-unlocked','2')));
// The checkout remains a single page with two explicit states.
if(page==='06-checkout'){
 const step=localStorage.getItem('spinach-access')==='step',notice=$('.mode-content[data-mode-content="0"] .notice.green');if(notice)notice.textContent=step?'یادگیری مرحله‌ای انتخاب شده است؛ با تکمیل آزمون، همه محتوای جلسه بعد یکجا باز می‌شود.':'دسترسی کامل انتخاب شده است؛ پس از خرید همه جلسات در دسترس خواهند بود.';
 const desc=$$('.mode-content[data-mode-content="0"] .table-wrap small').find(x=>x.textContent.includes('مرحله‌ای'));if(desc)desc.textContent=step?'دوره آفلاین · یادگیری مرحله‌ای':'دوره آفلاین · دسترسی کامل';
 $$('a[href]').forEach(a=>{if(a.textContent.includes('ادامه و تکمیل سفارش'))a.onclick=e=>{e.preventDefault();showMode(1);scrollTo({top:0,behavior:'smooth'})}});
}
})();
(()=>{if(document.body.dataset.page!=='07-learning')return;const q=new URLSearchParams(location.search);if(q.get('start')!=='1')return;const passed=Number(localStorage.getItem('spinach-unlocked')||0)>=2;document.querySelector('.lesson-panel h2').textContent='فصل ۱: مولکول‌های اطلاعاتی';document.querySelector('.video-titles b').textContent='فصل ۱ | مولکول‌های اطلاعاتی';document.querySelector('.course-progress h3').textContent='شروع مسیر یادگیری';document.querySelector('.progress-ring span').textContent=passed?'۸٪':'۰٪';document.querySelectorAll('[data-session]').forEach(x=>{const n=Number(x.dataset.session);x.classList.toggle('locked',n>(passed?2:1));x.classList.toggle('active',n===(passed?2:1))});document.querySelectorAll('[data-chapter]').forEach(x=>x.classList.toggle('active',x.dataset.chapter==='1'));})();

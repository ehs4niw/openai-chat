<?php defined('ABSPATH') || exit;
?><!doctype html><html <?php language_attributes(); ?> dir="rtl"><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head><body <?php body_class('alpha-portal-page'); ?>><?php wp_body_open();
// The dedicated panel page always mounts the app, even if its content was edited.
if (is_page('alpha-panel')) {
    echo alpha_first_visit_active() ? alpha_first_visit_view() : alpha_shortcode();
} else {
    while (have_posts()) { the_post(); echo do_shortcode(get_the_content()); }
}
wp_footer(); ?></body></html>

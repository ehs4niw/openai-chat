/* Alpha sessions: standalone readable React component, mounted by the existing application. */
(function(){'use strict';
const fmt=new Intl.DateTimeFormat('en-US-u-ca-persian-nu-latn',{year:'numeric',month:'numeric',day:'numeric',timeZone:'UTC'});
const parts=d=>Object.fromEntries(fmt.formatToParts(d).filter(x=>x.type!=='literal').map(x=>[x.type,+x.value]));
function greg(y,m,d){let a=Date.UTC(y+621,0,1,12);for(let i=-180;i<550;i++){let date=new Date(a+i*86400000),p=parts(date);if(p.year===y&&p.month===m&&p.day===d)return date;}return null;}
const iso=d=>d.toISOString().slice(0,10), pad=n=>String(n).padStart(2,'0');
const fa=n=>new Intl.NumberFormat('fa-IR',{useGrouping:false}).format(n);
const label=d=>new Intl.DateTimeFormat('fa-IR',{dateStyle:'full',timeZone:'UTC'}).format(d);
const local=s=>new Date(s.replace(' ','T')+'Z');
const time=s=>new Intl.DateTimeFormat('fa-IR',{hour:'2-digit',minute:'2-digit',hourCycle:'h23',timeZone:'Asia/Tehran'}).format(local(s));
const key=s=>new Intl.DateTimeFormat('en-CA',{year:'numeric',month:'2-digit',day:'2-digit',timeZone:'Asia/Tehran'}).format(local(s));
const statuses={pending:'در انتظار تأیید',approved:'تأیید شده',cancelled:'لغو شده',rejected:'رد شده'};
async function api(path,data){const [route,query]=path.split('?');let url=new URL(window.ALPHA.api+route);if(query)new URLSearchParams(query).forEach((v,k)=>url.searchParams.set(k,v));let r=await fetch(url,{credentials:'same-origin',headers:{'X-WP-Nonce':window.ALPHA.nonce,'Content-Type':'application/json'},...(data?{method:'POST',body:JSON.stringify(data)}:{})});let v=await r.json();if(!r.ok)throw Error(v.message||'درخواست انجام نشد.');return v;}
window.AlphaDateField=function({React:R,name,title,value}){
 const h=R.createElement, initial=parts(new Date(value+'T12:00:00Z'));
 const [val,setVal]=R.useState(initial.year+'/'+pad(initial.month)+'/'+pad(initial.day)),[open,setOpen]=R.useState(false),[m,setM]=R.useState(initial);
 const start=greg(m.year,m.month,1),end=greg(m.month===12?m.year+1:m.year,m.month===12?1:m.month+1,1),count=Math.round((end-start)/86400000),cells=[];
 for(let i=0;i<(start.getUTCDay()+1)%7;i++)cells.push(h('span',{key:'e'+i}));
 for(let d=1;d<=count;d++)cells.push(h('button',{key:d,type:'button',onClick:()=>{setVal(m.year+'/'+pad(m.month)+'/'+pad(d));setOpen(false)}},fa(d)));
 function move(n){let next=m.month+n,y=m.year;if(next<1){next=12;y--}if(next>12){next=1;y++}setM({year:y,month:next})}
 return h('div',{className:'ab-date-field'},h('label',{className:'ab-field'},title,h('input',{name,value:val,onChange:e=>setVal(e.target.value),required:true,dir:'ltr',placeholder:'1405/09/03',pattern:'[0-9۰-۹]{4}/[0-9۰-۹]{1,2}/[0-9۰-۹]{1,2}'})),h('button',{type:'button',className:'ab-btn',onClick:()=>setOpen(!open),'aria-expanded':open},'▦ انتخاب تاریخ'),open&&h('div',{className:'ab-date-picker'},h('header',null,h('button',{type:'button',onClick:()=>move(-1)},'‹'),h('b',null,new Intl.DateTimeFormat('fa-IR',{year:'numeric',month:'long',timeZone:'UTC'}).format(start)),h('button',{type:'button',onClick:()=>move(1)},'›')),h('div',{className:'ab-date-grid'},['ش','ی','د','س','چ','پ','ج'].map(x=>h('b',{key:x},x)),cells)));
};
window.ALPHA_MANAGER=function({React:R}){
 const h=R.createElement,[selected,setSelected]=R.useState(iso(new Date())),[month,setMonth]=R.useState(parts(new Date())),[view,setView]=R.useState('month'),[data,setData]=R.useState({slots:[],bookings:[],consultants:[],settings:{duration:30,gap:0,capacity:1}}),[error,setError]=R.useState(''),[loading,setLoading]=R.useState(true),[modal,setModal]=R.useState(null),[busy,setBusy]=R.useState(false),[history,setHistory]=R.useState([]),[menu,setMenu]=R.useState(false),[all,setAll]=R.useState(false);
 const first=greg(month.year,month.month,1),next=greg(month.month===12?month.year+1:month.year,month.month===12?1:month.month+1,1),days=Math.round((next-first)/86400000);
 async function reload(){setLoading(true);try{setData(await api('booking/manage?start='+encodeURIComponent(iso(new Date(+first-7*86400000))+'T00:00:00+03:30')+'&end='+encodeURIComponent(iso(new Date(+next+7*86400000))+'T00:00:00+03:30')));setError('')}catch(e){setError(e.message)}finally{setLoading(false)}}
 R.useEffect(()=>{reload()},[month.year,month.month]);
 R.useEffect(()=>{if(!modal)return;const previous=document.activeElement,overflow=document.body.style.overflow;document.body.style.overflow='hidden';const timer=setTimeout(()=>document.querySelector('.ab-dialog button,.ab-dialog input')?.focus(),0);const fn=e=>{if(e.key==='Escape'&&!busy)setModal(null);if(e.key==='Tab'){const nodes=[...document.querySelectorAll('.ab-dialog button:not(:disabled),.ab-dialog input:not(:disabled),.ab-dialog select:not(:disabled)')];if(!nodes.length)return;const first=nodes[0],last=nodes[nodes.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}};document.addEventListener('keydown',fn);return()=>{clearTimeout(timer);document.body.style.overflow=overflow;document.removeEventListener('keydown',fn);previous?.focus()}},[modal,busy]);
 const btn=(text,fn,cls='',disabled=false)=>h('button',{type:'button',className:'ab-btn '+cls,onClick:fn,disabled},text);
 const consultants=data.consultants, name=id=>consultants.find(x=>+x.id===+id)?.name||'بدون مشاور';
 const daySlots=data.slots.filter(s=>key(s.starts_at)===selected),dayBookings=data.bookings.filter(b=>key(b.starts_at)===selected);
 function move(n){let m=month.month+n,y=month.year;if(m<1){m=12;y--}if(m>12){m=1;y++}setMonth({year:y,month:m});setSelected(iso(greg(y,m,1)))}
 async function act(path,values){setBusy(true);setError('');try{await api(path,values);setModal(null);await reload()}catch(e){setError(e.message)}finally{setBusy(false)}}
 function open(type,slot){setError('');setModal({type,slot});setMenu(false)}
 function input(name,title,type='text',value='',extra={}){return h('label',{className:'ab-field',key:name},title,h('input',{name,type,defaultValue:value,...extra}))}
 function dateInput(name,title,value){return h(window.AlphaDateField,{React:R,name,title,value})}
 function readDate(v){v=String(v).replace(/[۰-۹]/g,c=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(c));let [y,m,d]=v.split('/').map(Number),date=greg(y,m,d);if(!date)throw Error('تاریخ شمسی معتبر نیست.');return iso(date)}
 function formSubmit(e){e.preventDefault();const f=Object.fromEntries(new FormData(e.currentTarget));try{
 if(modal.type==='settings'){act('booking/settings',f);return}
 if(modal.type==='reschedule'){act('bookings/'+modal.slot.id+'/reschedule',{slot_id:+f.slot_id});return}
 f.consultant_id=+f.consultant_id;f.capacity=+f.capacity;
 if(modal.type==='batch'){f.from=readDate(f.from);f.to=readDate(f.to);f.weekdays=new FormData(e.currentTarget).getAll('weekdays').map(Number);act('slots/batch',f);return}
 const date=readDate(f.date);f.starts_at=date+'T'+f.start_time+':00+03:30';f.ends_at=date+'T'+f.end_time+':00+03:30';f.active=f.active==='on';if(modal.slot)f.revision=modal.slot.revision;act(modal.slot?'slots/'+modal.slot.id:'slots',f);
 }catch(err){setError(err.message)}}
 function modalContent(){if(!modal)return null;let slot=modal.slot,isBatch=modal.type==='batch',isSettings=modal.type==='settings';let values=slot?{date:key(slot.starts_at),start:timeLatin(slot.starts_at),end:timeLatin(slot.ends_at)}:{date:selected,start:'09:00',end:isBatch?'12:00':pad(9+Math.floor(data.settings.duration/60))+':'+pad(data.settings.duration%60)};
 let body;if(modal.type==='history')body=h('div',{className:'ab-history'},history.map((x,i)=>h('article',{key:i},h('b',null,({slot_created:'ایجاد وقت',slot_updated:'ویرایش وقت',slots_batch_created:'ایجاد گروهی',booking_approved:'تأیید رزرو',booking_cancelled:'لغو رزرو',booking_rejected:'رد رزرو',booking_rescheduled:'تغییر زمان',booking_requested:'درخواست رزرو',settings_updated:'تغییر تنظیمات'}[x.event]||x.event)),h('p',null,label(local(x.created_at))+' — '+time(x.created_at)),h('small',null,'شناسه '+fa(x.entity_id)+' · کاربر '+fa(x.actor_id)),h('details',null,h('summary',null,'جزئیات تغییر'),h('pre',null,JSON.stringify(JSON.parse(x.detail||'{}'),null,2))))));
 else if(modal.type==='day')body=h('div',null,daySlots.map(s=>h('article',{className:'ab-slot',key:s.id},h('b',null,s.title),h('p',null,time(s.starts_at)+' تا '+time(s.ends_at)),btn('ویرایش وقت',()=>open('single',s)))));
 else body=h('form',{onSubmit:formSubmit,className:'ab-form'},
 modal.type==='reschedule'?h('label',{className:'ab-field'},'وقت جایگزین',h('select',{name:'slot_id',required:true},data.slots.filter(s=>+s.active&&+s.reserved<+s.capacity&&+s.id!==+slot.slot_id&&local(s.starts_at)>new Date()).map(s=>h('option',{key:s.id,value:s.id},s.title+' · '+label(local(s.starts_at))+' '+time(s.starts_at))))):h(R.Fragment,null,
 !isSettings&&input('title','موضوع جلسه','text',slot?.title||'جلسه معارفه رایگان',{required:true,maxLength:200}),
 !isSettings&&h('label',{className:'ab-field'},'مشاور',h('select',{name:'consultant_id',defaultValue:slot?.consultant_id||0},h('option',{value:0},'بدون مشاور'),consultants.map(c=>h('option',{key:c.id,value:c.id},c.name)))),
 !isSettings&&dateInput(isBatch?'from':'date',isBatch?'از تاریخ':'تاریخ جلسه',values.date),
 isBatch&&dateInput('to','تا تاریخ',values.date),
 !isSettings&&input('start_time','ساعت شروع (۲۴ ساعته)','text',values.start,{required:true,pattern:'(?:[01][0-9]|2[0-3]):[0-5][0-9]',placeholder:'09:00',dir:'ltr'}),
 !isSettings&&input('end_time','ساعت پایان (۲۴ ساعته)','text',values.end,{required:true,pattern:'(?:[01][0-9]|2[0-3]):[0-5][0-9]',placeholder:'12:00',dir:'ltr'}),
 (isBatch||isSettings)&&input('duration','مدت هر جلسه (دقیقه)','number',data.settings.duration,{min:5,max:480,required:true}),
 (isBatch||isSettings)&&input('gap','فاصله بین جلسات (دقیقه)','number',data.settings.gap,{min:0,max:240,required:true}),
 input('capacity','ظرفیت هر وقت','number',slot?.capacity||data.settings.capacity,{min:1,max:100,required:true}),
 isBatch&&h('fieldset',{className:'ab-weekdays'},h('legend',null,'تکرار در روزهای انتخاب‌شده، در تمام هفته‌های بازه'),['یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه','شنبه'].map((d,i)=>h('label',{key:i},h('input',{type:'checkbox',name:'weekdays',value:i,defaultChecked:i!==5}),d))),
 slot&&h('label',null,h('input',{type:'checkbox',name:'active',defaultChecked:!!+slot.active}),' وقت فعال باشد؛ غیرفعال‌کردن، رزروهای قبلی را لغو نمی‌کند')),
 h('div',{className:'ab-form-footer'},h('button',{className:'ab-btn primary',disabled:busy,type:'submit'},busy?'در حال ذخیره…':isBatch?'ایجاد وقت‌ها':'ذخیره تغییرات')));
 return h('div',{className:'ab-overlay',onClick:e=>{if(e.target===e.currentTarget&&!busy)setModal(null)}},h('section',{role:'dialog','aria-modal':true,'aria-label':'مدیریت جلسات',className:'ab-dialog'},h('header',null,h('h2',null,({single:slot?'ویرایش وقت':'ایجاد وقت تکی',batch:'ایجاد گروهی و تکرار هفتگی',settings:'تنظیمات جلسات',history:'سوابق تغییرات',day:'ویرایش جلسات روز',reschedule:'تغییر زمان رزرو'})[modal.type]),btn('✕',()=>setModal(null),'',busy)),error&&h('p',{role:'alert',className:'ab-error'},error),body));}
 let cells=[],dates=[];
 if(view==='month'){
 for(let i=0;i<(first.getUTCDay()+1)%7;i++)cells.push(h('div',{className:'ab-empty',key:'e'+i}));
 for(let d=1;d<=days;d++)dates.push(new Date(+first+(d-1)*86400000));
 }else if(view==='week'){
 const at=new Date(selected+'T12:00:00Z'),begin=+at-((at.getUTCDay()+1)%7)*86400000;
 for(let i=0;i<7;i++)dates.push(new Date(begin+i*86400000));
 }else dates.push(new Date(selected+'T12:00:00Z'));
 for(const at of dates){let date=iso(at),slots=data.slots.filter(s=>key(s.starts_at)===date);
 cells.push(h('button',{key:date,type:'button',className:'ab-cell '+(selected===date?'selected':''),onClick:()=>setSelected(date)},
 h('b',null,fa(parts(at).day)),view!=='month'&&h('small',null,new Intl.DateTimeFormat('fa-IR',{weekday:'short',timeZone:'UTC'}).format(at)),
 h('span',{className:'ab-dots'},slots.slice(0,4).map(s=>h('i',{key:s.id,className:!+s.active?'off':+s.reserved>=+s.capacity?'full':+s.reserved?'partial':'free'}))),
 slots.length>0&&h('small',null,fa(slots.length)+' جلسه')))}

 return h('div',{className:'ab-manager',dir:'rtl'},h('header',{className:'ab-heading'},h('div',null,h('h1',null,'جلسات و برنامهٔ همراهی'),h('p',null,'مدیریت زمان‌های قابل رزرو، مشاهده و ویرایش جلسات مشاوره')),h('div',{className:'ab-tools'},btn('⚙ تنظیمات جلسات',()=>open('settings')),btn('◷ سوابق تغییرات',async()=>{try{setHistory(await api('booking/history'));open('history')}catch(e){setError(e.message)}}),btn('مدیریت ظرفیت‌ها',()=>open('day')),h('div',{className:'ab-new'},btn('＋ تعیین وقت جدید',()=>setMenu(!menu),'primary'),menu&&h('div',{className:'ab-dropdown'},btn('ایجاد وقت تکی',()=>open('single')),btn('ایجاد گروهی (بازه زمانی)',()=>open('batch')))))),
 error&&!modal&&h('p',{role:'alert',className:'ab-error'},error),loading&&h('p',{role:'status'},'در حال دریافت جلسات…'),
 h('section',{className:'ab-calendar-card'},h('aside',{className:'ab-agenda'},h('h2',null,label(new Date(selected+'T12:00:00Z'))),h('p',null,fa(daySlots.length)+' جلسه برنامه‌ریزی‌شده'),daySlots.map(s=>h('article',{className:'ab-slot '+(!+s.active?'off':+s.reserved>=+s.capacity?'full':+s.reserved?'partial':'free'),key:s.id},h('div',{className:'ab-slot-top'},h('b',null,s.title),btn('✎',()=>open('single',s))),h('p',null,time(s.starts_at)+' تا '+time(s.ends_at)),h('small',null,name(s.consultant_id)),h('div',{className:'ab-slot-bottom'},h('span',null,'ظرفیت: '+fa(s.capacity)+' نفر'),h('span',null,fa(s.reserved)+' / '+fa(s.capacity)),!+s.active&&h('small',null,'غیرفعال')))),!daySlots.length&&h('p',null,'برای این روز وقتی تعریف نشده است.'),btn('ویرایش همه جلسات روز ✎',()=>open('day'),'outline'),dayBookings.filter(b=>b.status==='pending').length>0&&h('p',null,fa(dayBookings.filter(b=>b.status==='pending').length)+' رزرو در انتظار تأیید')),
 h('div',{className:'ab-calendar'},h('header',{className:'ab-calendar-head'},h('div',{className:'ab-segment'},[['month','ماهانه'],['week','هفتگی'],['day','روزانه']].map(([v,t])=>btn(t,()=>setView(v),view===v?'primary':''))),h('div',{className:'ab-month'},btn('‹',()=>move(-1)),h('b',null,new Intl.DateTimeFormat('fa-IR',{year:'numeric',month:'long',timeZone:'UTC'}).format(first)),btn('›',()=>move(1)))),view==='month'&&h('div',{className:'ab-week-head'},['ش','ی','د','س','چ','پ','ج'].map(d=>h('b',{key:d},d))),h('div',{className:'ab-grid '+view},cells))),
 h('section',{className:'ab-recent'},
 h('header',null,h('h2',null,'آخرین جلسات'),btn(all?'نمایش خلاصه':'مشاهده همه',()=>setAll(!all))),
 h('div',{className:'ab-table-wrap'},h('table',null,
 h('thead',null,h('tr',null,['مراجعه‌کننده / مشاور','موضوع','تاریخ','زمان','ظرفیت','وضعیت','عملیات'].map(t=>h('th',{key:t},t)))),
 h('tbody',null,data.bookings.filter(b=>{let d=key(b.starts_at);return d>=iso(first)&&d<iso(next)}).slice(0,all?2000:8).map(b=>{
 const actions=['pending','approved'].includes(b.status)?h('div',{className:'ab-row-actions'},
 b.status==='pending'&&btn('تأیید',()=>act('bookings/'+b.id+'/status',{status:'approved'}),'',busy),
 b.status==='pending'&&btn('رد',()=>open('reject',b),'',busy),
 btn('تغییر وقت',()=>open('reschedule',b)),btn('لغو',()=>open('cancel',b))):null;
 return h('tr',{key:b.id},h('td',null,b.name||'مراجعه‌کننده',h('small',null,name(b.consultant_id))),h('td',null,b.title),
 h('td',null,new Intl.DateTimeFormat('fa-IR',{timeZone:'Asia/Tehran'}).format(local(b.starts_at))),
 h('td',null,time(b.starts_at)+' – '+time(b.ends_at)),h('td',null,fa(b.reserved)+' / '+fa(b.capacity)),
 h('td',null,h('span',{className:'ab-status '+b.status},statuses[b.status]||b.status)),h('td',null,actions));
 })))),!data.bookings.length&&h('p',null,'رزروی در این ماه ثبت نشده است.')),

 ['cancel','reject'].includes(modal?.type)?h('div',{className:'ab-overlay'},h('section',{className:'ab-dialog',role:'dialog','aria-modal':true},h('h2',null,modal.type==='cancel'?'لغو رزرو؟':'رد درخواست؟'),h('p',null,'سوابق رزرو و پروندهٔ مراجعه‌کننده حفظ می‌شود.'),error&&h('p',{role:'alert'},error),btn('تأیید',()=>act('bookings/'+modal.slot.id+'/status',{status:modal.type==='cancel'?'cancelled':'rejected'}),'primary',busy),btn('بازگشت',()=>setModal(null),'',busy))):modalContent());
};
function timeLatin(s){return new Intl.DateTimeFormat('en-GB',{hour:'2-digit',minute:'2-digit',hourCycle:'h23',timeZone:'Asia/Tehran'}).format(local(s))}
})();

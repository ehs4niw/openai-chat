<?php
defined('ABSPATH') || exit;

function alpha_booking_topics() {
    global $wpdb;
    return $wpdb->get_results('SELECT id,title,free_intro FROM ' . alpha_table('booking_topics') . ' WHERE active=1 ORDER BY id', ARRAY_A);
}

function alpha_student_intro_only() {
    return current_user_can('alpha_student') && !current_user_can('alpha_booking') && !current_user_can('alpha_consult');
}

function alpha_slot_is_intro($slot) {
    if (empty($slot['topic_id'])) return alpha_is_free_intro($slot['title']);

    global $wpdb;
    return (int) $wpdb->get_var($wpdb->prepare(
        'SELECT free_intro FROM ' . alpha_table('booking_topics') . ' WHERE id=%d',
        $slot['topic_id']
    )) === 1;
}

function alpha_available_booking_slots() {
    global $wpdb;
    $slots = alpha_table('slots');
    $where = 's.active=1 AND s.starts_at>UTC_TIMESTAMP()';
    $join = '';
    if (alpha_student_intro_only()) {
        $join = ' LEFT JOIN ' . alpha_table('booking_topics') . ' t ON t.id=s.topic_id';
        $where .= " AND s.reserved<s.capacity AND (t.free_intro=1 OR
            (s.topic_id=0 AND REPLACE(s.title,'ي','ی') LIKE '%رایگان%' AND s.title LIKE '%معارفه%'))";
    }
    return $wpdb->get_results("SELECT s.id,s.title,s.consultant_id,s.starts_at,s.ends_at,s.capacity,s.reserved
        FROM {$slots} s{$join} WHERE {$where} ORDER BY s.starts_at LIMIT 100", ARRAY_A);
}

add_action('alpha_register_routes', function () {
    alpha_route('/booking/topics', 'POST', function ($r) {
        $title = alpha_text($r['title'] ?? '', 200);
        if ($title === '') alpha_fail('عنوان موضوع را وارد کنید.');
        return alpha_tx(function () use ($r, $title) {
            global $wpdb;
            $id = (int) $r['id'];
            $values = ['title' => $title, 'free_intro' => !empty($r['free_intro']) ? 1 : 0];
            if ($id) {
                $topic = alpha_get('booking_topics', $id, true);
                if (empty($topic['active'])) alpha_fail('موضوع حذف شده است.', 409);
                alpha_dbcheck($wpdb->update(alpha_table('booking_topics'), $values, ['id' => $id]));
                alpha_dbcheck($wpdb->query($wpdb->prepare(
                    'UPDATE ' . alpha_table('slots') . ' SET title=%s,revision=revision+1 WHERE topic_id=%d AND reserved=0 AND starts_at>UTC_TIMESTAMP()',
                    $title, $id
                )));
            } else {
                $id = alpha_insert('booking_topics', $values);
            }
            return ['id' => $id];
        });
    }, 'alpha_manage');

    alpha_route('/booking/topics/(?P<id>\d+)/archive', 'POST', function ($r) {
        global $wpdb;
        alpha_dbcheck($wpdb->update(alpha_table('booking_topics'), ['active' => 0], ['id' => (int) $r['id']]));
        return ['ok' => true];
    }, 'alpha_manage');
});

document.querySelectorAll('[data-als-login]').forEach(root => {
    const message = root.querySelector('[data-message]');
    const heading = root.querySelector('h2');
    const description = root.querySelector('[data-als-description]');
    const copy = {
        request: ['ورود به حساب کاربری', 'برای ورود یا ثبت‌نام شماره موبایل خود را وارد کنید.'],
        verify: ['تأیید شماره موبایل', 'کد شش‌رقمی ارسال‌شده به شماره‌تان را وارد کنید.'],
        register: ['تکمیل ثبت‌نام', 'مشخصات را وارد کنید تا به رزرو جلسه معارفه برسید.']
    };
    const restart = root.querySelector('[data-restart]');
    const forms = [...root.querySelectorAll('form[data-step]')];
    let phone = '';
    let registrationToken = '';

    function show(step) {
        [heading.textContent, description.textContent] = copy[step];
        forms.forEach(form => { form.hidden = form.dataset.step !== step; });
        restart.hidden = step === 'request';
        forms.find(form => form.dataset.step === step).querySelector('input').focus();
    }

    restart.addEventListener('click', () => {
        phone = '';
        registrationToken = '';
        forms.filter(form => form.dataset.step !== 'request').forEach(form => form.reset());
        message.textContent = '';
        show('request');
    });

    forms.forEach(form => form.addEventListener('submit', async event => {
        event.preventDefault();
        const step = form.dataset.step;
        const data = Object.fromEntries(new FormData(form));
        if (step === 'verify') data.phone = phone;
        if (step === 'register') data.registration_token = registrationToken;
        const submit = form.querySelector('button');
        submit.disabled = true;
        restart.disabled = true;
        message.textContent = 'در حال بررسی…';
        try {
            const response = await fetch(root.dataset[step], {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.message || 'ارتباط با سایت برقرار نشد.');
            if (result.redirect) {
                window.location.assign(result.redirect);
            } else if (step === 'request') {
                phone = data.phone;
                message.textContent = 'کد تأیید ارسال شد.';
                show('verify');
            } else {
                registrationToken = result.registration_token;
                message.textContent = '';
                show('register');
            }
        } catch (error) {
            message.textContent = error.message;
        } finally {
            submit.disabled = false;
            restart.disabled = false;
        }
    }));
});

const alphaLoginDialog = document.querySelector('#alpha-login-popup');
if (alphaLoginDialog && typeof alphaLoginDialog.showModal === 'function') {
    document.addEventListener('click', event => {
        if (!(event.target instanceof Element) || event.defaultPrevented || event.button !== 0
            || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey) return;
        const trigger = event.target.closest('a.alpha-login-trigger');
        if (!trigger) return;
        event.preventDefault();
        if (!alphaLoginDialog.open) {
            trigger.focus();
            alphaLoginDialog.showModal();
            alphaLoginDialog.querySelector('form:not([hidden]) input')?.focus();
        }
    });
    alphaLoginDialog.querySelector('[data-als-close]').addEventListener('click', () => alphaLoginDialog.close());
    alphaLoginDialog.addEventListener('click', event => {
        if (event.target !== alphaLoginDialog) return;
        const rect = alphaLoginDialog.getBoundingClientRect();
        if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) {
            alphaLoginDialog.close();
        }
    });
}

<?php defined('ABSPATH') || exit; ?>
<div data-als-login class="als-login"
     data-request="<?php echo esc_url(rest_url('alpha-sms/v1/request')); ?>"
     data-verify="<?php echo esc_url(rest_url('alpha-sms/v1/verify')); ?>"
     data-register="<?php echo esc_url(rest_url('alpha-sms/v1/register')); ?>" dir="rtl">
    <h2 id="<?php echo esc_attr($title_id); ?>">ورود به حساب کاربری</h2>
    <p class="als-description" data-als-description>برای ورود یا ثبت‌نام شماره موبایل خود را وارد کنید.</p>
    <form method="post" data-step="request">
        <label>شماره موبایل
            <span class="als-phone">
                <span aria-hidden="true">+۹۸</span>
                <input name="phone" type="tel" inputmode="tel" autocomplete="tel-national" placeholder="0912 345 6789" maxlength="11" required>
            </span>
        </label>
        <button class="als-submit">ارسال کد تأیید</button>
    </form>
    <form method="post" data-step="verify" hidden>
        <label>کد پیامکی <input name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required dir="ltr"></label>
        <button class="als-submit">تأیید کد</button>
    </form>
    <form method="post" data-step="register" hidden>
        <div class="als-names">
            <label>نام <input name="first_name" autocomplete="given-name" maxlength="50" required></label>
            <label>نام خانوادگی <input name="last_name" autocomplete="family-name" maxlength="50" required></label>
        </div>
        <label>گروه آزمایشی
            <select name="exam_group" required>
                <option value="">انتخاب کنید</option>
                <?php foreach (als_exam_groups() as $group): ?>
                    <option><?php echo esc_html($group); ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>رمز عبور <input name="password" type="password" autocomplete="new-password" minlength="8" maxlength="72" required dir="ltr" placeholder="حداقل ۸ کاراکتر"></label>
        <button class="als-submit">ثبت‌نام و رزرو جلسه</button>
    </form>
    <p data-message role="status" aria-live="polite"></p>
    <button class="als-restart" type="button" data-restart hidden>تغییر شماره یا دریافت کد جدید</button>
</div>
